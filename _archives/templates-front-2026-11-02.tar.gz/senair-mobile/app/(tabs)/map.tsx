import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, STATIONS, getAQIInfo } from '@/constants/data';
import { Station } from '@/types';
import StationDetailModal from '@/components/StationDetailModal';
import { MapPin, Layers, Navigation, Plus, Minus, Factory, Home, Route, Building2 } from 'lucide-react-native';
import Svg, { Circle, G, Line, Path } from 'react-native-svg';

const { width, height } = Dimensions.get('window');

// Simulated map bounds for Thiès area
const MAP_BOUNDS = {
  minLat: 14.7600,
  maxLat: 14.8200,
  minLng: -16.9400,
  maxLng: -16.9000,
};

const MAP_WIDTH = width;
const MAP_HEIGHT = height - 120;

function latToY(lat: number): number {
  return ((MAP_BOUNDS.maxLat - lat) / (MAP_BOUNDS.maxLat - MAP_BOUNDS.minLat)) * MAP_HEIGHT;
}
function lngToX(lng: number): number {
  return ((lng - MAP_BOUNDS.minLng) / (MAP_BOUNDS.maxLng - MAP_BOUNDS.minLng)) * MAP_WIDTH;
}

export default function MapScreen() {
  const [selectedStation, setSelectedStation] = useState<Station | null>(null);
  const [filter, setFilter] = useState<'all' | 'industrial' | 'residential' | 'road'>('all');

  const filteredStations = useMemo(() => {
    if (filter === 'all') return STATIONS;
    return STATIONS.filter((s) => s.type === filter);
  }, [filter]);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Carte des stations</Text>
        <Text style={styles.headerSubtitle}>Ville de Thiès — Surveillance en temps réel</Text>
      </View>

      {/* Filter bar */}
      <View style={styles.filterBar}>
        {([
          { key: 'all', label: 'Toutes', icon: <Layers size={14} color="#fff" strokeWidth={2.5} /> },
          { key: 'industrial', label: 'Industriel', icon: <Factory size={14} color="#fff" strokeWidth={2.5} /> },
          { key: 'residential', label: 'Résidentiel', icon: <Home size={14} color="#fff" strokeWidth={2.5} /> },
          { key: 'road', label: 'Trafic', icon: <Route size={14} color="#fff" strokeWidth={2.5} /> },
        ] as const).map((f) => (
          <Pressable
            key={f.key}
            style={[styles.filterChip, filter === f.key && styles.filterChipActive]}
            onPress={() => setFilter(f.key)}
          >
            {filter === f.key && f.icon}
            <Text style={[styles.filterText, filter === f.key && styles.filterTextActive]}>
              {f.label}
            </Text>
          </Pressable>
        ))}
      </View>

      {/* Map */}
      <View style={styles.mapContainer}>
        <Svg width={MAP_WIDTH} height={MAP_HEIGHT} style={styles.mapSvg}>
          {/* Background grid */}
          {Array.from({ length: 8 }).map((_, i) => (
            <G key={`h-${i}`}>
              <Line
                x1={0}
                y1={(i / 8) * MAP_HEIGHT}
                x2={MAP_WIDTH}
                y2={(i / 8) * MAP_HEIGHT}
                stroke={COLORS.border}
                strokeWidth={0.5}
              />
              <Line
                x1={(i / 8) * MAP_WIDTH}
                y1={0}
                x2={(i / 8) * MAP_WIDTH}
                y2={MAP_HEIGHT}
                stroke={COLORS.border}
                strokeWidth={0.5}
              />
            </G>
          ))}

          {/* Roads (simplified) */}
          <Path
            d={`M ${lngToX(-16.9260)} ${latToY(14.7600)} L ${lngToX(-16.9260)} ${latToY(14.8200)}`}
            stroke={COLORS.surfaceAlt}
            strokeWidth={8}
            strokeLinecap="round"
          />
          <Path
            d={`M ${lngToX(-16.9400)} ${latToY(14.7885)} L ${lngToX(-16.9000)} ${latToY(14.7885)}`}
            stroke={COLORS.surfaceAlt}
            strokeWidth={6}
            strokeLinecap="round"
          />
          <Path
            d={`M ${lngToX(-16.9350)} ${latToY(14.7750)} L ${lngToX(-16.9100)} ${latToY(14.8050)}`}
            stroke={COLORS.surfaceAlt}
            strokeWidth={5}
            strokeLinecap="round"
          />

          {/* City center marker */}
          <Circle cx={lngToX(-16.9260)} cy={latToY(14.7885)} r={40} fill={COLORS.primaryLight} opacity={0.3} />

          {/* Station markers */}
          {filteredStations.map((station) => {
            const info = getAQIInfo(station.aqi);
            const x = lngToX(station.lng);
            const y = latToY(station.lat);
            return (
              <G key={station.id}>
                {/* Pulse ring */}
                <Circle cx={x} cy={y} r={24} fill={info.color} opacity={0.15} />
                <Circle cx={x} cy={y} r={16} fill={info.color} opacity={0.25} />
                {/* Main marker */}
                <Circle cx={x} cy={y} r={12} fill={info.color} stroke="#fff" strokeWidth={2.5} />
              </G>
            );
          })}
        </Svg>

        {/* Station labels overlay */}
        {filteredStations.map((station) => {
          const info = getAQIInfo(station.aqi);
          const x = lngToX(station.lng);
          const y = latToY(station.lat);
          return (
            <Pressable
              key={station.id}
              style={[styles.stationLabel, { left: x - 50, top: y + 16 }]}
              onPress={() => setSelectedStation(station)}
            >
              <Text style={styles.stationLabelText} numberOfLines={1}>{station.name}</Text>
              <Text style={[styles.stationLabelAQI, { color: info.color }]}>AQI {station.aqi}</Text>
            </Pressable>
          );
        })}

        {/* Legend */}
        <View style={styles.legend}>
          <Text style={styles.legendTitle}>Niveau AQI</Text>
          {[
            { label: '0-50 Bon', color: '#00E400' },
            { label: '51-100 Modéré', color: '#FFFF00' },
            { label: '101-150 Sensible', color: '#FF7E00' },
            { label: '151-200 Malsain', color: '#FF0000' },
            { label: '201+ Dangereux', color: '#8F3F97' },
          ].map((item) => (
            <View key={item.label} style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: item.color }]} />
              <Text style={styles.legendText}>{item.label}</Text>
            </View>
          ))}
        </View>

        {/* Zoom buttons (decorative) */}
        <View style={styles.zoomControls}>
          <Pressable style={styles.zoomBtn}>
            <Plus size={18} color={COLORS.text} strokeWidth={2.5} />
          </Pressable>
          <Pressable style={styles.zoomBtn}>
            <Minus size={18} color={COLORS.text} strokeWidth={2.5} />
          </Pressable>
          <Pressable style={styles.zoomBtn}>
            <Navigation size={18} color={COLORS.primary} strokeWidth={2.5} />
          </Pressable>
        </View>
      </View>

      {/* Station list preview */}
      <View style={styles.listPreview}>
        <Text style={styles.listPreviewTitle}>{filteredStations.length} stations affichées</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.listPreviewScroll}>
          {filteredStations.map((s) => {
            const info = getAQIInfo(s.aqi);
            return (
              <Pressable key={s.id} style={styles.miniCard} onPress={() => setSelectedStation(s)}>
                <View style={[styles.miniAQI, { backgroundColor: info.color }]}>
                  <Text style={styles.miniAQIText}>{s.aqi}</Text>
                </View>
                <Text style={styles.miniName} numberOfLines={1}>{s.name}</Text>
                <Text style={styles.miniZone} numberOfLines={1}>{s.zone}</Text>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      <StationDetailModal
        station={selectedStation}
        visible={!!selectedStation}
        onClose={() => setSelectedStation(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
  },
  headerTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 22,
    color: COLORS.text,
  },
  headerSubtitle: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  filterBar: {
    flexDirection: 'row',
    paddingHorizontal: SPACING.md,
    paddingBottom: SPACING.sm,
    gap: SPACING.xs,
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
    borderRadius: RADIUS.pill,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  filterChipActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  filterText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  filterTextActive: {
    color: '#fff',
    marginLeft: 4,
  },
  mapContainer: {
    flex: 1,
    position: 'relative',
    backgroundColor: '#F5F7F8',
  },
  mapSvg: {
    position: 'absolute',
    top: 0,
    left: 0,
  },
  stationLabel: {
    position: 'absolute',
    width: 100,
    alignItems: 'center',
  },
  stationLabelText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 11,
    color: COLORS.text,
    textAlign: 'center',
  },
  stationLabelAQI: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 12,
  },
  legend: {
    position: 'absolute',
    top: SPACING.sm,
    right: SPACING.sm,
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderRadius: RADIUS.md,
    padding: SPACING.sm,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  legendTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 11,
    color: COLORS.text,
    marginBottom: 6,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 6,
  },
  legendText: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 10,
    color: COLORS.textSecondary,
  },
  zoomControls: {
    position: 'absolute',
    bottom: SPACING.lg,
    right: SPACING.md,
    gap: SPACING.xs,
  },
  zoomBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.95)',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  listPreview: {
    backgroundColor: COLORS.surface,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
    paddingVertical: SPACING.sm,
  },
  listPreviewTitle: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.textMuted,
    paddingHorizontal: SPACING.md,
    marginBottom: SPACING.xs,
  },
  listPreviewScroll: {
    paddingHorizontal: SPACING.md,
    gap: SPACING.sm,
  },
  miniCard: {
    width: 120,
    backgroundColor: COLORS.background,
    borderRadius: RADIUS.md,
    padding: SPACING.sm,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  miniAQI: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  miniAQIText: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 14,
    color: '#fff',
  },
  miniName: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.text,
  },
  miniZone: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 10,
    color: COLORS.textMuted,
    marginTop: 2,
  },
});
