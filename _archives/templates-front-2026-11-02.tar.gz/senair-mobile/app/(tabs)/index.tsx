import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, STATIONS, getAQIInfo, HISTORY_24H, HISTORY_7D } from '@/constants/data';
import AQIGauge from '@/components/AQIGauge';
import WeatherCard from '@/components/WeatherCard';
import PollutantCard from '@/components/PollutantCard';
import AlertBanner from '@/components/AlertBanner';
import StationCard from '@/components/StationCard';
import SectionHeader from '@/components/SectionHeader';
import AQIChart from '@/components/AQIChart';
import StationDetailModal from '@/components/StationDetailModal';
import { Station } from '@/types';
import { Wind, Droplets, Eye, Activity, Clock, TrendingUp, ChevronDown } from 'lucide-react-native';

export default function HomeScreen() {
  const [refreshing, setRefreshing] = useState(false);
  const [showAlert, setShowAlert] = useState(true);
  const [selectedStation, setSelectedStation] = useState<Station | null>(null);
  const [chartMetric, setChartMetric] = useState<'aqi' | 'pm25' | 'pm10'>('aqi');
  const [chartRange, setChartRange] = useState<'24h' | '7d'>('24h');

  const mainStation = STATIONS[0];
  const info = getAQIInfo(mainStation.aqi);
  const chartData = chartRange === '24h' ? HISTORY_24H : HISTORY_7D;

  const avgAQI = useMemo(() => Math.round(STATIONS.reduce((sum, s) => sum + s.aqi, 0) / STATIONS.length), []);
  const maxStation = useMemo(() => STATIONS.reduce((max, s) => (s.aqi > max.aqi ? s : max), STATIONS[0]), []);

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1200);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView
        style={styles.container}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.primary} />}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Bonjour, Thiès</Text>
            <Text style={styles.date}>
              {new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}
            </Text>
          </View>
          <View style={[styles.logoBadge, { backgroundColor: info.bgColor }]}>
            <Text style={[styles.logoText, { color: info.textColor }]}>SEN-AIR</Text>
          </View>
        </View>

        {/* Alert Banner */}
        {showAlert && (
          <AlertBanner
            aqi={maxStation.aqi}
            stationName={maxStation.name}
            onDismiss={() => setShowAlert(false)}
            onPress={() => setSelectedStation(maxStation)}
          />
        )}

        {/* Main AQI Card */}
        <View style={[styles.mainCard, { backgroundColor: info.bgColor }]}>
          <View style={styles.mainCardHeader}>
            <View>
              <Text style={[styles.cardTitle, { color: info.textColor }]}>Qualité de l'air actuelle</Text>
              <Text style={[styles.cardSubtitle, { color: info.textColor }]}>
                {mainStation.name} · {mainStation.zone}
              </Text>
            </View>
            <Pressable
              style={[styles.changeBtn, { borderColor: info.textColor + '40' }]}
              onPress={() => setSelectedStation(mainStation)}
            >
              <Text style={[styles.changeBtnText, { color: info.textColor }]}>Détails</Text>
            </Pressable>
          </View>
          <View style={styles.gaugeWrap}>
            <AQIGauge aqi={mainStation.aqi} />
          </View>
          <View style={styles.quickStats}>
            <View style={styles.quickStat}>
              <TrendingUp size={16} color={info.textColor} strokeWidth={2} />
              <Text style={[styles.quickStatLabel, { color: info.textColor }]}>Moyenne ville</Text>
              <Text style={[styles.quickStatValue, { color: info.textColor }]}>{avgAQI}</Text>
            </View>
            <View style={[styles.quickStatDivider, { backgroundColor: info.textColor + '20' }]} />
            <View style={styles.quickStat}>
              <Activity size={16} color={info.textColor} strokeWidth={2} />
              <Text style={[styles.quickStatLabel, { color: info.textColor }]}>Pic max</Text>
              <Text style={[styles.quickStatValue, { color: info.textColor }]}>{maxStation.aqi}</Text>
            </View>
            <View style={[styles.quickStatDivider, { backgroundColor: info.textColor + '20' }]} />
            <View style={styles.quickStat}>
              <Clock size={16} color={info.textColor} strokeWidth={2} />
              <Text style={[styles.quickStatLabel, { color: info.textColor }]}>Mise à jour</Text>
              <Text style={[styles.quickStatValue, { color: info.textColor }]}>il y a 5 min</Text>
            </View>
          </View>
        </View>

        {/* Weather */}
        <SectionHeader title="Conditions météo" subtitle="Influence sur la dispersion des polluants" />
        <View style={styles.sectionPadding}>
          <WeatherCard weather={mainStation.weather} />
        </View>

        {/* Pollutants */}
        <SectionHeader title="Polluants mesurés" subtitle="Comparaison aux normes OMS" />
        <View style={styles.sectionPadding}>
          {mainStation.pollutants.map((p) => (
            <PollutantCard key={p.id} pollutant={p} />
          ))}
        </View>

        {/* Chart */}
        <SectionHeader
          title="Évolution temporelle"
          subtitle={chartRange === '24h' ? 'Dernières 24 heures' : '7 derniers jours'}
        />
        <View style={styles.sectionPadding}>
          <View style={styles.chartControls}>
            <View style={styles.metricToggle}>
              {(['aqi', 'pm25', 'pm10'] as const).map((m) => (
                <Pressable
                  key={m}
                  style={[styles.metricBtn, chartMetric === m && styles.metricBtnActive]}
                  onPress={() => setChartMetric(m)}
                >
                  <Text style={[styles.metricBtnText, chartMetric === m && styles.metricBtnTextActive]}>
                    {m === 'aqi' ? 'AQI' : m === 'pm25' ? 'PM2.5' : 'PM10'}
                  </Text>
                </Pressable>
              ))}
            </View>
            <View style={styles.metricToggle}>
              {(['24h', '7d'] as const).map((r) => (
                <Pressable
                  key={r}
                  style={[styles.metricBtn, chartRange === r && styles.metricBtnActive]}
                  onPress={() => setChartRange(r)}
                >
                  <Text style={[styles.metricBtnText, chartRange === r && styles.metricBtnTextActive]}>
                    {r === '24h' ? '24h' : '7j'}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
          <AQIChart data={chartData} metric={chartMetric} />
        </View>

        {/* Stations */}
        <SectionHeader title="Stations de mesure" subtitle={`${STATIONS.length} stations actives à Thiès`} />
        <View style={styles.sectionPadding}>
          {STATIONS.map((s) => (
            <StationCard key={s.id} station={s} onPress={() => setSelectedStation(s)} />
          ))}
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      <StationDetailModal
        station={selectedStation}
        visible={!!selectedStation}
        onClose={() => setSelectedStation(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
  },
  greeting: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 24,
    color: COLORS.text,
  },
  date: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 14,
    color: COLORS.textMuted,
    marginTop: 2,
    textTransform: 'capitalize',
  },
  logoBadge: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.xs,
    borderRadius: RADIUS.pill,
  },
  logoText: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 13,
    letterSpacing: 0.5,
  },
  mainCard: {
    marginHorizontal: SPACING.md,
    borderRadius: RADIUS.xl,
    padding: SPACING.lg,
    marginBottom: SPACING.md,
  },
  mainCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  cardTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 16,
  },
  cardSubtitle: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    opacity: 0.7,
    marginTop: 2,
  },
  changeBtn: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
    borderRadius: RADIUS.pill,
    borderWidth: 1,
  },
  changeBtnText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
  },
  gaugeWrap: {
    alignItems: 'center',
    marginVertical: SPACING.md,
  },
  quickStats: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    marginTop: SPACING.sm,
  },
  quickStat: {
    alignItems: 'center',
    flex: 1,
  },
  quickStatLabel: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    opacity: 0.7,
    marginTop: 4,
  },
  quickStatValue: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 16,
    marginTop: 2,
  },
  quickStatDivider: {
    width: 1,
    height: 32,
  },
  sectionPadding: {
    paddingHorizontal: SPACING.md,
  },
  chartControls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: SPACING.sm,
  },
  metricToggle: {
    flexDirection: 'row',
    backgroundColor: COLORS.surfaceAlt,
    borderRadius: RADIUS.pill,
    padding: 2,
  },
  metricBtn: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
    borderRadius: RADIUS.pill,
  },
  metricBtnActive: {
    backgroundColor: COLORS.primary,
  },
  metricBtnText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  metricBtnTextActive: {
    color: '#fff',
  },
});
