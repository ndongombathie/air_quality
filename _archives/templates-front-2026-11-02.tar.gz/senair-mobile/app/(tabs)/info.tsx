import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Linking } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, WHO_NORMS } from '@/constants/data';
import SectionHeader from '@/components/SectionHeader';
import { BookOpen, ExternalLink, FileText, Globe, ChevronRight, Info, Beaker, Scale, Shield } from 'lucide-react-native';

const ARTICLES = [
  {
    id: '1',
    title: "Comprendre l'indice de qualité de l'air (AQI)",
    category: 'Éducation',
    excerpt: "L'AQI est un indicateur standardisé qui traduit les concentrations de polluants en une valeur compréhensible par tous...",
    icon: 'book',
    readTime: '5 min',
  },
  {
    id: '2',
    title: 'Les effets des particules fines sur la santé',
    category: 'Santé',
    excerpt: 'Les particules fines PM2.5 pénètrent profondément dans les poumons et peuvent passer dans la circulation sanguine...',
    icon: 'health',
    readTime: '7 min',
  },
  {
    id: '3',
    title: 'Pollution atmosphérique à Thiès : sources et enjeux',
    category: 'Local',
    excerpt: "La ville de Thiès fait face à des défis majeurs liés à l'industrialisation, au trafic routier et aux activités artisanales...",
    icon: 'local',
    readTime: '10 min',
  },
  {
    id: '4',
    title: "Comment se protéger lors d'un pic de pollution",
    category: 'Prévention',
    excerpt: 'Mesures pratiques pour réduire son exposition et protéger sa santé lors des épisodes de pollution élevée...',
    icon: 'prevention',
    readTime: '4 min',
  },
  {
    id: '5',
    title: "Les normes de l'OMS expliquées",
    category: 'Réglementation',
    excerpt: "L'Organisation Mondiale de la Santé publie des lignes directrices sur la qualité de l'air basées sur des preuves scientifiques...",
    icon: 'regulation',
    readTime: '8 min',
  },
];

export default function InfoScreen() {
  const [expandedNorm, setExpandedNorm] = useState<string | null>(null);

  const getArticleIcon = (iconName: string) => {
    switch (iconName) {
      case 'book': return <BookOpen size={24} color={COLORS.primary} strokeWidth={2} />;
      case 'health': return <Shield size={24} color={COLORS.error} strokeWidth={2} />;
      case 'local': return <Globe size={24} color={COLORS.secondary} strokeWidth={2} />;
      case 'prevention': return <Info size={24} color={COLORS.accent} strokeWidth={2} />;
      case 'regulation': return <Scale size={24} color={COLORS.primaryDark} strokeWidth={2} />;
      default: return <FileText size={24} color={COLORS.primary} strokeWidth={2} />;
    }
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Informations</Text>
          <Text style={styles.headerSubtitle}>
            Normes, ressources et documentation
          </Text>
        </View>

        {/* About SEN-AIR */}
        <View style={styles.aboutCard}>
          <View style={styles.aboutHeader}>
            <View style={styles.aboutIcon}>
              <Beaker size={24} color="#fff" strokeWidth={2} />
            </View>
            <View>
              <Text style={styles.aboutTitle}>SEN-AIR</Text>
              <Text style={styles.aboutSubtitle}>Surveillance de la qualité de l'air</Text>
            </View>
          </View>
          <Text style={styles.aboutText}>
            SEN-AIR est un système de surveillance de la qualité de l'air dédié à la ville de Thiès, au Sénégal. 
            Notre mission est de fournir en temps réel des données fiables sur la pollution atmosphérique 
            et de sensibiliser la population aux enjeux de santé publique.
          </Text>
          <View style={styles.aboutStats}>
            <View style={styles.aboutStat}>
              <Text style={styles.aboutStatValue}>6</Text>
              <Text style={styles.aboutStatLabel}>Stations</Text>
            </View>
            <View style={styles.aboutStatDivider} />
            <View style={styles.aboutStat}>
              <Text style={styles.aboutStatValue}>5</Text>
              <Text style={styles.aboutStatLabel}>Polluants</Text>
            </View>
            <View style={styles.aboutStatDivider} />
            <View style={styles.aboutStat}>
              <Text style={styles.aboutStatValue}>24/7</Text>
              <Text style={styles.aboutStatLabel}>Surveillance</Text>
            </View>
          </View>
        </View>

        {/* WHO Norms */}
        <SectionHeader title="Normes OMS" subtitle="Lignes directrices sur la qualité de l'air" />
        <View style={styles.normsSection}>
          {WHO_NORMS.map((norm) => {
            const isExpanded = expandedNorm === norm.pollutant;
            return (
              <View key={norm.pollutant} style={styles.normCard}>
                <Pressable
                  style={styles.normHeader}
                  onPress={() => setExpandedNorm(isExpanded ? null : norm.pollutant)}
                >
                  <View style={styles.normLeft}>
                    <View style={styles.normFormula}>
                      <Text style={styles.normFormulaText}>{norm.formula}</Text>
                    </View>
                    <View>
                      <Text style={styles.normName}>{norm.pollutant}</Text>
                      <Text style={styles.normUnit}>{norm.unit}</Text>
                    </View>
                  </View>
                  <ChevronRight
                    size={20}
                    color={COLORS.textMuted}
                    strokeWidth={2.5}
                    style={{ transform: [{ rotate: isExpanded ? '90deg' : '0deg' }] }}
                  />
                </Pressable>
                {isExpanded && (
                  <View style={styles.normDetails}>
                    {norm.annual !== undefined && (
                      <View style={styles.normDetailRow}>
                        <Text style={styles.normDetailLabel}>Moyenne annuelle</Text>
                        <Text style={styles.normDetailValue}>{norm.annual} {norm.unit}</Text>
                      </View>
                    )}
                    {norm.daily !== undefined && (
                      <View style={styles.normDetailRow}>
                        <Text style={styles.normDetailLabel}>Moyenne 24h</Text>
                        <Text style={styles.normDetailValue}>{norm.daily} {norm.unit}</Text>
                      </View>
                    )}
                    {norm.hourly8 !== undefined && (
                      <View style={styles.normDetailRow}>
                        <Text style={styles.normDetailLabel}>Moyenne 8h</Text>
                        <Text style={styles.normDetailValue}>{norm.hourly8} {norm.unit}</Text>
                      </View>
                    )}
                  </View>
                )}
              </View>
            );
          })}
        </View>

        {/* Articles */}
        <SectionHeader title="Ressources & articles" subtitle="En savoir plus sur la qualité de l'air" />
        <View style={styles.articlesSection}>
          {ARTICLES.map((article) => (
            <Pressable
              key={article.id}
              style={({ pressed }) => [styles.articleCard, pressed && styles.pressed]}
            >
              <View style={styles.articleIconWrap}>
                {getArticleIcon(article.icon)}
              </View>
              <View style={styles.articleContent}>
                <View style={styles.articleMeta}>
                  <View style={styles.articleCategory}>
                    <Text style={styles.articleCategoryText}>{article.category}</Text>
                  </View>
                  <Text style={styles.articleReadTime}>{article.readTime}</Text>
                </View>
                <Text style={styles.articleTitle} numberOfLines={2}>{article.title}</Text>
                <Text style={styles.articleExcerpt} numberOfLines={2}>{article.excerpt}</Text>
              </View>
              <ChevronRight size={18} color={COLORS.textMuted} strokeWidth={2.5} style={styles.articleChevron} />
            </Pressable>
          ))}
        </View>

        {/* External resources */}
        <SectionHeader title="Ressources externes" />
        <View style={styles.linksSection}>
          {[
            { label: "OMS — Qualité de l'air", url: 'https://www.who.int/health-topics/air-pollution', icon: <Globe size={20} color={COLORS.secondary} strokeWidth={2} /> },
            { label: 'AirNow — Indice AQI', url: 'https://www.airnow.gov', icon: <ExternalLink size={20} color={COLORS.primary} strokeWidth={2} /> },
            { label: "Ministère de l'Environnement (Sénégal)", url: 'https://www.environnement.gouv.sn', icon: <Shield size={20} color={COLORS.primaryDark} strokeWidth={2} /> },
          ].map((link) => (
            <Pressable
              key={link.label}
              style={({ pressed }) => [styles.linkRow, pressed && styles.pressed]}
              onPress={() => Linking.openURL(link.url)}
            >
              {link.icon}
              <Text style={styles.linkLabel}>{link.label}</Text>
              <ExternalLink size={16} color={COLORS.textMuted} strokeWidth={2} style={{ marginLeft: 'auto' }} />
            </Pressable>
          ))}
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>SEN-AIR v1.0.0</Text>
          <Text style={styles.footerSub}>Données à but informatif et de sensibilisation</Text>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
  },
  headerTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 22,
    color: COLORS.text,
  },
  headerSubtitle: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  aboutCard: {
    marginHorizontal: SPACING.md,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.xl,
    padding: SPACING.lg,
    marginBottom: SPACING.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  aboutHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  aboutIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.sm,
  },
  aboutTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 20,
    color: COLORS.text,
  },
  aboutSubtitle: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  aboutText: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 14,
    color: COLORS.textSecondary,
    lineHeight: 22,
    marginBottom: SPACING.md,
  },
  aboutStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: COLORS.surfaceAlt,
    borderRadius: RADIUS.md,
    paddingVertical: SPACING.sm,
  },
  aboutStat: {
    alignItems: 'center',
  },
  aboutStatValue: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 20,
    color: COLORS.primary,
  },
  aboutStatLabel: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  aboutStatDivider: {
    width: 1,
    height: 28,
    backgroundColor: COLORS.border,
  },
  normsSection: {
    paddingHorizontal: SPACING.md,
    marginBottom: SPACING.md,
  },
  normCard: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    marginBottom: SPACING.sm,
    overflow: 'hidden',
  },
  normHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: SPACING.md,
  },
  normLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  normFormula: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: COLORS.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.sm,
  },
  normFormulaText: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 16,
    color: COLORS.primary,
  },
  normName: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 14,
    color: COLORS.text,
  },
  normUnit: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  normDetails: {
    paddingHorizontal: SPACING.md,
    paddingBottom: SPACING.md,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
    paddingTop: SPACING.sm,
  },
  normDetailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
  normDetailLabel: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  normDetailValue: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 13,
    color: COLORS.text,
  },
  articlesSection: {
    paddingHorizontal: SPACING.md,
    marginBottom: SPACING.md,
  },
  articleCard: {
    flexDirection: 'row',
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.sm,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  pressed: {
    opacity: 0.85,
  },
  articleIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.sm,
  },
  articleContent: {
    flex: 1,
  },
  articleMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  articleCategory: {
    backgroundColor: COLORS.primaryLight,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 2,
    borderRadius: RADIUS.sm,
    marginRight: SPACING.sm,
  },
  articleCategoryText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 10,
    color: COLORS.primary,
  },
  articleReadTime: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: COLORS.textMuted,
  },
  articleTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 14,
    color: COLORS.text,
    marginBottom: 4,
  },
  articleExcerpt: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    color: COLORS.textSecondary,
    lineHeight: 17,
  },
  articleChevron: {
    marginLeft: SPACING.sm,
  },
  linksSection: {
    marginHorizontal: SPACING.md,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.lg,
    padding: SPACING.sm,
    marginBottom: SPACING.md,
  },
  linkRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: SPACING.sm,
    paddingHorizontal: SPACING.sm,
    borderRadius: RADIUS.md,
  },
  linkLabel: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 14,
    color: COLORS.text,
    marginLeft: SPACING.sm,
    flex: 1,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: SPACING.lg,
  },
  footerText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 13,
    color: COLORS.textMuted,
  },
  footerSub: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: COLORS.textMuted,
    marginTop: 4,
  },
});
