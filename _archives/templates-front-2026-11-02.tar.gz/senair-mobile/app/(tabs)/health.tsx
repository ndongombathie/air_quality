import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, HEALTH_PROFILES, RECOMMENDATIONS, getAQIInfo, STATIONS } from '@/constants/data';
import SectionHeader from '@/components/SectionHeader';
import { Check, Heart, Wind, Activity, Shield, AlertTriangle, ChevronRight } from 'lucide-react-native';

export default function HealthScreen() {
  const [selectedProfile, setSelectedProfile] = useState('general');
  const [selectedStationId, setSelectedStationId] = useState(STATIONS[0].id);

  const station = STATIONS.find((s) => s.id === selectedStationId) ?? STATIONS[0];
  const info = getAQIInfo(station.aqi);

  const getRecommendation = () => {
    const rec = RECOMMENDATIONS.find(
      (r) => r.profile === selectedProfile && r.aqiLevel === info.level
    );
    if (rec) return rec;
    // Fallback: general recommendation at this AQI level
    const general = RECOMMENDATIONS.find(
      (r) => r.profile === 'general' && r.aqiLevel === info.level
    );
    return general;
  };

  const recommendation = getRecommendation();

  const profileIcon = (iconName: string, size: number, color: string) => {
    const icons: Record<string, React.ReactNode> = {
      users: <Heart size={size} color={color} strokeWidth={2} />,
      baby: <Heart size={size} color={color} strokeWidth={2} />,
      accessibility: <Activity size={size} color={color} strokeWidth={2} />,
      wind: <Wind size={size} color={color} strokeWidth={2} />,
      'heart-pulse': <Heart size={size} color={color} strokeWidth={2} />,
      heart: <Heart size={size} color={color} strokeWidth={2} />,
      'hard-hat': <Shield size={size} color={color} strokeWidth={2} />,
      activity: <Activity size={size} color={color} strokeWidth={2} />,
    };
    return icons[iconName] ?? <Heart size={size} color={color} strokeWidth={2} />;
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Conseils santé</Text>
          <Text style={styles.headerSubtitle}>
            Recommandations personnalisées selon votre profil
          </Text>
        </View>

        {/* Current AQI context */}
        <View style={[styles.aqiContext, { backgroundColor: info.bgColor, borderColor: info.color }]}>
          <View style={[styles.aqiCircle, { backgroundColor: info.color }]}>
            <Text style={styles.aqiNum}>{station.aqi}</Text>
          </View>
          <View style={styles.aqiContextInfo}>
            <Text style={[styles.aqiContextStation, { color: info.textColor }]}>
              {station.name}
            </Text>
            <Text style={[styles.aqiContextLevel, { color: info.textColor }]}>
              {info.labelFr}
            </Text>
          </View>
        </View>

        {/* Station selector */}
        <SectionHeader title="Zone surveillée" />
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.stationSelector}
        >
          {STATIONS.map((s) => {
            const sInfo = getAQIInfo(s.aqi);
            const isSelected = s.id === selectedStationId;
            return (
              <Pressable
                key={s.id}
                style={[styles.stationChip, isSelected && styles.stationChipActive]}
                onPress={() => setSelectedStationId(s.id)}
              >
                <View style={[styles.stationChipDot, { backgroundColor: sInfo.color }]} />
                <Text
                  style={[
                    styles.stationChipText,
                    isSelected && styles.stationChipTextActive,
                  ]}
                  numberOfLines={1}
                >
                  {s.name}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>

        {/* Profile selector */}
        <SectionHeader title="Votre profil" subtitle="Sélectionnez votre catégorie pour des conseils adaptés" />
        <View style={styles.profileGrid}>
          {HEALTH_PROFILES.map((profile) => {
            const isSelected = profile.id === selectedProfile;
            return (
              <Pressable
                key={profile.id}
                style={[styles.profileCard, isSelected && styles.profileCardActive]}
                onPress={() => setSelectedProfile(profile.id)}
              >
                <View style={[styles.profileIconWrap, isSelected && styles.profileIconWrapActive]}>
                  {profileIcon(profile.icon, 22, isSelected ? '#fff' : COLORS.primary)}
                </View>
                <Text
                  style={[styles.profileLabel, isSelected && styles.profileLabelActive]}
                  numberOfLines={2}
                >
                  {profile.label}
                </Text>
                {isSelected && (
                  <View style={styles.profileCheck}>
                    <Check size={12} color="#fff" strokeWidth={3} />
                  </View>
                )}
              </Pressable>
            );
          })}
        </View>

        {/* Recommendation */}
        <SectionHeader title="Recommandations" subtitle={`Pour ${HEALTH_PROFILES.find((p) => p.id === selectedProfile)?.label}`} />
        <View style={styles.recommendationCard}>
          <View style={[styles.recHeader, { backgroundColor: recommendation?.color ?? COLORS.primary }]}>
            <AlertTriangle size={20} color="#fff" strokeWidth={2.5} />
            <Text style={styles.recTitle}>{recommendation?.title ?? 'Surveillance recommandée'}</Text>
          </View>
          <View style={styles.recBody}>
            {recommendation?.actions.map((action, i) => (
              <View key={i} style={styles.recAction}>
                <View style={[styles.recActionDot, { backgroundColor: recommendation.color ?? COLORS.primary }]} />
                <Text style={styles.recActionText}>{action}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Risk level explanation */}
        <SectionHeader title="Niveau de risque" subtitle="Comprendre l'indice de qualité de l'air" />
        <View style={styles.riskSection}>
          {[
            { level: 'Bon', range: '0-50', color: '#00E400', desc: 'Aucun risque, air de bonne qualité' },
            { level: 'Modéré', range: '51-100', color: '#FFFF00', desc: 'Risque limité pour les personnes très sensibles' },
            { level: 'Sensible', range: '101-150', color: '#FF7E00', desc: 'Risque pour les groupes sensibles' },
            { level: 'Malsain', range: '151-200', color: '#FF0000', desc: 'Risque pour toute la population' },
            { level: 'Très malsain', range: '201-300', color: '#8F3F97', desc: 'Alerte sanitaire générale' },
            { level: 'Dangereux', range: '301+', color: '#7E0023', desc: 'Danger immédiat pour la santé' },
          ].map((item) => (
            <View key={item.level} style={styles.riskRow}>
              <View style={styles.riskLeft}>
                <View style={[styles.riskColorBox, { backgroundColor: item.color }]} />
                <View>
                  <Text style={styles.riskLevel}>{item.level}</Text>
                  <Text style={styles.riskRange}>AQI {item.range}</Text>
                </View>
              </View>
              <Text style={styles.riskDesc}>{item.desc}</Text>
            </View>
          ))}
        </View>

        {/* Health impact */}
        <SectionHeader title="Effets sur la santé" />
        <View style={styles.healthImpact}>
          <View style={styles.impactCard}>
            <Wind size={24} color={COLORS.secondary} strokeWidth={2} />
            <Text style={styles.impactTitle}>Système respiratoire</Text>
            <Text style={styles.impactDesc}>
              Irritation, toux, aggravation de l'asthme, diminution de la capacité pulmonaire
            </Text>
          </View>
          <View style={styles.impactCard}>
            <Heart size={24} color={COLORS.error} strokeWidth={2} />
            <Text style={styles.impactTitle}>Système cardiovasculaire</Text>
            <Text style={styles.impactDesc}>
              Augmentation du risque cardiaque, hypertension, troubles du rythme
            </Text>
          </View>
          <View style={styles.impactCard}>
            <Shield size={24} color={COLORS.primary} strokeWidth={2} />
            <Text style={styles.impactTitle}>Système immunitaire</Text>
            <Text style={styles.impactDesc}>
              Baisse des défenses, sensibilité accrue aux infections respiratoires
            </Text>
          </View>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
  },
  headerTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 22,
    color: COLORS.text,
  },
  headerSubtitle: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  aqiContext: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: SPACING.md,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    borderWidth: 1.5,
    marginBottom: SPACING.md,
  },
  aqiCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.md,
  },
  aqiNum: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 24,
    color: '#fff',
  },
  aqiContextInfo: {
    flex: 1,
  },
  aqiContextStation: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 16,
  },
  aqiContextLevel: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    opacity: 0.8,
    marginTop: 2,
  },
  stationSelector: {
    paddingHorizontal: SPACING.md,
    gap: SPACING.sm,
    paddingBottom: SPACING.sm,
  },
  stationChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical: 8,
    borderRadius: RADIUS.pill,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  stationChipActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  stationChipDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  stationChipText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  stationChipTextActive: {
    color: '#fff',
  },
  profileGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: SPACING.md,
    gap: SPACING.sm,
    marginBottom: SPACING.md,
  },
  profileCard: {
    width: '48%',
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: COLORS.border,
    position: 'relative',
  },
  profileCardActive: {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primaryLight,
  },
  profileIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: SPACING.sm,
  },
  profileIconWrapActive: {
    backgroundColor: COLORS.primary,
  },
  profileLabel: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 13,
    color: COLORS.text,
    textAlign: 'center',
  },
  profileLabelActive: {
    color: COLORS.primary,
  },
  profileCheck: {
    position: 'absolute',
    top: SPACING.sm,
    right: SPACING.sm,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  recommendationCard: {
    marginHorizontal: SPACING.md,
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.lg,
    overflow: 'hidden',
    marginBottom: SPACING.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  recHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: SPACING.md,
  },
  recTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 16,
    color: '#fff',
    marginLeft: SPACING.sm,
  },
  recBody: {
    padding: SPACING.md,
  },
  recAction: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: SPACING.sm,
  },
  recActionDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginTop: 5,
    marginRight: SPACING.sm,
  },
  recActionText: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 14,
    color: COLORS.text,
    flex: 1,
    lineHeight: 20,
  },
  riskSection: {
    backgroundColor: COLORS.surface,
    marginHorizontal: SPACING.md,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.md,
  },
  riskRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  riskLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  riskColorBox: {
    width: 24,
    height: 24,
    borderRadius: 6,
    marginRight: SPACING.sm,
  },
  riskLevel: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 14,
    color: COLORS.text,
  },
  riskRange: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: COLORS.textMuted,
  },
  riskDesc: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: COLORS.textSecondary,
    textAlign: 'right',
    flex: 1,
    marginLeft: SPACING.sm,
  },
  healthImpact: {
    paddingHorizontal: SPACING.md,
    gap: SPACING.sm,
    marginBottom: SPACING.md,
  },
  impactCard: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  impactTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 14,
    color: COLORS.text,
    marginLeft: SPACING.sm,
  },
  impactDesc: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    color: COLORS.textSecondary,
    marginLeft: 'auto',
    textAlign: 'right',
    flex: 1,
    lineHeight: 16,
  },
});
