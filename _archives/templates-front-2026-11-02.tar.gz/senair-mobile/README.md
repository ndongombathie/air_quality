## 📋 Récapitulatif du projet SEN-AIR

**SEN-AIR** est une application mobile React Native (Expo Router) de **surveillance de la qualité de l'air** dédiée à la ville de **Thiès, Sénégal**.

### Architecture
- **Framework** : React Native / Expo Router (5 onglets : Accueil, Carte, Alertes, Santé, Infos)
- **Langage** : TypeScript
- **Backend visé** : python/django
- **Données** : Actuellement toutes **mockées/statiques** dans `constants/data.ts`

### Modèles de données principaux
- **Station** (6 stations : Thiès Centre, Zone Industrielle, Thiès Nord, Route Dakar-Bamako, Thiès Est, Thiès Sud)
- **Pollutant** (5 polluants : PM2.5, PM10, NO₂, SO₂, O₃)
- **WeatherData** (température, humidité, vent, pression)
- **Alert** (4 alertes mockées)
- **HealthProfile** (8 profils : général, enfants, âgés, asthmatiques, cardiaques, femmes enceintes, travailleurs extérieurs, sportifs)
- **Recommendation** (12 recommandations)
- **WHONorm** (6 normes OMS)
- **HistoryPoint** (historique 24h et 7 jours)

---

## 🚀 22 Endpoints API nécessaires

### Stations (3)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/stations` | Liste toutes les stations avec AQI |
| GET | `/api/stations/:id` | Détail complet d'une station |
| GET | `/api/stations/:id/pollutants` | Polluants d'une station |

### AQI (3)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/aqi` | AQI global (moyenne) |
| GET | `/api/aqi/:stationId` | AQI d'une station |
| GET | `/api/aqi/history/:stationId?range=24h\|7d` | Historique AQI |

### Polluants (2)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/pollutants` | Liste des polluants |
| GET | `/api/pollutants/:id` | Détail d'un polluant |

### Météo (1)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/weather/:stationId` | Météo d'une station |

### Alertes (3)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/alerts?read=false&stationId=:id` | Liste des alertes filtrées |
| PATCH | `/api/alerts/:id/read` | Marquer une alerte lue |
| PATCH | `/api/alerts/read-all` | Tout marquer comme lu |

### Santé (3)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/health-profiles` | Profils santé |
| GET | `/api/recommendations` | Toutes les recommandations |
| GET | `/api/recommendations?profile=:id&aqiLevel=:level` | Recommandation spécifique |

### Normes OMS (1)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/who-norms` | Normes OMS |

### Auth & Utilisateurs (4)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/api/auth/register` | Inscription |
| POST | `/api/auth/login` | Connexion |
| GET | `/api/users/:id/preferences` | Préférences utilisateur |
| PATCH | `/api/users/:id/preferences` | Mise à jour préférences |

### Articles (2)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/articles` | Articles éducatifs |
| GET | `/api/articles/:id` | Détail d'un article |

**Total : 22 endpoints REST** à implémenter côté Supabase/backend.

