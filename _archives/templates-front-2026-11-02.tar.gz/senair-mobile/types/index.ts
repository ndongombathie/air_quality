export type AQILevel = 'good' | 'moderate' | 'sensitive' | 'unhealthy' | 'very_unhealthy' | 'hazardous';

export interface AQIInfo {
  level: AQILevel;
  label: string;
  labelFr: string;
  color: string;
  bgColor: string;
  textColor: string;
  min: number;
  max: number;
  icon: string;
}

export interface Pollutant {
  id: string;
  name: string;
  unit: string;
  value: number;
  whoLimit: number;
  description: string;
}

export interface WeatherData {
  temperature: number;
  humidity: number;
  windSpeed: number;
  windDirection: string;
  pressure: number;
  condition: string;
  icon: string;
}

export interface Station {
  id: string;
  name: string;
  zone: string;
  lat: number;
  lng: number;
  aqi: number;
  pollutants: Pollutant[];
  weather: WeatherData;
  lastUpdate: Date;
  type: 'industrial' | 'residential' | 'road' | 'reference';
  active: boolean;
}

export interface Alert {
  id: string;
  stationId: string;
  stationName: string;
  pollutant: string;
  value: number;
  threshold: number;
  level: AQILevel;
  timestamp: Date;
  read: boolean;
  message: string;
}

export interface HealthProfile {
  id: string;
  label: string;
  icon: string;
  description: string;
}

export interface Recommendation {
  profile: string;
  aqiLevel: AQILevel;
  title: string;
  actions: string[];
  color: string;
}

export interface WHONorm {
  pollutant: string;
  formula: string;
  annual?: number;
  daily?: number;
  hourly8?: number;
  unit: string;
}

export interface HistoryPoint {
  time: string;
  aqi: number;
  pm25: number;
  pm10: number;
}
