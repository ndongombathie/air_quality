import { AQIInfo, AQILevel, Pollutant, WeatherData, Station, Alert, Recommendation, WHONorm, HistoryPoint } from '@/types';

export const AQI_LEVELS: Record<AQILevel, AQIInfo> = {
  good: {
    level: 'good',
    label: 'Good',
    labelFr: 'Bon',
    color: '#00E400',
    bgColor: '#E8F8E8',
    textColor: '#1B5E20',
    min: 0,
    max: 50,
    icon: 'check-circle',
  },
  moderate: {
    level: 'moderate',
    label: 'Moderate',
    labelFr: 'Modéré',
    color: '#FFFF00',
    bgColor: '#FFFDE7',
    textColor: '#F57F17',
    min: 51,
    max: 100,
    icon: 'alert-circle',
  },
  sensitive: {
    level: 'sensitive',
    label: 'Unhealthy for Sensitive Groups',
    labelFr: 'Malsain pour groupes sensibles',
    color: '#FF7E00',
    bgColor: '#FFF3E0',
    textColor: '#E65100',
    min: 101,
    max: 150,
    icon: 'alert-triangle',
  },
  unhealthy: {
    level: 'unhealthy',
    label: 'Unhealthy',
    labelFr: 'Malsain',
    color: '#FF0000',
    bgColor: '#FFEBEE',
    textColor: '#B71C1C',
    min: 151,
    max: 200,
    icon: 'alert-octagon',
  },
  very_unhealthy: {
    level: 'very_unhealthy',
    label: 'Very Unhealthy',
    labelFr: 'Très malsain',
    color: '#8F3F97',
    bgColor: '#F3E5F5',
    textColor: '#4A148C',
    min: 201,
    max: 300,
    icon: 'alert-octagon',
  },
  hazardous: {
    level: 'hazardous',
    label: 'Hazardous',
    labelFr: 'Dangereux',
    color: '#7E0023',
    bgColor: '#FCE4EC',
    textColor: '#560027',
    min: 301,
    max: 500,
    icon: 'skull',
  },
};

export function getAQIInfo(aqi: number): AQIInfo {
  if (aqi <= 50) return AQI_LEVELS.good;
  if (aqi <= 100) return AQI_LEVELS.moderate;
  if (aqi <= 150) return AQI_LEVELS.sensitive;
  if (aqi <= 200) return AQI_LEVELS.unhealthy;
  if (aqi <= 300) return AQI_LEVELS.very_unhealthy;
  return AQI_LEVELS.hazardous;
}

export const WHO_NORMS: WHONorm[] = [
  { pollutant: 'Dioxyde d\'azote', formula: 'NO₂', annual: 10, hourly8: 25, unit: 'µg/m³' },
  { pollutant: 'Dioxyde de soufre', formula: 'SO₂', daily: 40, hourly8: 200, unit: 'µg/m³' },
  { pollutant: 'Ozone', formula: 'O₃', hourly8: 100, unit: 'µg/m³' },
  { pollutant: 'Particules fines', formula: 'PM2.5', annual: 5, daily: 15, unit: 'µg/m³' },
  { pollutant: 'Particules grossières', formula: 'PM10', annual: 15, daily: 45, unit: 'µg/m³' },
  { pollutant: 'Monoxyde de carbone', formula: 'CO', daily: 4, unit: 'mg/m³' },
];

export const HEALTH_PROFILES = [
  { id: 'general', label: 'Population générale', icon: 'users', description: 'Adultes en bonne santé' },
  { id: 'children', label: 'Enfants', icon: 'baby', description: 'Moins de 12 ans' },
  { id: 'elderly', label: 'Personnes âgées', icon: 'accessibility', description: 'Plus de 65 ans' },
  { id: 'asthma', label: 'Asthmatiques', icon: 'wind', description: 'Maladies respiratoires' },
  { id: 'cardiac', label: 'Cardiaques', icon: 'heart-pulse', description: 'Maladies cardiovasculaires' },
  { id: 'pregnant', label: 'Femmes enceintes', icon: 'heart', description: 'Grossesse' },
  { id: 'outdoor', label: 'Travailleurs extérieurs', icon: 'hard-hat', description: 'Exposition professionnelle' },
  { id: 'athlete', label: 'Sportifs', icon: 'activity', description: 'Activité physique intense' },
];

export const RECOMMENDATIONS: Recommendation[] = [
  {
    profile: 'general',
    aqiLevel: 'good',
    title: 'Qualité de l\'air idéale',
    actions: [
      'Profitez pleinement des activités en plein air',
      'Aérez votre domicile en grand',
      'Aucune précaution particulière nécessaire',
    ],
    color: '#00B86B',
  },
  {
    profile: 'general',
    aqiLevel: 'moderate',
    title: 'Qualité de l\'air acceptable',
    actions: [
      'Activités extérieures possibles sans restriction majeure',
      'Aérez en début de journée quand la pollution est plus faible',
      'Surveillez les évolutions si vous êtes sensible',
    ],
    color: '#F5A623',
  },
  {
    profile: 'general',
    aqiLevel: 'sensitive',
    title: 'Prudence recommandée',
    actions: [
      'Limitez les efforts intenses en plein air',
      'Préférez l\'activité physique en intérieur',
      'Aérez tôt le matin (6h-8h)',
    ],
    color: '#FF7E00',
  },
  {
    profile: 'general',
    aqiLevel: 'unhealthy',
    title: 'Évitez l\'extérieur',
    actions: [
      'Restez à l\'intérieur autant que possible',
      'Fermez fenêtres et portes',
      'Utilisez un purificateur d\'air si disponible',
    ],
    color: '#E53935',
  },
  {
    profile: 'general',
    aqiLevel: 'very_unhealthy',
    title: 'Alerte sanitaire',
    actions: [
      'Restez impérativement à l\'intérieur',
      'Évitez toute activité physique',
      'Portez un masque si vous devez sortir',
    ],
    color: '#8F3F97',
  },
  {
    profile: 'children',
    aqiLevel: 'moderate',
    title: 'Surveillance renforcée pour les enfants',
    actions: [
      'Limitez les jeux extérieurs prolongés',
      'Privilégiez les activités calmes en intérieur',
      'Surveillez la respiration et la toux',
    ],
    color: '#F5A623',
  },
  {
    profile: 'children',
    aqiLevel: 'sensitive',
    title: 'Protection des enfants',
    actions: [
      'Maintenez les enfants à l\'intérieur',
      'Suspendez les activités sportives en extérieur',
      'Consultez un médecin en cas de toux ou gêne',
    ],
    color: '#FF7E00',
  },
  {
    profile: 'asthma',
    aqiLevel: 'moderate',
    title: 'Vigilance asthmatiques',
    actions: [
      'Gardez votre bronchodilatateur à portée de main',
      'Évitez les zones à fort trafic',
      'Surveillez tout signe d\'essoufflement',
    ],
    color: '#F5A623',
  },
  {
    profile: 'asthma',
    aqiLevel: 'sensitive',
    title: 'Précautions asthmatiques',
    actions: [
      'Restez à l\'intérieur, climatisation si possible',
      'Utilisez votre traitement de fond régulièrement',
      'Consultez immédiatement en cas de crise',
    ],
    color: '#FF7E00',
  },
  {
    profile: 'cardiac',
    aqiLevel: 'moderate',
    title: 'Attention cardiaques',
    actions: [
      'Évitez les efforts physiques intenses',
      'Surveillez tension et rythme cardiaque',
      'Ne sortez pas aux heures chaudes',
    ],
    color: '#F5A623',
  },
  {
    profile: 'outdoor',
    aqiLevel: 'unhealthy',
    title: 'Protection travailleurs extérieurs',
    actions: [
      'Portez un masque de protection FFP2',
      'Faites des pauses à l\'intérieur toutes les 2 heures',
      'Hydratez-vous abondamment',
    ],
    color: '#E53935',
  },
  {
    profile: 'athlete',
    aqiLevel: 'moderate',
    title: 'Ajustement sportif',
    actions: [
      'Réduisez l\'intensité de 50%',
      'Préférez l\'entraînement en salle',
      'Évitez les séances longues en extérieur',
    ],
    color: '#F5A623',
  },
];

export const STATIONS: Station[] = [
  {
    id: 'thies-centre',
    name: 'Thiès Centre',
    zone: 'Centre-ville',
    lat: 14.7885,
    lng: -16.9260,
    aqi: 142,
    type: 'residential',
    active: true,
    lastUpdate: new Date(),
    pollutants: [
      { id: 'pm25', name: 'PM2.5', unit: 'µg/m³', value: 38, whoLimit: 15, description: 'Particules fines' },
      { id: 'pm10', name: 'PM10', unit: 'µg/m³', value: 62, whoLimit: 45, description: 'Particules grossières' },
      { id: 'no2', name: 'NO₂', unit: 'µg/m³', value: 28, whoLimit: 25, description: 'Dioxyde d\'azote' },
      { id: 'so2', name: 'SO₂', unit: 'µg/m³', value: 12, whoLimit: 40, description: 'Dioxyde de soufre' },
      { id: 'o3', name: 'O₃', unit: 'µg/m³', value: 45, whoLimit: 100, description: 'Ozone' },
    ],
    weather: {
      temperature: 32,
      humidity: 68,
      windSpeed: 8,
      windDirection: 'NO',
      pressure: 1012,
      condition: 'Ensoleillé',
      icon: 'sun',
    },
  },
  {
    id: 'thies-industriel',
    name: 'Zone Industrielle',
    zone: 'Secteur industriel',
    lat: 14.8050,
    lng: -16.9100,
    aqi: 178,
    type: 'industrial',
    active: true,
    lastUpdate: new Date(),
    pollutants: [
      { id: 'pm25', name: 'PM2.5', unit: 'µg/m³', value: 52, whoLimit: 15, description: 'Particules fines' },
      { id: 'pm10', name: 'PM10', unit: 'µg/m³', value: 95, whoLimit: 45, description: 'Particules grossières' },
      { id: 'no2', name: 'NO₂', unit: 'µg/m³', value: 48, whoLimit: 25, description: 'Dioxyde d\'azote' },
      { id: 'so2', name: 'SO₂', unit: 'µg/m³', value: 35, whoLimit: 40, description: 'Dioxyde de soufre' },
      { id: 'o3', name: 'O₃', unit: 'µg/m³', value: 62, whoLimit: 100, description: 'Ozone' },
    ],
    weather: {
      temperature: 34,
      humidity: 62,
      windSpeed: 6,
      windDirection: 'O',
      pressure: 1010,
      condition: 'Ensoleillé',
      icon: 'sun',
    },
  },
  {
    id: 'thies-nord',
    name: 'Thiès Nord',
    zone: 'Quartier résidentiel nord',
    lat: 14.8100,
    lng: -16.9260,
    aqi: 68,
    type: 'residential',
    active: true,
    lastUpdate: new Date(),
    pollutants: [
      { id: 'pm25', name: 'PM2.5', unit: 'µg/m³', value: 18, whoLimit: 15, description: 'Particules fines' },
      { id: 'pm10', name: 'PM10', unit: 'µg/m³', value: 35, whoLimit: 45, description: 'Particules grossières' },
      { id: 'no2', name: 'NO₂', unit: 'µg/m³', value: 15, whoLimit: 25, description: 'Dioxyde d\'azote' },
      { id: 'so2', name: 'SO₂', unit: 'µg/m³', value: 6, whoLimit: 40, description: 'Dioxyde de soufre' },
      { id: 'o3', name: 'O₃', unit: 'µg/m³', value: 38, whoLimit: 100, description: 'Ozone' },
    ],
    weather: {
      temperature: 31,
      humidity: 72,
      windSpeed: 10,
      windDirection: 'N',
      pressure: 1014,
      condition: 'Partiellement nuageux',
      icon: 'cloud-sun',
    },
  },
  {
    id: 'thies-route',
    name: 'Route Dakar-Bamako',
    zone: 'Axes routiers',
    lat: 14.7750,
    lng: -16.9350,
    aqi: 156,
    type: 'road',
    active: true,
    lastUpdate: new Date(),
    pollutants: [
      { id: 'pm25', name: 'PM2.5', unit: 'µg/m³', value: 45, whoLimit: 15, description: 'Particules fines' },
      { id: 'pm10', name: 'PM10', unit: 'µg/m³', value: 78, whoLimit: 45, description: 'Particules grossières' },
      { id: 'no2', name: 'NO₂', unit: 'µg/m³', value: 42, whoLimit: 25, description: 'Dioxyde d\'azote' },
      { id: 'so2', name: 'SO₂', unit: 'µg/m³', value: 18, whoLimit: 40, description: 'Dioxyde de soufre' },
      { id: 'o3', name: 'O₃', unit: 'µg/m³', value: 50, whoLimit: 100, description: 'Ozone' },
    ],
    weather: {
      temperature: 33,
      humidity: 65,
      windSpeed: 7,
      windDirection: 'SO',
      pressure: 1011,
      condition: 'Ensoleillé',
      icon: 'sun',
    },
  },
  {
    id: 'thies-est',
    name: 'Thiès Est',
    zone: 'Zone est',
    lat: 14.7885,
    lng: -16.9050,
    aqi: 95,
    type: 'residential',
    active: true,
    lastUpdate: new Date(),
    pollutants: [
      { id: 'pm25', name: 'PM2.5', unit: 'µg/m³', value: 25, whoLimit: 15, description: 'Particules fines' },
      { id: 'pm10', name: 'PM10', unit: 'µg/m³', value: 48, whoLimit: 45, description: 'Particules grossières' },
      { id: 'no2', name: 'NO₂', unit: 'µg/m³', value: 22, whoLimit: 25, description: 'Dioxyde d\'azote' },
      { id: 'so2', name: 'SO₂', unit: 'µg/m³', value: 10, whoLimit: 40, description: 'Dioxyde de soufre' },
      { id: 'o3', name: 'O₃', unit: 'µg/m³', value: 42, whoLimit: 100, description: 'Ozone' },
    ],
    weather: {
      temperature: 31,
      humidity: 70,
      windSpeed: 9,
      windDirection: 'E',
      pressure: 1013,
      condition: 'Partiellement nuageux',
      icon: 'cloud-sun',
    },
  },
  {
    id: 'thies-sud',
    name: 'Thiès Sud',
    zone: 'Zone sud',
    lat: 14.7700,
    lng: -16.9260,
    aqi: 112,
    type: 'residential',
    active: true,
    lastUpdate: new Date(),
    pollutants: [
      { id: 'pm25', name: 'PM2.5', unit: 'µg/m³', value: 30, whoLimit: 15, description: 'Particules fines' },
      { id: 'pm10', name: 'PM10', unit: 'µg/m³', value: 55, whoLimit: 45, description: 'Particules grossières' },
      { id: 'no2', name: 'NO₂', unit: 'µg/m³', value: 26, whoLimit: 25, description: 'Dioxyde d\'azote' },
      { id: 'so2', name: 'SO₂', unit: 'µg/m³', value: 14, whoLimit: 40, description: 'Dioxyde de soufre' },
      { id: 'o3', name: 'O₃', unit: 'µg/m³', value: 48, whoLimit: 100, description: 'Ozone' },
    ],
    weather: {
      temperature: 32,
      humidity: 71,
      windSpeed: 8,
      windDirection: 'S',
      pressure: 1012,
      condition: 'Ensoleillé',
      icon: 'sun',
    },
  },
];

export const SAMPLE_ALERTS: Alert[] = [
  {
    id: 'alert-1',
    stationId: 'thies-industriel',
    stationName: 'Zone Industrielle',
    pollutant: 'PM2.5',
    value: 52,
    threshold: 15,
    level: 'unhealthy',
    timestamp: new Date(Date.now() - 1000 * 60 * 15),
    read: false,
    message: 'Dépassement du seuil OMS pour les particules fines PM2.5',
  },
  {
    id: 'alert-2',
    stationId: 'thies-route',
    stationName: 'Route Dakar-Bamako',
    pollutant: 'NO₂',
    value: 42,
    threshold: 25,
    level: 'unhealthy',
    timestamp: new Date(Date.now() - 1000 * 60 * 45),
    read: false,
    message: 'Pic de dioxyde d\'azote lié au trafic routier',
  },
  {
    id: 'alert-3',
    stationId: 'thies-centre',
    stationName: 'Thiès Centre',
    pollutant: 'PM10',
    value: 62,
    threshold: 45,
    level: 'sensitive',
    timestamp: new Date(Date.now() - 1000 * 60 * 120),
    read: true,
    message: 'Particules grossières au-dessus de la norme OMS',
  },
  {
    id: 'alert-4',
    stationId: 'thies-industriel',
    stationName: 'Zone Industrielle',
    pollutant: 'NO₂',
    value: 48,
    threshold: 25,
    level: 'unhealthy',
    timestamp: new Date(Date.now() - 1000 * 60 * 180),
    read: true,
    message: 'Concentration élevée en dioxyde d\'azote d\'origine industrielle',
  },
];

export const HISTORY_24H: HistoryPoint[] = Array.from({ length: 24 }, (_, i) => {
  const hour = i;
  const baseAQI = 90 + Math.sin((hour / 24) * Math.PI * 2) * 40 + Math.random() * 20;
  const basePM25 = baseAQI * 0.35 + Math.random() * 5;
  const basePM10 = baseAQI * 0.55 + Math.random() * 8;
  return {
    time: `${String(hour).padStart(2, '0')}:00`,
    aqi: Math.round(baseAQI),
    pm25: Math.round(basePM25),
    pm10: Math.round(basePM10),
  };
});

export const HISTORY_7D: HistoryPoint[] = Array.from({ length: 7 }, (_, i) => {
  const days = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
  const baseAQI = 100 + Math.sin(i * 0.8) * 35 + Math.random() * 15;
  return {
    time: days[i],
    aqi: Math.round(baseAQI),
    pm25: Math.round(baseAQI * 0.35),
    pm10: Math.round(baseAQI * 0.55),
  };
});

export const COLORS = {
  primary: '#0A6B3B',
  primaryDark: '#064A28',
  primaryLight: '#E8F5E9',
  secondary: '#0288D1',
  secondaryDark: '#01579B',
  secondaryLight: '#E1F5FE',
  accent: '#FF8F00',
  accentLight: '#FFF8E1',
  success: '#00C853',
  warning: '#FFAB00',
  error: '#D32F2F',
  background: '#F7F9FA',
  surface: '#FFFFFF',
  surfaceAlt: '#F0F4F5',
  text: '#1A1F23',
  textSecondary: '#5F6B72',
  textMuted: '#9BA8B0',
  border: '#E3E8EB',
  dark: '#0B1416',
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const RADIUS = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  pill: 999,
};

export const TYPOGRAPHY = {
  heading: 'Inter-Bold',
  body: 'Inter-Regular',
  medium: 'Inter-Medium',
  light: 'Inter-Light',
};
