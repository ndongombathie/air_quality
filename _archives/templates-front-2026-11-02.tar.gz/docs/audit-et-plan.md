# Audit et plan d'exécution

## État constaté

### Points déjà solides

- `senair.web/project` possède une navigation Expo Router structurée.
- Les écrans citoyens couvrent accueil, carte, alertes, santé, informations et articles.
- Les écrans admin couvrent stations, articles, prévisions, alertes et analytique.
- Les types de station, polluants, météo, alertes et prévisions existent déjà.
- Le cahier des charges et la présentation donnent une base métier cohérente.

### Écarts critiques

- `senair.mobile/App.tsx` affiche encore un écran de démarrage et n'utilise pas la feature SEN-AIR.
- `senair.web/project` et `project` sont des copies concurrentes.
- `useStations` utilise directement Supabase et fabrique un fallback silencieux.
- `lib/forecast.ts` produit des prévisions aléatoires côté client.
- Les données admin et alertes sont codées en dur dans `lib/adminData.ts`.
- Les migrations Supabase autorisent actuellement le CRUD à `anon`, ce qui est incompatible avec une administration sécurisée.
- L'authentification et la garde de rôle admin ne sont pas présentes dans les routes observées.
- L'architecture PWA n'est pas encore matérialisée par un manifest/service worker de production.

## Séquencement recommandé

1. Geler `senair.web/project` comme référence et marquer `project` comme archive.
2. Extraire `domain`, `data`, `security` et `theme` sans modifier le comportement visuel.
3. Remplacer les données aléatoires/fallbacks par des états explicitement `loading`, `error`, `stale`, `unavailable`.
4. Implémenter l'adaptateur API et les contrats de [api-contracts.md](./api-contracts.md).
5. Brancher articles, alertes et admin sur des endpoints autorisés.
6. Ajouter authentification, rôles et redirections admin.
7. Finaliser PWA/offline, accessibilité et notifications.
8. Ajouter les tests de contrat et les parcours critiques.

## Décision sur les templates

Ne pas supprimer physiquement les dossiers tant qu'un build et une validation de parcours n'ont pas confirmé le transfert. Après migration et archivage validés, `project` et les écrans morts de `senair.mobile` pourront être retirés dans une PR séparée, avec historique Git conservé.
