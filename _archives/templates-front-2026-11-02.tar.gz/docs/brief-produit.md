# Brief produit SEN-AIR

## Vision

SEN-AIR est une plateforme multi-sources de surveillance de la qualité de l'air à Thiès. Elle rend compréhensibles des mesures de capteurs, des données météorologiques, des estimations spatiales et des prévisions IA afin d'aider les citoyens, les personnes sensibles et les autorités à décider rapidement.

## Utilisateurs

| Profil | Besoin principal | Interface |
|---|---|---|
| Citoyen | Voir l'état actuel, comprendre le risque et recevoir des conseils | Mobile, web responsive/PWA |
| Personne sensible | Recevoir une information lisible et actionnable | Mobile prioritaire |
| Autorité/analyste | Suivre le réseau, les alertes, les prévisions et les tendances | Web admin |
| Administrateur | Gérer stations, seuils, contenus et comptes | Web admin sécurisé |

## Promesse fonctionnelle

1. Afficher l'IQA global et le polluant déterminant.
2. Visualiser les stations et les zones estimées sur une carte.
3. Comparer PM2.5, PM10, NO₂, SO₂, CO et O₃ aux référentiels configurés.
4. Consulter l'historique et les horizons de prévision 1 h, 2 h, 3 h, J+1, J+2 et J+3.
5. Recevoir des alertes sanitaires contextualisées, avec horodatage et source.
6. Donner des recommandations par profil de santé sans se substituer à un avis médical.
7. Publier des articles, rapports et informations depuis l'administration.

## Périmètre de cette itération

Inclus : `senair.mobile` et `senair.web`, navigation, composants UI, état client, cache hors-ligne, PWA, intégration API, parcours citoyen et administration.

Hors périmètre : modification du backend Python, ingestion capteurs, Kafka, stockage, entraînement des modèles, déploiement infrastructure. Les besoins backend sont spécifiés dans [api-contracts.md](./api-contracts.md).

## Règles métier visibles dans le front

- L'IQA est une valeur calculée par le backend ; le front ne doit pas recalculer une vérité concurrente.
- Les niveaux d'affichage sont : Bon, Modéré, Malsain pour groupes sensibles, Malsain, Très malsain, Dangereux.
- Chaque donnée doit afficher sa fraîcheur (`observedAt`/`updatedAt`) et son statut (`measured`, `estimated`, `forecast`).
- Une prévision doit afficher son horizon, sa confiance fournie par le modèle et sa provenance.
- Un conseil de santé doit rester informatif et inclure une mention de non-substitution médicale.

## MVP accepté

Accueil avec IQA, carte des stations, détail station, historique 24 h/7 j, alertes, santé, articles, authentification admin et tableau de bord stations/alertes/articles/prévisions. Les données simulées doivent être identifiées comme telles et ne doivent pas être présentées comme des mesures temps réel.
