# Architecture front cible

## Décision

Le template retenu est [senair.web/project](../senair.web/project). Il couvre déjà le plus grand nombre de cas d'usage : écrans citoyens, articles et routes `admin/*`. `project` et `senair.web/project` sont des copies concurrentes ; `project` doit être traité comme archive de référence et ne doit plus évoluer en parallèle. `senair.mobile` reste l'application native, mais son écran de démarrage vide doit être remplacé par une consommation de la même couche métier.

## Cible logique

```text
app/                    routes Expo Router uniquement
features/               cas d'usage par domaine
  air-quality/          IQA, polluants, stations, historique
  map/                  couches cartographiques et sélection de zone
  alerts/               alertes citoyennes et administration
  forecasts/            prévisions et provenance du modèle
  content/              articles et publications
  health/               profils et recommandations
  admin/                écrans de pilotage
components/             composants de présentation réutilisables
domain/                 types, règles de présentation, adaptateurs purs
data/                   clients API, DTO, cache, synchronisation
security/               session, rôles, permissions, redaction d'erreurs
theme/                  tokens, typographie, accessibilité
tests/                  contrats, composants, parcours
```

## Principes

- Les écrans orchestrent ; ils ne font pas d'appels réseau directs.
- Les DTO backend sont transformés par des adaptateurs typés avant d'atteindre les composants.
- Les règles de couleur et de libellé IQA sont centralisées dans `domain/air-quality`.
- Les composants restent présentatifs et réutilisables entre web et mobile.
- Les effets (réseau, stockage, notifications, navigation) sont isolés derrière des interfaces.
- Les états loading/empty/error/offline/stale sont explicites pour chaque feature.
- Les actions admin sont protégées par rôle côté API et contrôlées une seconde fois dans l'UI.

## Routes

Citoyen : `/`, `/map`, `/articles`, `/articles/[slug]`, `/alerts`, `/health`, `/info`.

Administration : `/admin`, `/admin/stations`, `/admin/articles`, `/admin/forecasts`, `/admin/alerts`, `/admin/analytics`.

Les routes admin doivent rediriger vers `/login` si la session ou le rôle requis est absent. La protection UI ne remplace jamais l'autorisation backend.

## PWA et mobile

- Web : manifest, icônes, service worker, cache lecture seule des dernières données, page offline et stratégie stale-while-revalidate.
- Mobile : cache local limité, rafraîchissement manuel, deep links, notifications push optionnelles et permissions demandées au moment utile.
- Cartographie : chargement différé, fallback liste si la carte n'est pas disponible, contraste compatible avec les niveaux IQA.
- Accessibilité : navigation clavier web, labels d'icônes, zones tactiles suffisantes, couleur jamais utilisée seule pour transmettre un niveau.

## Arborescence de migration proposée

La migration doit être incrémentale : extraire d'abord les types et adaptateurs sans casser les routes actuelles, puis déplacer une feature à la fois. Ne pas supprimer les templates avant validation des parcours et du build web/mobile.
