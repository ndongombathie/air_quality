# Données et hypothèses métier

## Sources observées

- Capteurs AirGradient : PM2.5, PM10, NO₂, CO, SO₂, O₃ et variables associées.
- Météo : température, humidité, vent, pression et précipitations selon disponibilité.
- Modèles : interpolation spatiale pour les zones sans capteur et prévisions temporelles jusqu'à J+3.
- Données locales : `projet-transversal/air_quality.csv` contient les mesures historiques ; `air_quality/data/air_quality_dataset.csv` sert d'échantillon.

## Entités front

Station, Reading, Pollutant, Weather, AQI, Forecast, Alert, Article, HealthProfile, User/AdminRole.

## Risques de cohérence identifiés

- Le code historique mélange `iqr` et IQA : le contrat canonique doit utiliser `aqi` et documenter l'alias legacy.
- Le code de prévision contient des valeurs générées aléatoirement : interdit en production et à remplacer par `/forecasts`.
- Des valeurs de repli fixes (`75`) peuvent masquer une panne : elles doivent être marquées `unavailable`/`stale`.
- Le seuil et le référentiel doivent venir de la configuration backend, pas de constantes divergentes dans plusieurs écrans.
- Les CSV comportent des valeurs vides : le front doit afficher absence de mesure, pas zéro.
