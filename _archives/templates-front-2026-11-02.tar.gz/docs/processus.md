# Processus de développement, qualité et sécurité

## Flux de livraison

1. Clarifier le besoin et le rôle utilisateur.
2. Écrire le contrat de données/API avant l'écran.
3. Implémenter domaine et adaptateur avec données de test déterministes.
4. Construire les composants accessibles puis l'écran responsive.
5. Vérifier mobile étroit, tablette et desktop.
6. Tester loading, empty, error, offline et stale.
7. Exécuter typecheck, lint, tests et build web.
8. Revoir sécurité, logs, permissions et dépendances.
9. Documenter le changement et publier une version.

## Règles SOLID/DRY

- Une feature possède une responsabilité métier claire.
- Les composants ne connaissent pas Supabase, Django ou Kafka.
- Une seule fonction traduit le statut IQA en libellé/couleur.
- Pas de duplication entre web et mobile : partager types, domaine et composants compatibles.
- Les fonctions de formatage sont pures et testables.
- Les interfaces permettent de remplacer l'API réelle par un mock.

## Sécurité

- Remplacer la politique actuelle de CRUD anonyme par lecture publique minimale et écritures admin authentifiées.
- Ne jamais committer `.env`, clés Supabase privilégiées ou tokens.
- Utiliser uniquement la clé publique côté client ; les opérations sensibles passent par le backend.
- Stocker la session avec les mécanismes sécurisés de la plateforme, avec expiration et rotation.
- Valider et encoder le contenu article avant rendu ; ne pas injecter du HTML non nettoyé.
- Limiter les données personnelles, journaliser les actions admin et éviter les valeurs sensibles dans les logs.
- Ajouter rate limiting, CORS strict, CSP web, headers de sécurité et protection contre replay côté API.

## Definition of Done

Une feature est terminée quand le contrat est documenté, les états UI sont couverts, le typecheck/lint/build passent, les tests ciblés passent, le parcours est vérifié sur web et mobile, les permissions sont confirmées côté serveur et la documentation est mise à jour.
