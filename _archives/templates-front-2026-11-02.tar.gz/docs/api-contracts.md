# Contrats API attendus du backend

Préfixe recommandé : `/api/v1`. Toutes les dates sont ISO-8601 UTC. Toutes les réponses d'erreur suivent `{ "code": string, "message": string, "details"?: object, "requestId": string }`.

## Lecture publique

| Méthode | Endpoint | Usage | Paramètres principaux |
|---|---|---|---|
| GET | `/stations` | Liste et état des stations | `bbox`, `zone`, `active`, `limit`, `cursor` |
| GET | `/stations/{stationId}` | Détail station | — |
| GET | `/stations/{stationId}/readings/latest` | Dernière mesure | `include=weather,pollutants` |
| GET | `/stations/{stationId}/readings` | Historique | `from`, `to`, `pollutant`, `granularity` |
| GET | `/air-quality/summary` | IQA ville/zone | `zoneId`, `at` |
| GET | `/air-quality/heatmap` | Points estimés/interpolés | `bbox`, `pollutant`, `at`, `resolution` |
| GET | `/forecasts` | Prévisions | `zoneId`, `stationId`, `horizons=1h,2h,3h,J+1,J+2,J+3` |
| GET | `/alerts` | Alertes publiées | `status`, `severity`, `from`, `to`, `cursor` |
| GET | `/articles` | Articles publiés | `category`, `cursor`, `featured` |
| GET | `/articles/{slug}` | Article public | — |
| GET | `/health-guidance` | Conseils par profil et niveau | `profile`, `aqiLevel` |
| GET | `/thresholds` | Référentiels OMS/Sénégal | `reference`, `pollutant` |
| GET | `/metadata` | Version des données et modèles | — |

## Authentification et administration

| Méthode | Endpoint | Rôle |
|---|---|---|
| POST | `/auth/login` | Ouverture session admin |
| POST | `/auth/refresh` | Renouvellement sécurisé |
| POST | `/auth/logout` | Révocation |
| GET | `/me` | Profil et permissions |
| PATCH | `/admin/stations/{id}` | `station_manager` |
| POST/PATCH/DELETE | `/admin/articles[/{id}]` | `content_manager` |
| PATCH | `/admin/alerts/{id}` | `alert_manager` |
| POST | `/admin/forecasts/recompute` | `analyst` |
| GET | `/admin/analytics/summary` | `analyst` |

## Schémas minimaux

`Station` : `id`, `name`, `zone`, `latitude`, `longitude`, `type`, `active`, `lastObservedAt`, `dataStatus`.

`Reading` : `stationId`, `observedAt`, `source`, `pollutants` (valeur/unité), `weather`, `aqi`, `aqiLevel`.

`Forecast` : `scope`, `scopeId`, `horizon`, `validAt`, `aqi`, `aqiLevel`, `confidence`, `drivers`, `modelVersion`, `generatedAt`.

`Alert` : `id`, `severity`, `status`, `pollutant`, `value`, `threshold`, `stationId/zoneId`, `startedAt`, `resolvedAt`, `message`, `recommendations`.

## Exigences non négociables

- Pagination par curseur pour listes évolutives.
- `ETag`/`Last-Modified` sur lectures cacheables.
- `requestId` pour corrélation support.
- Aucun secret ou rôle ne doit être déduit d'une valeur envoyée par le client.
- Les écritures admin exigent une authentification forte, une autorisation serveur, une validation de schéma et un audit.
- Le backend doit renvoyer un statut de fraîcheur plutôt que laisser le front inventer une mise à jour.
