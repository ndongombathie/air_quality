# Documentation SEN-AIR

Cette documentation décrit le périmètre front demandé : application mobile Expo/React Native et application web/PWA SEN-AIR. Le backend, le pipeline Kafka/ETL et les modèles IA sont considérés comme des systèmes externes à intégrer.

## Documents

- [Brief produit et décision d'architecture](./brief-produit.md)
- [Architecture front cible](./architecture-front.md)
- [Contrats API attendus du backend](./api-contracts.md)
- [Processus produit, qualité et sécurité](./processus.md)
- [Analyse des écarts et plan d'exécution](./audit-et-plan.md)
- [Données et hypothèses métier](./donnees-metier.md)

## Source de vérité front

Le socle retenu est [senair.web/project](../senair.web/project). Les composants partagés entre web et mobile doivent être extraits progressivement vers une couche `packages/ui`/`packages/domain` lorsque le monorepo sera mis en place. Aucun secret backend ne doit être embarqué dans une application cliente.
