import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { STATION_LOCATIONS, buildPollutants, buildWeather, aqiFromCategorie } from '@/constants/data';
import { Station, StationReading } from '@/types';

export function useStations() {
  const [stations, setStations] = useState<Station[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadStations = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fetchError } = await supabase
        .from('readings')
        .select('*')
        .order('timestamp', { ascending: false });

      if (fetchError) throw fetchError;

      const readings = data as StationReading[];
      const latestByStation = new Map<number, StationReading>();
      for (const r of readings) {
        if (!latestByStation.has(r.station_id)) {
          latestByStation.set(r.station_id, r);
        }
      }

      const stationList: Station[] = STATION_LOCATIONS.map((loc) => {
        const reading = latestByStation.get(loc.id);
        const aqi = reading?.iqr ?? aqiFromCategorie(reading?.categorie_iqa ?? 'Modérée');
        return {
          id: loc.id,
          name: loc.shortName,
          zone: loc.zone,
          lat: loc.lat,
          lng: loc.lng,
          aqi: Math.round(aqi),
          pollutants: reading ? buildPollutants(reading) : [],
          weather: reading ? buildWeather(reading) : buildWeather({} as StationReading),
          lastUpdate: reading ? new Date(reading.timestamp) : new Date(),
          type: loc.type,
          active: true,
        };
      });

      setStations(stationList);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erreur de chargement');
      const fallback: Station[] = STATION_LOCATIONS.map((loc) => ({
        id: loc.id,
        name: loc.shortName,
        zone: loc.zone,
        lat: loc.lat,
        lng: loc.lng,
        aqi: 75,
        pollutants: [],
        weather: buildWeather({} as StationReading),
        lastUpdate: new Date(),
        type: loc.type,
        active: true,
      }));
      setStations(fallback);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStations();
  }, [loadStations]);

  return { stations, loading, error, reload: loadStations };
}
