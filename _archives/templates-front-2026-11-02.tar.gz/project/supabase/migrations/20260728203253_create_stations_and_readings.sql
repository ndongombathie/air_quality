/*
# Create air quality stations and readings tables

1. New Tables
- `stations` — sensor locations across Thiès (9 real stations from project data)
  - id (int, primary key — matches location_id from source data)
  - location_name (text, e.g. "Thiès, Université Iba Der Thiam")
  - latitude, longitude (double precision)
  - type (text: industrial/residential/road/reference)
  - active (boolean, default true)
  - created_at (timestamptz)

- `readings` — air quality measurements from each station
  - id (uuid, primary key)
  - station_id (int, references stations)
  - pm25, pm10, temperature, humidity, co2, tvoc, co, no, no2, so2, o3, nh3 (double precision, nullable)
  - vitesse_vent, direction_vent (double precision)
  - iqr (double precision — computed AQI)
  - categorie_iqa (text — e.g. "Modérée", "Très mauvaise")
  - timestamp (timestamptz — measurement time)
  - created_at (timestamptz)

2. Security
- Single-tenant app (no sign-in). RLS enabled, anon+authenticated have full CRUD.
- Data is intentionally public/shared across the app.
*/

CREATE TABLE IF NOT EXISTS stations (
  id integer PRIMARY KEY,
  location_name text NOT NULL,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  type text NOT NULL DEFAULT 'residential',
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE stations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_stations" ON stations;
CREATE POLICY "anon_select_stations" ON stations FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_stations" ON stations;
CREATE POLICY "anon_insert_stations" ON stations FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_stations" ON stations;
CREATE POLICY "anon_update_stations" ON stations FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_stations" ON stations;
CREATE POLICY "anon_delete_stations" ON stations FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS readings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  station_id integer NOT NULL REFERENCES stations(id) ON DELETE CASCADE,
  pm25 double precision,
  pm10 double precision,
  temperature double precision,
  humidity double precision,
  co2 double precision,
  tvoc double precision,
  co double precision,
  no double precision,
  no2 double precision,
  so2 double precision,
  o3 double precision,
  nh3 double precision,
  vitesse_vent double precision,
  direction_vent double precision,
  iqr double precision,
  categorie_iqa text,
  timestamp timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE readings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_readings" ON readings;
CREATE POLICY "anon_select_readings" ON readings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_readings" ON readings;
CREATE POLICY "anon_insert_readings" ON readings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_readings" ON readings;
CREATE POLICY "anon_update_readings" ON readings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_readings" ON readings;
CREATE POLICY "anon_delete_readings" ON readings FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_readings_station_id ON readings(station_id);
CREATE INDEX IF NOT EXISTS idx_readings_timestamp ON readings(timestamp DESC);
