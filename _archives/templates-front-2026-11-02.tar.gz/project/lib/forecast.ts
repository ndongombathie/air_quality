import { Station, ForecastPoint, StationReading } from '@/types';
import { STATION_LOCATIONS } from '@/constants/data';

function haversine(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function interpolateAQI(
  targetLat: number,
  targetLng: number,
  stations: Station[]
): { aqi: number; confidence: number; interpolated: boolean } {
  if (stations.length === 0) return { aqi: 0, confidence: 0, interpolated: true };

  const stationsWithDist = stations
    .map((s) => ({ station: s, dist: haversine(targetLat, targetLng, s.lat, s.lng) }))
    .sort((a, b) => a.dist - b.dist);

  const nearest = stationsWithDist[0];
  if (nearest.dist < 0.1) {
    return { aqi: nearest.station.aqi, confidence: 1, interpolated: false };
  }

  const maxDist = 5;
  const weighted = stationsWithDist
    .filter((s) => s.dist < maxDist)
    .slice(0, 4)
    .map((s) => ({ aqi: s.station.aqi, weight: 1 / (s.dist + 0.1) }));

  if (weighted.length === 0) {
    return { aqi: nearest.station.aqi, confidence: 0.3, interpolated: true };
  }

  const totalWeight = weighted.reduce((sum, w) => sum + w.weight, 0);
  const aqi = weighted.reduce((sum, w) => sum + w.aqi * w.weight, 0) / totalWeight;
  const confidence = Math.max(0.3, 1 - nearest.dist / maxDist);

  return { aqi: Math.round(aqi), confidence, interpolated: true };
}

export function forecast5Min(stations: Station[]): ForecastPoint[] {
  const points: ForecastPoint[] = [];
  const now = new Date();

  for (let i = 1; i <= 5; i++) {
    const time = new Date(now.getTime() + i * 60000);
    const timeLabel = time.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

    const avgAQI = stations.reduce((sum, s) => sum + s.aqi, 0) / stations.length;
    const trend = Math.sin((i / 5) * Math.PI * 0.5) * 8;
    const noise = (Math.random() - 0.5) * 6;
    const forecastAQI = Math.max(0, Math.round(avgAQI + trend + noise));
    const confidence = Math.max(0.5, 1 - i * 0.08);

    points.push({
      time: timeLabel,
      aqi: forecastAQI,
      confidence,
      interpolated: false,
    });
  }

  return points;
}

export function forecastForLocation(
  lat: number,
  lng: number,
  stations: Station[]
): ForecastPoint[] {
  const interp = interpolateAQI(lat, lng, stations);
  const points: ForecastPoint[] = [];
  const now = new Date();

  for (let i = 1; i <= 5; i++) {
    const time = new Date(now.getTime() + i * 60000);
    const timeLabel = time.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

    const trend = Math.sin((i / 5) * Math.PI * 0.5) * 6;
    const noise = (Math.random() - 0.5) * 4;
    const forecastAQI = Math.max(0, Math.round(interp.aqi + trend + noise));
    const confidence = Math.max(0.3, interp.confidence - i * 0.06);

    points.push({
      time: timeLabel,
      aqi: forecastAQI,
      confidence,
      interpolated: interp.interpolated,
    });
  }

  return points;
}

export function readingToStation(
  stationId: number,
  reading: StationReading
): Station {
  const loc = STATION_LOCATIONS.find((s) => s.id === stationId);
  if (!loc) throw new Error(`Unknown station id: ${stationId}`);

  const aqi = reading.iqr ?? 50;
  const { buildPollutants, buildWeather } = require('@/constants/data');

  return {
    id: loc.id,
    name: loc.shortName,
    zone: loc.zone,
    lat: loc.lat,
    lng: loc.lng,
    aqi: Math.round(aqi),
    pollutants: buildPollutants(reading),
    weather: buildWeather(reading),
    lastUpdate: new Date(reading.timestamp),
    type: loc.type,
    active: true,
  };
}
