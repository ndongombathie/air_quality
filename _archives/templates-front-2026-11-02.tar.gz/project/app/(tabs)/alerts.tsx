import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, SAMPLE_ALERTS, getAQIInfo } from '@/constants/data';
import AlertItem from '@/components/AlertItem';
import SectionHeader from '@/components/SectionHeader';
import { Alert as AlertType } from '@/types';
import { Bell, BellOff, Settings, Check, ChevronRight } from 'lucide-react-native';
import { useStations } from '@/hooks/useStations';

export default function AlertsScreen() {
  const { stations } = useStations();
  const [alerts, setAlerts] = useState<AlertType[]>(SAMPLE_ALERTS);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');
  const [showSettings, setShowSettings] = useState(false);
  const [notifSettings, setNotifSettings] = useState({
    pushEnabled: true,
    smsEnabled: false,
    emailEnabled: true,
    thresholdAQI: 150,
    pollutantsPM25: true,
    pollutantsNO2: true,
    pollutantsO3: false,
    quietHours: false,
  });

  const filteredAlerts = filter === 'unread' ? alerts.filter((a) => !a.read) : alerts;
  const unreadCount = alerts.filter((a) => !a.read).length;

  const markAsRead = (id: string) => {
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, read: true } : a)));
  };

  const markAllRead = () => {
    setAlerts((prev) => prev.map((a) => ({ ...a, read: true })));
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Alertes</Text>
          <Text style={styles.headerSubtitle}>
            {unreadCount > 0 ? `${unreadCount} alerte${unreadCount > 1 ? 's' : ''} non lue${unreadCount > 1 ? 's' : ''}` : 'Toutes les alertes sont lues'}
          </Text>
        </View>
        <Pressable
          style={[styles.settingsBtn, showSettings && styles.settingsBtnActive]}
          onPress={() => setShowSettings(!showSettings)}
        >
          <Settings size={20} color={showSettings ? '#fff' : COLORS.text} strokeWidth={2.5} />
        </Pressable>
      </View>

      {/* Filter tabs */}
      <View style={styles.filterRow}>
        <Pressable
          style={[styles.tab, filter === 'all' && styles.tabActive]}
          onPress={() => setFilter('all')}
        >
          <Text style={[styles.tabText, filter === 'all' && styles.tabTextActive]}>
            Toutes ({alerts.length})
          </Text>
        </Pressable>
        <Pressable
          style={[styles.tab, filter === 'unread' && styles.tabActive]}
          onPress={() => setFilter('unread')}
        >
          <Text style={[styles.tabText, filter === 'unread' && styles.tabTextActive]}>
            Non lues ({unreadCount})
          </Text>
        </Pressable>
        {unreadCount > 0 && (
          <Pressable style={styles.markAllBtn} onPress={markAllRead}>
            <Check size={14} color={COLORS.primary} strokeWidth={2.5} />
            <Text style={styles.markAllText}>Tout marquer lu</Text>
          </Pressable>
        )}
      </View>

      {showSettings ? (
        <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
          <SectionHeader title="Paramètres de notification" subtitle="Configurez vos préférences d'alerte" />

          <View style={styles.settingsSection}>
            <Text style={styles.settingsSectionTitle}>Canaux de notification</Text>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <Bell size={20} color={COLORS.primary} strokeWidth={2} />
                <View>
                  <Text style={styles.settingLabel}>Notifications push</Text>
                  <Text style={styles.settingDesc}>Alertes en temps réel sur votre téléphone</Text>
                </View>
              </View>
              <Switch
                value={notifSettings.pushEnabled}
                onValueChange={(v) => setNotifSettings({ ...notifSettings, pushEnabled: v })}
                trackColor={{ false: COLORS.border, true: COLORS.primary }}
              />
            </View>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <Bell size={20} color={COLORS.secondary} strokeWidth={2} />
                <View>
                  <Text style={styles.settingLabel}>Email</Text>
                  <Text style={styles.settingDesc}>Résumé quotidien des alertes</Text>
                </View>
              </View>
              <Switch
                value={notifSettings.emailEnabled}
                onValueChange={(v) => setNotifSettings({ ...notifSettings, emailEnabled: v })}
                trackColor={{ false: COLORS.border, true: COLORS.primary }}
              />
            </View>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <BellOff size={20} color={COLORS.textMuted} strokeWidth={2} />
                <View>
                  <Text style={styles.settingLabel}>SMS</Text>
                  <Text style={styles.settingDesc}>Alertes critiques par SMS</Text>
                </View>
              </View>
              <Switch
                value={notifSettings.smsEnabled}
                onValueChange={(v) => setNotifSettings({ ...notifSettings, smsEnabled: v })}
                trackColor={{ false: COLORS.border, true: COLORS.primary }}
              />
            </View>
          </View>

          <View style={styles.settingsSection}>
            <Text style={styles.settingsSectionTitle}>Seuils d'alerte</Text>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <View style={styles.thresholdDisplay}>
                  <Text style={styles.thresholdValue}>{notifSettings.thresholdAQI}</Text>
                </View>
                <View>
                  <Text style={styles.settingLabel}>Seuil AQI</Text>
                  <Text style={styles.settingDesc}>Alerte quand l'AQI dépasse ce seuil</Text>
                </View>
              </View>
              <View style={styles.stepper}>
                <Pressable
                  style={styles.stepBtn}
                  onPress={() => setNotifSettings({ ...notifSettings, thresholdAQI: Math.max(50, notifSettings.thresholdAQI - 10) })}
                >
                  <Text style={styles.stepBtnText}>-</Text>
                </Pressable>
                <Pressable
                  style={styles.stepBtn}
                  onPress={() => setNotifSettings({ ...notifSettings, thresholdAQI: Math.min(300, notifSettings.thresholdAQI + 10) })}
                >
                  <Text style={styles.stepBtnText}>+</Text>
                </Pressable>
              </View>
            </View>
          </View>

          <View style={styles.settingsSection}>
            <Text style={styles.settingsSectionTitle}>Polluants surveillés</Text>
            {[
              { key: 'pollutantsPM25', label: 'Particules fines PM2.5', desc: 'Sources: combustion, trafic' },
              { key: 'pollutantsNO2', label: 'Dioxyde d\'azote NO₂', desc: 'Sources: trafic routier' },
              { key: 'pollutantsO3', label: 'Ozone O₃', desc: 'Sources: réaction photochimique' },
            ].map((p) => (
              <View key={p.key} style={styles.settingRow}>
                <View style={styles.settingLeft}>
                  <View style={styles.pollutantDot} />
                  <View>
                    <Text style={styles.settingLabel}>{p.label}</Text>
                    <Text style={styles.settingDesc}>{p.desc}</Text>
                  </View>
                </View>
                <Switch
                  value={notifSettings[p.key as keyof typeof notifSettings] as boolean}
                  onValueChange={(v) => setNotifSettings({ ...notifSettings, [p.key]: v })}
                  trackColor={{ false: COLORS.border, true: COLORS.primary }}
                />
              </View>
            ))}
          </View>

          <View style={styles.settingsSection}>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <BellOff size={20} color={COLORS.warning} strokeWidth={2} />
                <View>
                  <Text style={styles.settingLabel}>Heures silencieuses</Text>
                  <Text style={styles.settingDesc}>Pas de notifications de 22h à 6h</Text>
                </View>
              </View>
              <Switch
                value={notifSettings.quietHours}
                onValueChange={(v) => setNotifSettings({ ...notifSettings, quietHours: v })}
                trackColor={{ false: COLORS.border, true: COLORS.primary }}
              />
            </View>
          </View>

          <View style={{ height: 100 }} />
        </ScrollView>
      ) : (
        <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
          {filteredAlerts.length === 0 ? (
            <View style={styles.emptyState}>
              <BellOff size={48} color={COLORS.textMuted} strokeWidth={1.5} />
              <Text style={styles.emptyTitle}>Aucune alerte</Text>
              <Text style={styles.emptyDesc}>
                {filter === 'unread' ? 'Toutes les alertes ont été lues' : 'Aucune alerte pour le moment'}
              </Text>
            </View>
          ) : (
            <View style={styles.alertList}>
              {filteredAlerts.map((alert) => (
                <AlertItem key={alert.id} alert={alert} onPress={() => markAsRead(alert.id)} />
              ))}
            </View>
          )}

          {/* Active alerts summary */}
          <SectionHeader title="Surveillance active" subtitle={`${stations.length} stations monitorées`} />
          <View style={styles.summarySection}>
            {stations.map((s) => {
              const info = getAQIInfo(s.aqi);
              return (
                <View key={s.id} style={styles.summaryRow}>
                  <View style={[styles.summaryDot, { backgroundColor: info.color }]} />
                  <Text style={styles.summaryName} numberOfLines={1}>{s.name}</Text>
                  <Text style={[styles.summaryAQI, { color: info.color }]}>AQI {s.aqi}</Text>
                </View>
              );
            })}
          </View>

          <View style={{ height: 100 }} />
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
  },
  headerTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 22,
    color: COLORS.text,
  },
  headerSubtitle: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  settingsBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
  },
  settingsBtnActive: {
    backgroundColor: COLORS.primary,
  },
  filterRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingBottom: SPACING.sm,
    gap: SPACING.sm,
  },
  tab: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
    borderRadius: RADIUS.pill,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  tabActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  tabText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  tabTextActive: {
    color: '#fff',
  },
  markAllBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 'auto',
  },
  markAllText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.primary,
    marginLeft: 4,
  },
  container: {
    flex: 1,
  },
  alertList: {
    padding: SPACING.md,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: SPACING.xxl * 2,
  },
  emptyTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 18,
    color: COLORS.text,
    marginTop: SPACING.md,
  },
  emptyDesc: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 14,
    color: COLORS.textMuted,
    marginTop: 4,
    textAlign: 'center',
  },
  summarySection: {
    backgroundColor: COLORS.surface,
    marginHorizontal: SPACING.md,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.md,
  },
  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  summaryDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: SPACING.sm,
  },
  summaryName: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 13,
    color: COLORS.text,
    flex: 1,
    marginRight: SPACING.sm,
  },
  summaryAQI: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 14,
  },
  settingsSection: {
    backgroundColor: COLORS.surface,
    marginHorizontal: SPACING.md,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.md,
  },
  settingsSectionTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 14,
    color: COLORS.text,
    marginBottom: SPACING.sm,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingLabel: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 14,
    color: COLORS.text,
    flexShrink: 1,
  },
  settingDesc: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: COLORS.textMuted,
    marginTop: 2,
    flexShrink: 1,
  },
  thresholdDisplay: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: COLORS.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.sm,
  },
  thresholdValue: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 18,
    color: COLORS.primary,
  },
  stepper: {
    flexDirection: 'row',
    gap: SPACING.xs,
  },
  stepBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: COLORS.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepBtnText: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 18,
    color: COLORS.text,
  },
  pollutantDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: COLORS.secondary,
    marginRight: SPACING.sm,
  },
});
