import React, { useState, useMemo, useRef } from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView, Dimensions, Platform, Linking } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo, STATION_LOCATIONS } from '@/constants/data';
import { Station } from '@/types';
import StationDetailModal from '@/components/StationDetailModal';
import { useStations } from '@/hooks/useStations';
import { interpolateAQI, forecastForLocation } from '@/lib/forecast';
import ForecastCard from '@/components/ForecastCard';
import { MapPin, Layers, Navigation, Factory, Home, Route, Building2, Crosshair, Clock } from 'lucide-react-native';
import { WebView } from 'react-native-webview';

const { width } = Dimensions.get('window');

interface MapPin_ {
  lat: number;
  lng: number;
  aqi: number;
  name: string;
  color: string;
}

export default function MapScreen() {
  const { stations, loading, error } = useStations();
  const [selectedStation, setSelectedStation] = useState<Station | null>(null);
  const [filter, setFilter] = useState<'all' | 'industrial' | 'residential' | 'road'>('all');
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [showForecast, setShowForecast] = useState(false);
  const webViewRef = useRef<WebView>(null);

  const filteredStations = useMemo(() => {
    if (filter === 'all') return stations;
    return stations.filter((s) => s.type === filter);
  }, [filter, stations]);

  // Request user location
  const requestLocation = () => {
    if (Platform.OS === 'web') {
      if (!navigator.geolocation) {
        setLocationError('Géolocalisation non supportée sur ce navigateur');
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
          setLocationError(null);
          updateMapCenter(pos.coords.latitude, pos.coords.longitude);
        },
        (err) => {
          setLocationError('Position indisponible: ' + err.message);
        },
        { enableHighAccuracy: true, timeout: 10000 }
      );
    }
  };

  const updateMapCenter = (lat: number, lng: number) => {
    const js = `
      if (window.map) {
        window.map.setCenter({ lat: ${lat}, lng: ${lng} });
        new google.maps.Marker({
          position: { lat: ${lat}, lng: ${lng} },
          map: window.map,
          icon: { path: google.maps.SymbolPath.CIRCLE, scale: 8, fillColor: '#0288D1', fillOpacity: 1, strokeColor: '#fff', strokeWeight: 3 }
        });
      }
    `;
    webViewRef.current?.injectJavaScript(js);
  };

  // Build Google Maps HTML with station markers
  const mapHtml = useMemo(() => {
    const centerLat = userLocation?.lat ?? 14.7885;
    const centerLng = userLocation?.lng ?? -16.9260;
    const pins = filteredStations.map((s) => {
      const info = getAQIInfo(s.aqi);
      return `new google.maps.Marker({
        position: { lat: ${s.lat}, lng: ${s.lng} },
        map: map,
        label: { text: '${s.aqi}', color: '#fff', fontSize: '11px', fontWeight: 'bold' },
        icon: { path: google.maps.SymbolPath.CIRCLE, scale: 16, fillColor: '${info.color}', fillOpacity: 1, strokeColor: '#fff', strokeWeight: 2 }
      });`;
    }).join('\n');

    return `<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <style>
    body { margin: 0; padding: 0; }
    #map { width: 100vw; height: 100vh; }
  </style>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSYDummyKey&callback=initMap" async defer></script>
</head>
<body>
  <div id="map"></div>
  <script>
    function initMap() {
      window.map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: ${centerLat}, lng: ${centerLng} },
        zoom: 13,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: false
      });
      ${pins}
    }
  </script>
</body>
</html>`;
  }, [filteredStations, userLocation]);

  // Fallback: use an iframe embed (no API key needed for basic embed)
  const mapEmbedUrl = useMemo(() => {
    const centerLat = userLocation?.lat ?? 14.7885;
    const centerLng = userLocation?.lng ?? -16.9260;
    const delta = 0.04;
    const bbox = `${centerLng - delta}%2C${centerLat - delta}%2C${centerLng + delta}%2C${centerLat + delta}`;
    return `https://www.google.com/maps/embed/v1/view?key=AIzaSYDummyKey&center=${centerLat},${centerLng}&zoom=13`;
  }, [userLocation]);

  // Interpolation forecast for user location or city center
  const locationForecast = useMemo(() => {
    const lat = userLocation?.lat ?? 14.7885;
    const lng = userLocation?.lng ?? -16.9260;
    return forecastForLocation(lat, lng, stations);
  }, [userLocation, stations]);

  const interpResult = useMemo(() => {
    const lat = userLocation?.lat ?? 14.7885;
    const lng = userLocation?.lng ?? -16.9260;
    return interpolateAQI(lat, lng, stations);
  }, [userLocation, stations]);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Text style={styles.headerTitle} numberOfLines={1}>Carte des stations</Text>
          <Text style={styles.headerSubtitle} numberOfLines={1}>Thiès — Surveillance en temps réel</Text>
        </View>
        <Pressable style={styles.locateBtn} onPress={requestLocation}>
          <Crosshair size={18} color={COLORS.primary} strokeWidth={2.5} />
        </Pressable>
      </View>

      {/* Filter bar */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterBar} contentContainerStyle={styles.filterBarContent}>
        {([
          { key: 'all' as const, label: 'Toutes', icon: <Layers size={14} color="#fff" strokeWidth={2.5} /> },
          { key: 'industrial' as const, label: 'Industriel', icon: <Factory size={14} color="#fff" strokeWidth={2.5} /> },
          { key: 'residential' as const, label: 'Résidentiel', icon: <Home size={14} color="#fff" strokeWidth={2.5} /> },
          { key: 'road' as const, label: 'Trafic', icon: <Route size={14} color="#fff" strokeWidth={2.5} /> },
        ]).map((f) => (
          <Pressable
            key={f.key}
            style={[styles.filterChip, filter === f.key && styles.filterChipActive]}
            onPress={() => setFilter(f.key)}
          >
            {filter === f.key && f.icon}
            <Text style={[styles.filterText, filter === f.key && styles.filterTextActive]} numberOfLines={1}>
              {f.label}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      {/* Map container */}
      <View style={styles.mapContainer}>
        {loading ? (
          <View style={styles.mapLoading}>
            <Text style={styles.mapLoadingText}>Chargement de la carte...</Text>
          </View>
        ) : (
          <WebView
            ref={webViewRef}
            source={{
              html: `<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { width: 100%; height: 100%; overflow: hidden; }
    #map { width: 100%; height: 100%; }
  </style>
</head>
<body>
  <iframe
    src="https://maps.google.com/maps?q=${userLocation?.lat ?? 14.7885},${userLocation?.lng ?? -16.9260}&z=13&output=embed"
    width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen
  ></iframe>
</body>
</html>`,
            }}
            style={styles.mapWebView}
            javaScriptEnabled={true}
            scrollEnabled={false}
          />
        )}

        {/* Station markers overlay (pressable labels) */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.markerList}
          contentContainerStyle={styles.markerListContent}
        >
          {filteredStations.map((station) => {
            const info = getAQIInfo(station.aqi);
            return (
              <Pressable
                key={station.id}
                style={styles.markerChip}
                onPress={() => setSelectedStation(station)}
              >
                <View style={[styles.markerDot, { backgroundColor: info.color }]} />
                <Text style={styles.markerName} numberOfLines={1}>{station.name}</Text>
                <Text style={[styles.markerAQI, { color: info.color }]}>{station.aqi}</Text>
              </Pressable>
            );
          })}
        </ScrollView>

        {/* User location status */}
        {locationError && (
          <View style={styles.locationBanner}>
            <Text style={styles.locationBannerText} numberOfLines={2}>{locationError}</Text>
          </View>
        )}
        {userLocation && !locationError && (
          <View style={styles.locationBannerSuccess}>
            <Navigation size={14} color={COLORS.secondary} strokeWidth={2} />
            <Text style={styles.locationBannerTextSuccess} numberOfLines={1}>
              Position: {userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}
            </Text>
          </View>
        )}

        {/* Legend */}
        <View style={styles.legend}>
          <Text style={styles.legendTitle} numberOfLines={1}>Niveau AQI</Text>
          {[
            { label: '0-50 Bon', color: '#00E400' },
            { label: '51-100 Modéré', color: '#FFFF00' },
            { label: '101-150 Sensible', color: '#FF7E00' },
            { label: '151-200 Malsain', color: '#FF0000' },
            { label: '201+ Dangereux', color: '#8F3F97' },
          ].map((item) => (
            <View key={item.label} style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: item.color }]} />
              <Text style={styles.legendText} numberOfLines={1}>{item.label}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Forecast toggle */}
      <Pressable
        style={styles.forecastToggle}
        onPress={() => setShowForecast(!showForecast)}
      >
        <Clock size={16} color={COLORS.primary} strokeWidth={2} />
        <Text style={styles.forecastToggleText} numberOfLines={1}>
          {showForecast ? 'Masquer la prévision' : 'Voir la prévision (5 min)'}
        </Text>
      </Pressable>

      {/* Forecast section */}
      {showForecast && (
        <ScrollView style={styles.forecastSection} showsVerticalScrollIndicator={false}>
          <ForecastCard
            forecast={locationForecast}
            interpolated={interpResult.interpolated}
            locationLabel={
              userLocation
                ? `Votre position (${userLocation.lat.toFixed(4)}, ${userLocation.lng.toFixed(4)})`
                : 'Centre de Thiès (position par défaut)'
            }
          />
          <Text style={styles.forecastNote}>
            {interpResult.interpolated
              ? 'Cette zone n\'a pas de capteur direct. L\'AQI est estimé par interpolation des stations les plus proches.'
              : 'Cette zone est couverte par un capteur direct.'}
          </Text>
        </ScrollView>
      )}

      <StationDetailModal
        station={selectedStation}
        visible={!!selectedStation}
        onClose={() => setSelectedStation(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
  },
  headerLeft: {
    flex: 1,
    marginRight: SPACING.sm,
  },
  headerTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 20,
    color: COLORS.text,
  },
  headerSubtitle: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  locateBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  filterBar: {
    maxHeight: 44,
    paddingBottom: SPACING.sm,
  },
  filterBarContent: {
    paddingHorizontal: SPACING.md,
    gap: SPACING.xs,
    alignItems: 'center',
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical: 7,
    borderRadius: RADIUS.pill,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  filterChipActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  filterText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  filterTextActive: {
    color: '#fff',
    marginLeft: 4,
  },
  mapContainer: {
    flex: 1,
    position: 'relative',
    backgroundColor: '#E8EAED',
    overflow: 'hidden',
  },
  mapWebView: {
    flex: 1,
  },
  mapLoading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapLoadingText: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 14,
    color: COLORS.textMuted,
  },
  markerList: {
    position: 'absolute',
    bottom: SPACING.sm,
    left: 0,
    right: 0,
    maxHeight: 50,
  },
  markerListContent: {
    paddingHorizontal: SPACING.md,
    gap: SPACING.xs,
    alignItems: 'center',
  },
  markerChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderRadius: RADIUS.pill,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
    gap: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 3,
  },
  markerDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  markerName: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 11,
    color: COLORS.text,
    maxWidth: 100,
  },
  markerAQI: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 13,
  },
  locationBanner: {
    position: 'absolute',
    top: SPACING.sm,
    left: SPACING.md,
    right: SPACING.md,
    backgroundColor: 'rgba(211, 47, 47, 0.9)',
    borderRadius: RADIUS.sm,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
  },
  locationBannerText: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: '#fff',
  },
  locationBannerSuccess: {
    position: 'absolute',
    top: SPACING.sm,
    left: SPACING.md,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(2, 136, 209, 0.9)',
    borderRadius: RADIUS.sm,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
    gap: 4,
  },
  locationBannerTextSuccess: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: '#fff',
  },
  legend: {
    position: 'absolute',
    top: SPACING.sm,
    right: SPACING.sm,
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderRadius: RADIUS.md,
    padding: SPACING.sm,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
  },
  legendTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 11,
    color: COLORS.text,
    marginBottom: 6,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 6,
  },
  legendText: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 10,
    color: COLORS.textSecondary,
  },
  forecastToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: SPACING.sm,
    backgroundColor: COLORS.surface,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
    gap: 6,
  },
  forecastToggleText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 13,
    color: COLORS.primary,
  },
  forecastSection: {
    maxHeight: 280,
    backgroundColor: COLORS.background,
    padding: SPACING.md,
  },
  forecastNote: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: COLORS.textMuted,
    textAlign: 'center',
    marginTop: SPACING.xs,
    lineHeight: 16,
  },
});
