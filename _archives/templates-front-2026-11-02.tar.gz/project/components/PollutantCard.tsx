import React from 'react';
import { View, Text, StyleSheet, ViewStyle } from 'react-native';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY } from '@/constants/data';
import { Pollutant } from '@/types';

interface PollutantCardProps {
  pollutant: Pollutant;
  style?: ViewStyle;
}

export default function PollutantCard({ pollutant, style }: PollutantCardProps) {
  const ratio = pollutant.value / pollutant.whoLimit;
  const isOverLimit = ratio > 1;
  const isCritical = ratio > 2;

  const statusColor = isCritical ? COLORS.error : isOverLimit ? COLORS.warning : COLORS.success;
  const statusBg = isCritical ? '#FFEBEE' : isOverLimit ? '#FFF8E1' : '#E8F5E9';
  const statusLabel = isCritical ? 'Critique' : isOverLimit ? 'Au-dessus OMS' : 'Conforme OMS';

  return (
    <View style={[styles.card, { borderLeftColor: statusColor }, style]}>
      <View style={styles.header}>
        <Text style={styles.name}>{pollutant.name}</Text>
        <View style={[styles.badge, { backgroundColor: statusBg }]}>
          <View style={[styles.dot, { backgroundColor: statusColor }]} />
          <Text style={[styles.badgeText, { color: statusColor }]}>{statusLabel}</Text>
        </View>
      </View>
      <View style={styles.valueRow}>
        <Text style={styles.value}>{pollutant.value}</Text>
        <Text style={styles.unit}>{pollutant.unit}</Text>
      </View>
      <Text style={styles.description}>{pollutant.description}</Text>
      <View style={styles.barContainer}>
        <View style={styles.barBackground} />
        <View
          style={[
            styles.barFill,
            {
              width: `${Math.min(ratio * 50, 100)}%`,
              backgroundColor: statusColor,
            },
          ]}
        />
        <View
          style={[
            styles.barMarker,
            { left: '50%' },
          ]}
        />
      </View>
      <Text style={styles.whoLimit}>Seuil OMS: {pollutant.whoLimit} {pollutant.unit}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    borderLeftWidth: 4,
    marginBottom: SPACING.sm,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
  },
  name: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 16,
    color: COLORS.text,
    flex: 1,
    flexShrink: 1,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.xs,
    borderRadius: RADIUS.pill,
    flexShrink: 1,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 6,
  },
  badgeText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 9,
    flexShrink: 1,
  },
  valueRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 4,
  },
  value: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 32,
    color: COLORS.text,
  },
  unit: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 14,
    color: COLORS.textMuted,
    marginLeft: SPACING.xs,
  },
  description: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    color: COLORS.textSecondary,
    marginBottom: SPACING.sm,
    flexShrink: 1,
  },
  barContainer: {
    height: 8,
    borderRadius: 4,
    position: 'relative',
    marginBottom: SPACING.xs,
  },
  barBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: COLORS.surfaceAlt,
    borderRadius: 4,
  },
  barFill: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    borderRadius: 4,
  },
  barMarker: {
    position: 'absolute',
    top: -2,
    bottom: -2,
    width: 2,
    backgroundColor: COLORS.textMuted,
    borderRadius: 1,
  },
  whoLimit: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 10,
    color: COLORS.textMuted,
    flexShrink: 1,
  },
});
