import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo } from '@/constants/data';
import { AlertTriangle, X, Bell } from 'lucide-react-native';

interface AlertBannerProps {
  aqi: number;
  stationName: string;
  onDismiss?: () => void;
  onPress?: () => void;
}

export default function AlertBanner({ aqi, stationName, onDismiss, onPress }: AlertBannerProps) {
  const info = getAQIInfo(aqi);

  if (aqi <= 100) return null;

  return (
    <Pressable
      style={({ pressed }) => [
        styles.container,
        { backgroundColor: info.bgColor, borderColor: info.color },
        pressed && styles.pressed,
      ]}
      onPress={onPress}
    >
      <View style={[styles.iconWrap, { backgroundColor: info.color }]}>
        <AlertTriangle size={22} color="#fff" strokeWidth={2.5} />
      </View>
      <View style={styles.content}>
        <Text style={[styles.title, { color: info.textColor }]}>
          {info.level === 'hazardous' ? 'Alerte danger' : info.level === 'very_unhealthy' ? 'Alerte sanitaire' : 'Alerte qualité de l\'air'}
        </Text>
        <Text style={[styles.message, { color: info.textColor }]}>
          {stationName} — AQI {aqi} ({info.labelFr})
        </Text>
      </View>
      {onDismiss && (
        <Pressable style={styles.dismiss} onPress={onDismiss} hitSlop={12}>
          <X size={18} color={info.textColor} strokeWidth={2.5} />
        </Pressable>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    borderWidth: 1.5,
    marginHorizontal: SPACING.md,
    marginBottom: SPACING.md,
  },
  pressed: {
    opacity: 0.85,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.sm,
  },
  content: {
    flex: 1,
  },
  title: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 15,
    marginBottom: 2,
  },
  message: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    opacity: 0.85,
  },
  dismiss: {
    padding: SPACING.xs,
  },
});
