import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo } from '@/constants/data';
import { Station } from '@/types';
import { MapPin, Factory, Home, Route, Building2, ChevronRight } from 'lucide-react-native';

interface StationCardProps {
  station: Station;
  onPress?: () => void;
}

export default function StationCard({ station, onPress }: StationCardProps) {
  const info = getAQIInfo(station.aqi);

  const getTypeIcon = () => {
    switch (station.type) {
      case 'industrial': return <Factory size={16} color={COLORS.textSecondary} strokeWidth={2} />;
      case 'residential': return <Home size={16} color={COLORS.textSecondary} strokeWidth={2} />;
      case 'road': return <Route size={16} color={COLORS.textSecondary} strokeWidth={2} />;
      case 'reference': return <Building2 size={16} color={COLORS.textSecondary} strokeWidth={2} />;
    }
  };

  return (
    <Pressable
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
      onPress={onPress}
    >
      <View style={[styles.leftBar, { backgroundColor: info.color }]} />
      <View style={styles.content}>
        <View style={styles.header}>
          <View style={styles.titleRow}>
            {getTypeIcon()}
            <Text style={styles.name} numberOfLines={1}>{station.name}</Text>
          </View>
          <View style={[styles.aqiBadge, { backgroundColor: info.color }]}>
            <Text style={styles.aqiText}>{station.aqi}</Text>
          </View>
        </View>
        <View style={styles.footer}>
          <View style={styles.zoneRow}>
            <MapPin size={12} color={COLORS.textMuted} strokeWidth={2} />
            <Text style={styles.zone}>{station.zone}</Text>
          </View>
          <Text style={styles.status}>{info.labelFr}</Text>
        </View>
      </View>
      <ChevronRight size={20} color={COLORS.textMuted} strokeWidth={2} style={styles.chevron} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    marginBottom: SPACING.sm,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  pressed: {
    opacity: 0.85,
  },
  leftBar: {
    width: 5,
    alignSelf: 'stretch',
  },
  content: {
    flex: 1,
    padding: SPACING.md,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.xs,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  name: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 15,
    color: COLORS.text,
    marginLeft: SPACING.xs,
  },
  aqiBadge: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  aqiText: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 15,
    color: '#fff',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  zoneRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  zone: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    color: COLORS.textMuted,
    marginLeft: 4,
  },
  status: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  chevron: {
    marginRight: SPACING.md,
  },
});
