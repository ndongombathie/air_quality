import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY } from '@/constants/data';
import { WeatherData } from '@/types';
import { Sun, CloudSun, Cloud, CloudRain, Wind, Droplets, Compass, Gauge } from 'lucide-react-native';

interface WeatherCardProps {
  weather: WeatherData;
}

export default function WeatherCard({ weather }: WeatherCardProps) {
  const getWeatherIcon = () => {
    switch (weather.icon) {
      case 'sun': return <Sun size={28} color={COLORS.accent} strokeWidth={2} />;
      case 'cloud-sun': return <CloudSun size={28} color={COLORS.secondary} strokeWidth={2} />;
      case 'cloud': return <Cloud size={28} color={COLORS.textSecondary} strokeWidth={2} />;
      case 'cloud-rain': return <CloudRain size={28} color={COLORS.secondary} strokeWidth={2} />;
      default: return <Sun size={28} color={COLORS.accent} strokeWidth={2} />;
    }
  };

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <View style={styles.iconWrap}>{getWeatherIcon()}</View>
        <View>
          <Text style={styles.condition}>{weather.condition}</Text>
          <Text style={styles.temp}>{weather.temperature}°C</Text>
        </View>
      </View>
      <View style={styles.metrics}>
        <View style={styles.metric}>
          <Droplets size={16} color={COLORS.secondary} strokeWidth={2} />
          <Text style={styles.metricLabel}>Humidité</Text>
          <Text style={styles.metricValue}>{weather.humidity}%</Text>
        </View>
        <View style={styles.metric}>
          <Wind size={16} color={COLORS.primary} strokeWidth={2} />
          <Text style={styles.metricLabel}>Vent</Text>
          <Text style={styles.metricValue}>{weather.windSpeed} km/h</Text>
        </View>
        <View style={styles.metric}>
          <Compass size={16} color={COLORS.accent} strokeWidth={2} />
          <Text style={styles.metricLabel}>Direction</Text>
          <Text style={styles.metricValue}>{weather.windDirection}</Text>
        </View>
        <View style={styles.metric}>
          <Gauge size={16} color={COLORS.textSecondary} strokeWidth={2} />
          <Text style={styles.metricLabel}>Pression</Text>
          <Text style={styles.metricValue}>{weather.pressure} hPa</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  iconWrap: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.surfaceAlt,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.sm,
  },
  condition: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 15,
    color: COLORS.text,
  },
  temp: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 24,
    color: COLORS.text,
  },
  metrics: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  metric: {
    alignItems: 'center',
    flex: 1,
  },
  metricLabel: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: COLORS.textMuted,
    marginTop: 4,
  },
  metricValue: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 13,
    color: COLORS.text,
    marginTop: 2,
  },
});
