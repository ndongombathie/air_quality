import React from 'react';
import { View, Text, StyleSheet, Pressable, Modal, ScrollView } from 'react-native';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo } from '@/constants/data';
import { Station } from '@/types';
import { X, MapPin, Factory, Home, Route, Building2, Wind, Droplets, Compass, Gauge, Clock } from 'lucide-react-native';
import PollutantCard from './PollutantCard';

interface StationDetailModalProps {
  station: Station | null;
  visible: boolean;
  onClose: () => void;
}

export default function StationDetailModal({ station, visible, onClose }: StationDetailModalProps) {
  if (!station) return null;
  const info = getAQIInfo(station.aqi);

  const getTypeIcon = () => {
    switch (station.type) {
      case 'industrial': return <Factory size={16} color="#fff" strokeWidth={2} />;
      case 'residential': return <Home size={16} color="#fff" strokeWidth={2} />;
      case 'road': return <Route size={16} color="#fff" strokeWidth={2} />;
      case 'reference': return <Building2 size={16} color="#fff" strokeWidth={2} />;
    }
  };

  const typeLabel = {
    industrial: 'Zone industrielle',
    residential: 'Zone résidentielle',
    road: 'Trafic routier',
    reference: 'Station de référence',
  }[station.type];

  return (
    <Modal visible={visible} animationType="slide" transparent={true} onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={styles.sheet}>
          <View style={styles.handle} />
          <ScrollView showsVerticalScrollIndicator={false} style={styles.scroll}>
            <View style={styles.header}>
              <View style={styles.headerLeft}>
                <View style={[styles.typeBadge, { backgroundColor: info.color }]}>
                  {getTypeIcon()}
                </View>
                <View style={styles.headerText}>
                  <Text style={styles.stationName} numberOfLines={2}>{station.name}</Text>
                  <View style={styles.zoneRow}>
                    <MapPin size={12} color={COLORS.textMuted} strokeWidth={2} />
                    <Text style={styles.zone} numberOfLines={1}>{station.zone}</Text>
                  </View>
                </View>
              </View>
              <Pressable style={styles.closeBtn} onPress={onClose} hitSlop={12}>
                <X size={22} color={COLORS.textSecondary} strokeWidth={2.5} />
              </Pressable>
            </View>

            <View style={styles.typeRow}>
              <Text style={styles.typeLabel}>{typeLabel}</Text>
            </View>

            {/* AQI Summary */}
            <View style={[styles.aqiSummary, { backgroundColor: info.bgColor, borderColor: info.color }]}>
              <View style={[styles.aqiCircle, { backgroundColor: info.color }]}>
                <Text style={styles.aqiNum}>{station.aqi}</Text>
              </View>
              <View style={styles.aqiTextWrap}>
                <Text style={[styles.aqiStatus, { color: info.textColor }]} numberOfLines={1}>
                  {info.labelFr}
                </Text>
                <Text style={[styles.aqiDesc, { color: info.textColor }]}>
                  {info.level === 'good' && 'Aucun risque pour la santé'}
                  {info.level === 'moderate' && 'Risque limité pour les personnes sensibles'}
                  {info.level === 'sensitive' && 'Risque pour les groupes sensibles'}
                  {info.level === 'unhealthy' && 'Risque pour toute la population'}
                  {info.level === 'very_unhealthy' && 'Alerte sanitaire'}
                  {info.level === 'hazardous' && 'Danger immédiat'}
                </Text>
              </View>
            </View>

            {/* Weather */}
            <Text style={styles.sectionTitle}>Conditions météo</Text>
            <View style={styles.weatherGrid}>
              <View style={styles.weatherItem}>
                <Droplets size={18} color={COLORS.secondary} strokeWidth={2} />
                <Text style={styles.weatherLabel}>Humidité</Text>
                <Text style={styles.weatherValue}>{station.weather.humidity}%</Text>
              </View>
              <View style={styles.weatherItem}>
                <Wind size={18} color={COLORS.primary} strokeWidth={2} />
                <Text style={styles.weatherLabel}>Vent</Text>
                <Text style={styles.weatherValue}>{station.weather.windSpeed} km/h</Text>
              </View>
              <View style={styles.weatherItem}>
                <Compass size={18} color={COLORS.accent} strokeWidth={2} />
                <Text style={styles.weatherLabel}>Direction</Text>
                <Text style={styles.weatherValue}>{station.weather.windDirection}</Text>
              </View>
              <View style={styles.weatherItem}>
                <Gauge size={18} color={COLORS.textSecondary} strokeWidth={2} />
                <Text style={styles.weatherLabel}>Pression</Text>
                <Text style={styles.weatherValue}>{station.weather.pressure} hPa</Text>
              </View>
            </View>

            {/* Pollutants */}
            <Text style={styles.sectionTitle}>Polluants mesurés</Text>
            {station.pollutants.map((p) => (
              <PollutantCard key={p.id} pollutant={p} />
            ))}

            <View style={styles.updateRow}>
              <Clock size={14} color={COLORS.textMuted} strokeWidth={2} />
              <Text style={styles.updateText}>
                Dernière mise à jour: {station.lastUpdate.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
              </Text>
            </View>

            <View style={{ height: 40 }} />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: COLORS.background,
    borderTopLeftRadius: RADIUS.xl,
    borderTopRightRadius: RADIUS.xl,
    maxHeight: '90%',
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: COLORS.border,
    alignSelf: 'center',
    marginTop: SPACING.sm,
    marginBottom: SPACING.xs,
  },
  scroll: {
    paddingHorizontal: SPACING.md,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: SPACING.xs,
  },
  headerLeft: {
    flexDirection: 'row',
    flex: 1,
    paddingRight: SPACING.md,
  },
  typeBadge: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.sm,
  },
  headerText: {
    flex: 1,
    flexShrink: 1,
  },
  aqiTextWrap: {
    flex: 1,
    flexShrink: 1,
  },
  stationName: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 18,
    color: COLORS.text,
    marginBottom: 2,
    flexShrink: 1,
  },
  zoneRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  zone: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    color: COLORS.textMuted,
    marginLeft: 4,
  },
  closeBtn: {
    padding: SPACING.xs,
  },
  typeRow: {
    marginBottom: SPACING.md,
  },
  typeLabel: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.textSecondary,
    backgroundColor: COLORS.surfaceAlt,
    alignSelf: 'flex-start',
    paddingHorizontal: SPACING.sm,
    paddingVertical: 4,
    borderRadius: RADIUS.sm,
  },
  aqiSummary: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    borderWidth: 1.5,
    marginBottom: SPACING.lg,
  },
  aqiCircle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.md,
  },
  aqiNum: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 28,
    color: '#fff',
  },
  aqiStatus: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 17,
    marginBottom: 4,
  },
  aqiDesc: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    opacity: 0.85,
    flex: 1,
    flexWrap: 'wrap',
  },
  sectionTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 16,
    color: COLORS.text,
    marginBottom: SPACING.sm,
    marginTop: SPACING.sm,
  },
  weatherGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: SPACING.md,
  },
  weatherItem: {
    width: '48%',
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.sm,
    marginBottom: SPACING.sm,
  },
  weatherLabel: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    color: COLORS.textMuted,
    marginLeft: SPACING.sm,
  },
  weatherValue: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.text,
    marginLeft: 'auto',
  },
  updateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: SPACING.md,
  },
  updateText: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    color: COLORS.textMuted,
    marginLeft: 6,
  },
});
