import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo } from '@/constants/data';
import { Alert } from '@/types';
import { Bell, BellOff, AlertTriangle, Clock } from 'lucide-react-native';

interface AlertItemProps {
  alert: Alert;
  onPress?: () => void;
}

export default function AlertItem({ alert, onPress }: AlertItemProps) {
  const info = getAQIInfo(alert.value > 150 ? alert.value : 100 + (alert.value / alert.threshold) * 50);
  const timeAgo = getTimeAgo(alert.timestamp);

  return (
    <Pressable
      style={({ pressed }) => [
        styles.container,
        !alert.read && styles.unread,
        pressed && styles.pressed,
      ]}
      onPress={onPress}
    >
      <View style={[styles.iconWrap, { backgroundColor: info.bgColor }]}>
        <AlertTriangle size={20} color={info.color} strokeWidth={2.5} />
      </View>
      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.stationName} numberOfLines={1}>{alert.stationName}</Text>
          {!alert.read && <View style={styles.unreadDot} />}
        </View>
        <Text style={styles.message} numberOfLines={2}>{alert.message}</Text>
        <View style={styles.footer}>
          <View style={styles.tagRow}>
            <View style={[styles.tag, { backgroundColor: info.bgColor }]}>
              <Text style={[styles.tagText, { color: info.textColor }]}>{alert.pollutant}</Text>
            </View>
            <Text style={styles.value}>
              {alert.value} / {alert.threshold} µg/m³
            </Text>
          </View>
          <View style={styles.timeRow}>
            <Clock size={12} color={COLORS.textMuted} strokeWidth={2} />
            <Text style={styles.time}>{timeAgo}</Text>
          </View>
        </View>
      </View>
    </Pressable>
  );
}

function getTimeAgo(date: Date): string {
  const diff = Date.now() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return 'à l\'instant';
  if (minutes < 60) return `il y a ${minutes} min`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `il y a ${hours}h`;
  const days = Math.floor(hours / 24);
  return `il y a ${days}j`;
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginBottom: SPACING.sm,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  unread: {
    borderLeftWidth: 3,
    borderLeftColor: COLORS.secondary,
  backgroundColor: '#FAFCFF',
  },
  pressed: {
    opacity: 0.85,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.sm,
  },
  content: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  stationName: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 15,
    color: COLORS.text,
    flex: 1,
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: COLORS.secondary,
    marginLeft: SPACING.xs,
  },
  message: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    color: COLORS.textSecondary,
    marginBottom: SPACING.xs,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  tagRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tag: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: 2,
    borderRadius: RADIUS.sm,
    marginRight: SPACING.sm,
  },
  tagText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 11,
  },
  value: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    color: COLORS.textMuted,
  },
  timeRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  time: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: COLORS.textMuted,
    marginLeft: 4,
  },
});
