import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo } from '@/constants/data';
import Svg, { Circle, Path } from 'react-native-svg';

const { width } = Dimensions.get('window');
const GAUGE_SIZE = Math.min(width * 0.62, 240);
const STROKE_WIDTH = 16;
const RADIUS_VAL = (GAUGE_SIZE - STROKE_WIDTH) / 2;
const CIRCUMFERENCE = RADIUS_VAL * Math.PI; // semicircle

interface AQIGaugeProps {
  aqi: number;
  size?: number;
  showLabel?: boolean;
}

export default function AQIGauge({ aqi, size, showLabel = true }: AQIGaugeProps) {
  const info = getAQIInfo(aqi);
  const gaugeSize = size ?? GAUGE_SIZE;
  const strokeWidth = size ? size * 0.067 : STROKE_WIDTH;
  const radius = (gaugeSize - strokeWidth) / 2;
  const circumference = radius * Math.PI;

  // AQI 0-300 mapped to 0-180 degrees
  const maxAQI = 300;
  const clampedAQI = Math.min(aqi, maxAQI);
  const progress = clampedAQI / maxAQI;
  const dashOffset = circumference * (1 - progress);

  const center = gaugeSize / 2;

  return (
    <View style={[styles.container, { width: gaugeSize, height: gaugeSize * 0.6 }]}>
      <Svg width={gaugeSize} height={gaugeSize * 0.6} viewBox={`0 0 ${gaugeSize} ${gaugeSize * 0.6}`}>
        {/* Background arc */}
        <Path
          d={`M ${strokeWidth / 2} ${gaugeSize * 0.6 - strokeWidth / 2}
              A ${radius} ${radius} 0 0 1 ${gaugeSize - strokeWidth / 2} ${gaugeSize * 0.6 - strokeWidth / 2}`}
          fill="none"
          stroke={COLORS.border}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
        />
        {/* Progress arc */}
        <Path
          d={`M ${strokeWidth / 2} ${gaugeSize * 0.6 - strokeWidth / 2}
              A ${radius} ${radius} 0 0 1 ${gaugeSize - strokeWidth / 2} ${gaugeSize * 0.6 - strokeWidth / 2}`}
          fill="none"
          stroke={info.color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={`${circumference} ${circumference}`}
          strokeDashoffset={dashOffset}
        />
      </Svg>
      <View style={styles.valueContainer}>
        <Text style={[styles.aqiValue, { color: info.color }]}>{aqi}</Text>
        {showLabel && (
          <Text style={[styles.aqiLabel, { color: info.textColor }]}>
            {info.labelFr}
          </Text>
        )}
        <Text style={styles.aqiUnit}>Indice de qualité de l'air</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  valueContainer: {
    position: 'absolute',
    bottom: 0,
    alignItems: 'center',
  },
  aqiValue: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 56,
    fontWeight: '700',
    lineHeight: 64,
  },
  aqiLabel: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 16,
    marginTop: SPACING.xs,
  },
  aqiUnit: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: COLORS.textMuted,
    marginTop: 2,
  },
});
