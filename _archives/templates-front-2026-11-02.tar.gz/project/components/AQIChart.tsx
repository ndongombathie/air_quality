import React from 'react';
import { View, Text, StyleSheet, Dimensions, ScrollView } from 'react-native';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo } from '@/constants/data';
import { HistoryPoint } from '@/types';
import Svg, { Path, Line, Text as SvgText, Rect, Circle } from 'react-native-svg';

const { width } = Dimensions.get('window');
const CHART_WIDTH = width - SPACING.lg * 2;
const CHART_HEIGHT = 160;
const PADDING_LEFT = 32;
const PADDING_BOTTOM = 24;
const PADDING_TOP = 12;

interface AQIChartProps {
  data: HistoryPoint[];
  metric?: 'aqi' | 'pm25' | 'pm10';
}

export default function AQIChart({ data, metric = 'aqi' }: AQIChartProps) {
  const values = data.map((d) => d[metric]);
  const maxVal = Math.max(...values) * 1.15;
  const minVal = 0;
  const chartWidth = CHART_WIDTH - PADDING_LEFT;
  const chartHeight = CHART_HEIGHT - PADDING_BOTTOM - PADDING_TOP;

  const points = data.map((d, i) => {
    const x = PADDING_LEFT + (i / (data.length - 1)) * chartWidth;
    const y = PADDING_TOP + chartHeight - ((d[metric] - minVal) / (maxVal - minVal)) * chartHeight;
    return { x, y, value: d[metric], time: d.time };
  });

  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaPath = `${linePath} L ${points[points.length - 1].x} ${PADDING_TOP + chartHeight} L ${points[0].x} ${PADDING_TOP + chartHeight} Z`;

  const yLabels = [0, Math.round(maxVal * 0.25), Math.round(maxVal * 0.5), Math.round(maxVal * 0.75), Math.round(maxVal)];

  return (
    <View style={styles.container}>
      <Svg width={CHART_WIDTH} height={CHART_HEIGHT}>
        {/* Y-axis labels */}
        {yLabels.map((val, i) => {
          const y = PADDING_TOP + chartHeight - (val / maxVal) * chartHeight;
          return (
            <React.Fragment key={i}>
              <Line
                x1={PADDING_LEFT}
                y1={y}
                x2={CHART_WIDTH}
                y2={y}
                stroke={COLORS.border}
                strokeWidth={1}
                strokeDasharray="4 4"
              />
              <SvgText
                x={PADDING_LEFT - 6}
                y={y + 3}
                fontSize="9"
                fill={COLORS.textMuted}
                fontFamily={TYPOGRAPHY.body}
                textAnchor="end"
              >
                {val}
              </SvgText>
            </React.Fragment>
          );
        })}

        {/* Area */}
        <Path d={areaPath} fill={COLORS.primaryLight} opacity={0.6} />

        {/* Line */}
        <Path d={linePath} fill="none" stroke={COLORS.primary} strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" />

        {/* Points */}
        {points.map((p, i) => {
          const info = getAQIInfo(p.value);
          return (
            <React.Fragment key={i}>
              <Circle cx={p.x} cy={p.y} r={3} fill={info.color} stroke="#fff" strokeWidth={1.5} />
            </React.Fragment>
          );
        })}

        {/* X-axis labels */}
        {points.map((p, i) => {
          const showLabel = data.length <= 8 || i % Math.ceil(data.length / 6) === 0;
          if (!showLabel) return null;
          return (
            <SvgText
              key={i}
              x={p.x}
              y={CHART_HEIGHT - 6}
              fontSize="9"
              fill={COLORS.textMuted}
              fontFamily={TYPOGRAPHY.body}
              textAnchor="middle"
            >
              {p.time}
            </SvgText>
          );
        })}
      </Svg>
    </View>
  );
}



const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
});
