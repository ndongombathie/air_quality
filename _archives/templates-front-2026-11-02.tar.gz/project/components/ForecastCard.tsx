import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo } from '@/constants/data';
import { ForecastPoint } from '@/types';
import { TrendingUp, Clock, MapPin } from 'lucide-react-native';
import Svg, { Path, Line, Text as SvgText, Circle } from 'react-native-svg';

interface ForecastCardProps {
  forecast: ForecastPoint[];
  interpolated?: boolean;
  locationLabel?: string;
}

export default function ForecastCard({ forecast, interpolated, locationLabel }: ForecastCardProps) {
  if (forecast.length === 0) return null;

  const aqiValues = forecast.map((f) => f.aqi);
  const maxAQI = Math.max(...aqiValues, 100);
  const chartWidth = 300;
  const chartHeight = 100;
  const padding = 20;
  const stepX = (chartWidth - padding * 2) / (forecast.length - 1);

  const points = forecast.map((f, i) => ({
    x: padding + i * stepX,
    y: chartHeight - padding - (f.aqi / maxAQI) * (chartHeight - padding * 2),
    ...f,
  }));

  const linePath = points
    .map((p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `L ${p.x} ${p.y}`))
    .join(' ');

  const areaPath = `${linePath} L ${points[points.length - 1].x} ${chartHeight - padding} L ${points[0].x} ${chartHeight - padding} Z`;

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Clock size={18} color={COLORS.primary} strokeWidth={2} />
          <View>
            <Text style={styles.title}>Prévision 5 minutes</Text>
            <Text style={styles.subtitle}>
              {interpolated ? 'Estimation par interpolation' : 'Basée sur les capteurs'}
            </Text>
          </View>
        </View>
        {interpolated && (
          <View style={styles.interpBadge}>
            <MapPin size={12} color={COLORS.accent} strokeWidth={2} />
            <Text style={styles.interpText}>Zone sans capteur</Text>
          </View>
        )}
      </View>

      {locationLabel && (
        <Text style={styles.locationLabel} numberOfLines={1}>{locationLabel}</Text>
      )}

      <View style={styles.chartWrap}>
        <Svg width={chartWidth} height={chartHeight}>
          {/* Grid lines */}
          {[0, 0.5, 1].map((t, i) => (
            <Line
              key={i}
              x1={padding}
              y1={padding + t * (chartHeight - padding * 2)}
              x2={chartWidth - padding}
              y2={padding + t * (chartHeight - padding * 2)}
              stroke={COLORS.border}
              strokeWidth={0.5}
              strokeDasharray="3 3"
            />
          ))}

          {/* Area fill */}
          <Path d={areaPath} fill={COLORS.primaryLight} opacity={0.5} />

          {/* Line */}
          <Path d={linePath} fill="none" stroke={COLORS.primary} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />

          {/* Points */}
          {points.map((p, i) => {
            const info = getAQIInfo(p.aqi);
            return (
              <Circle key={i} cx={p.x} cy={p.y} r={4} fill={info.color} stroke="#fff" strokeWidth={1.5} />
            );
          })}

          {/* X labels */}
          {points.map((p, i) => (
            <SvgText
              key={i}
              x={p.x}
              y={chartHeight - 4}
              fontSize={9}
              fill={COLORS.textMuted}
              textAnchor="middle"
              fontFamily="Inter-Regular"
            >
              {p.time}
            </SvgText>
          ))}
        </Svg>
      </View>

      <View style={styles.valuesRow}>
        {forecast.map((f, i) => {
          const info = getAQIInfo(f.aqi);
          return (
            <View key={i} style={styles.valueItem}>
              <Text style={[styles.valueAQI, { color: info.color }]}>{f.aqi}</Text>
              <Text style={styles.valueConf}>{Math.round(f.confidence * 100)}%</Text>
            </View>
          );
        })}
      </View>

      <View style={styles.footer}>
        <TrendingUp size={14} color={COLORS.textMuted} strokeWidth={2} />
        <Text style={styles.footerText}>
          Confiance: {Math.round((forecast.reduce((s, f) => s + f.confidence, 0) / forecast.length) * 100)}%
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: SPACING.sm,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  title: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 15,
    color: COLORS.text,
  },
  subtitle: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  interpBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.accentLight,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 4,
    borderRadius: RADIUS.pill,
  },
  interpText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 10,
    color: COLORS.accent,
    marginLeft: 4,
  },
  locationLabel: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    color: COLORS.textSecondary,
    marginBottom: SPACING.xs,
  },
  chartWrap: {
    alignItems: 'center',
    marginVertical: SPACING.sm,
  },
  valuesRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: SPACING.sm,
  },
  valueItem: {
    alignItems: 'center',
    flex: 1,
  },
  valueAQI: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 16,
  },
  valueConf: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 10,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: SPACING.sm,
    paddingTop: SPACING.sm,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  footerText: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    color: COLORS.textMuted,
    marginLeft: 6,
  },
});
