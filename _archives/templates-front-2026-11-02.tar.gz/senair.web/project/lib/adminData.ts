import { Article, DashboardStats, AdminAlert, ExtendedForecast } from '@/types';
import { STATION_LOCATIONS, getAQIInfo, AQI_LEVELS } from '@/constants/data';

export const ADMIN_ARTICLES: Article[] = [
  {
    id: 'art-1',
    title: 'Pic de pollution à l\'Hôtel de Ville — Recommandations',
    slug: 'pic-pollution-hotel-ville',
    excerpt: 'Une forte concentration de PM2.5 a été détectée au centre-ville de Thiès. La population est invitée à limiter les activités extérieures.',
    content: '# Alerte qualité de l\'air\n\nUne concentration anormale de particules fines (PM2.5) a été enregistrée à la station Hôtel de Ville, avec un indice dépassant 200.\n\n## Recommandations\n- Limitez les activités physiques en plein air\n- Préférez l\'aération matinale (6h-8h)\n- Les personnes sensibles doivent rester à l\'intérieur',
    category: 'alert',
    author_name: 'Dr. Aminata Diop',
    author_role: 'Directrice, Qualité de l\'Air',
    status: 'published',
    featured: true,
    image_url: null,
    tags: ['pm25', 'alerte', 'centre-ville'],
    published_at: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    created_at: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    updated_at: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
  },
  {
    id: 'art-2',
    title: 'Rapport mensuel de qualité de l\'air — Juin 2026',
    slug: 'rapport-mensuel-juin-2026',
    excerpt: 'Le rapport présente l\'analyse complète des données de qualité de l\'air pour le mois de juin 2026 sur les 9 stations de Thiès.',
    content: '# Rapport mensuel — Juin 2026\n\n## Synthèse\n\nLe mois de juin 2026 a montré une amélioration globale de la qualité de l\'air par rapport au mois de mai.',
    category: 'report',
    author_name: 'Mamadou Sarr',
    author_role: 'Analyste Environnemental',
    status: 'published',
    featured: false,
    image_url: null,
    tags: ['rapport', 'mensuel', 'analyse'],
    published_at: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(),
    updated_at: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
  },
  {
    id: 'art-3',
    title: 'Nouvelle station de mesure à Cité Lamy',
    slug: 'nouvelle-station-cite-lamy',
    excerpt: 'Une nouvelle station de surveillance de la qualité de l\'air a été installée au Collège Cité Lamy.',
    content: '# Nouvelle station — Cité Lamy\n\nLe réseau SEN-AIR s\'agrandit avec l\'installation d\'une nouvelle station de mesure.',
    category: 'info',
    author_name: 'Administration SEN-AIR',
    author_role: '',
    status: 'published',
    featured: false,
    image_url: null,
    tags: ['station', 'installation'],
    published_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 4).toISOString(),
    updated_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
  },
  {
    id: 'art-4',
    title: 'Réglementation sur les véhicules anciens en centre-ville',
    slug: 'reglementation-vehicules-anciens',
    excerpt: 'La mairie de Thiès annonce de nouvelles restrictions pour les véhicules de plus de 15 ans dans le centre-ville.',
    content: '# Nouvelle réglementation\n\n## Mesures\n\nAfin de réduire les émissions polluantes, la municipalité de Thiès met en place une zone à faibles émissions.',
    category: 'regulation',
    author_name: 'Mairie de Thiès',
    author_role: 'Service Environnement',
    status: 'published',
    featured: false,
    image_url: null,
    tags: ['reglementation', 'vehicules'],
    published_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(),
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 6).toISOString(),
    updated_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(),
  },
  {
    id: 'art-5',
    title: 'Journée de sensibilisation à la qualité de l\'air',
    slug: 'journee-sensibilisation-qualite-air',
    excerpt: 'Une journée de sensibilisation est organisée le 15 août 2026 à l\'Université Iba Der Thiam.',
    content: '# Journée de sensibilisation\n\nLe 15 août 2026, une journée de sensibilisation à la qualité de l\'air sera organisée.',
    category: 'event',
    author_name: 'Administration SEN-AIR',
    author_role: '',
    status: 'draft',
    featured: false,
    image_url: null,
    tags: ['event', 'sensibilisation'],
    published_at: null,
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    updated_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
  },
  {
    id: 'art-6',
    title: 'Analyse des niveaux de CO2 dans les écoles',
    slug: 'analyse-co2-ecoles',
    excerpt: 'Une étude révèle des concentrations élevées de CO2 dans plusieurs écoles de Thiès.',
    content: '# Analyse CO2\n\nLes mesures montrent des niveaux préoccupants dans certaines salles de classe.',
    category: 'report',
    author_name: 'Dr. Aminata Diop',
    author_role: 'Directrice, Qualité de l\'Air',
    status: 'draft',
    featured: false,
    image_url: null,
    tags: ['co2', 'ecoles', 'etude'],
    published_at: null,
    created_at: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    updated_at: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
  },
];

export const ADMIN_ALERTS: AdminAlert[] = [
  {
    id: 'admin-alert-1',
    stationId: 168373,
    stationName: 'Hôtel de Ville',
    pollutant: 'PM2.5',
    value: 205,
    threshold: 15,
    level: 'very_unhealthy',
    timestamp: new Date(Date.now() - 1000 * 60 * 15),
    status: 'active',
    message: 'Dépassement critique du seuil OMS pour les particules fines PM2.5',
  },
  {
    id: 'admin-alert-2',
    stationId: 168393,
    stationName: 'Lycee Medina Fall',
    pollutant: 'CO₂',
    value: 510,
    threshold: 1000,
    level: 'moderate',
    timestamp: new Date(Date.now() - 1000 * 60 * 45),
    status: 'active',
    message: 'Concentration élevée en dioxyde de carbone',
  },
  {
    id: 'admin-alert-3',
    stationId: 168394,
    stationName: 'Ecole élémentaire Kaba Sall',
    pollutant: 'CO₂',
    value: 815,
    threshold: 1000,
    level: 'moderate',
    timestamp: new Date(Date.now() - 1000 * 60 * 120),
    status: 'acknowledged',
    message: 'Niveau de CO₂ élevé détecté en salle de classe',
  },
  {
    id: 'admin-alert-4',
    stationId: 168373,
    stationName: 'Hôtel de Ville',
    pollutant: 'PM10',
    value: 207,
    threshold: 45,
    level: 'very_unhealthy',
    timestamp: new Date(Date.now() - 1000 * 60 * 180),
    status: 'resolved',
    message: 'Particules grossières très au-dessus de la norme OMS',
  },
  {
    id: 'admin-alert-5',
    stationId: 168377,
    stationName: 'Lycée Malick Sy',
    pollutant: 'TVOC',
    value: 296,
    threshold: 300,
    level: 'moderate',
    timestamp: new Date(Date.now() - 1000 * 60 * 240),
    status: 'active',
    message: 'Composés organiques volatils proches du seuil',
  },
];

export function getDashboardStats(stations: { id: number; name: string; aqi: number; type: string; zone: string }[]): DashboardStats {
  const totalStations = STATION_LOCATIONS.length;
  const activeStations = stations.length;
  const avgAQI = stations.length > 0 ? Math.round(stations.reduce((s, st) => s + st.aqi, 0) / stations.length) : 0;
  const maxAQI = stations.length > 0 ? Math.max(...stations.map((s) => s.aqi)) : 0;

  const totalAlerts = ADMIN_ALERTS.length;
  const unreadAlerts = ADMIN_ALERTS.filter((a) => a.status === 'active').length;

  const publishedArticles = ADMIN_ARTICLES.filter((a) => a.status === 'published').length;

  const types = ['residential', 'road', 'industrial', 'reference'];
  const stationsByType: { type: string; count: number; avgAQI: number }[] = types.map((type) => {
    const typeStations = stations.filter((s) => s.type === type);
    return {
      type,
      count: typeStations.length,
      avgAQI: typeStations.length > 0 ? Math.round(typeStations.reduce((s, st) => s + st.aqi, 0) / typeStations.length) : 0,
    };
  }).filter((t) => t.count > 0);

  const topPollutedZones = [...stations]
    .sort((a, b) => b.aqi - a.aqi)
    .slice(0, 5)
    .map((s) => ({
      zone: s.zone,
      aqi: s.aqi,
      trend: Math.round((Math.random() - 0.4) * 15),
    }));

  const alertLevels: ('good' | 'moderate' | 'sensitive' | 'unhealthy' | 'very_unhealthy' | 'hazardous')[] = ['good', 'moderate', 'sensitive', 'unhealthy', 'very_unhealthy', 'hazardous'];
  const alertsByLevel: { level: 'good' | 'moderate' | 'sensitive' | 'unhealthy' | 'very_unhealthy' | 'hazardous'; count: number }[] = alertLevels.map((level) => ({
    level,
    count: ADMIN_ALERTS.filter((a) => a.level === level).length,
  }));

  return {
    totalStations,
    activeStations,
    avgAQI,
    maxAQI,
    totalAlerts,
    unreadAlerts,
    totalArticles: ADMIN_ARTICLES.length,
    publishedArticles,
    stationsByType,
    topPollutedZones,
    alertsByLevel,
  };
}

export const ARTICLE_CATEGORIES = [
  { value: 'alert', label: 'Alerte', color: '#D32F2F' },
  { value: 'info', label: 'Information', color: '#0288D1' },
  { value: 'report', label: 'Rapport', color: '#0A6B3B' },
  { value: 'regulation', label: 'Réglementation', color: '#FF8F00' },
  { value: 'event', label: 'Événement', color: '#8F3F97' },
] as const;

export function getCategoryInfo(category: string) {
  return ARTICLE_CATEGORIES.find((c) => c.value === category) ?? ARTICLE_CATEGORIES[1];
}
