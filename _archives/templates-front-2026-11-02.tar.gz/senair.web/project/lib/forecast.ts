import { Station, ForecastPoint, StationReading, ExtendedForecast } from '@/types';
import { STATION_LOCATIONS } from '@/constants/data';

function haversine(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function interpolateAQI(
  targetLat: number,
  targetLng: number,
  stations: Station[]
): { aqi: number; confidence: number; interpolated: boolean } {
  if (stations.length === 0) return { aqi: 0, confidence: 0, interpolated: true };

  const stationsWithDist = stations
    .map((s) => ({ station: s, dist: haversine(targetLat, targetLng, s.lat, s.lng) }))
    .sort((a, b) => a.dist - b.dist);

  const nearest = stationsWithDist[0];
  if (nearest.dist < 0.1) {
    return { aqi: nearest.station.aqi, confidence: 1, interpolated: false };
  }

  const maxDist = 5;
  const weighted = stationsWithDist
    .filter((s) => s.dist < maxDist)
    .slice(0, 4)
    .map((s) => ({ aqi: s.station.aqi, weight: 1 / (s.dist + 0.1) }));

  if (weighted.length === 0) {
    return { aqi: nearest.station.aqi, confidence: 0.3, interpolated: true };
  }

  const totalWeight = weighted.reduce((sum, w) => sum + w.weight, 0);
  const aqi = weighted.reduce((sum, w) => sum + w.aqi * w.weight, 0) / totalWeight;
  const confidence = Math.max(0.3, 1 - nearest.dist / maxDist);

  return { aqi: Math.round(aqi), confidence, interpolated: true };
}

export function forecast5Min(stations: Station[]): ForecastPoint[] {
  const points: ForecastPoint[] = [];
  const now = new Date();

  for (let i = 1; i <= 5; i++) {
    const time = new Date(now.getTime() + i * 60000);
    const timeLabel = time.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

    const avgAQI = stations.reduce((sum, s) => sum + s.aqi, 0) / stations.length;
    const trend = Math.sin((i / 5) * Math.PI * 0.5) * 8;
    const noise = (Math.random() - 0.5) * 6;
    const forecastAQI = Math.max(0, Math.round(avgAQI + trend + noise));
    const confidence = Math.max(0.5, 1 - i * 0.08);

    points.push({
      time: timeLabel,
      aqi: forecastAQI,
      confidence,
      interpolated: false,
    });
  }

  return points;
}

export function forecastForLocation(
  lat: number,
  lng: number,
  stations: Station[]
): ForecastPoint[] {
  const interp = interpolateAQI(lat, lng, stations);
  const points: ForecastPoint[] = [];
  const now = new Date();

  for (let i = 1; i <= 5; i++) {
    const time = new Date(now.getTime() + i * 60000);
    const timeLabel = time.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

    const trend = Math.sin((i / 5) * Math.PI * 0.5) * 6;
    const noise = (Math.random() - 0.5) * 4;
    const forecastAQI = Math.max(0, Math.round(interp.aqi + trend + noise));
    const confidence = Math.max(0.3, interp.confidence - i * 0.06);

    points.push({
      time: timeLabel,
      aqi: forecastAQI,
      confidence,
      interpolated: interp.interpolated,
    });
  }

  return points;
}

export function readingToStation(
  stationId: number,
  reading: StationReading
): Station {
  const loc = STATION_LOCATIONS.find((s) => s.id === stationId);
  if (!loc) throw new Error(`Unknown station id: ${stationId}`);

  const aqi = reading.iqr ?? 50;
  const { buildPollutants, buildWeather } = require('@/constants/data');

  return {
    id: loc.id,
    name: loc.shortName,
    zone: loc.zone,
    lat: loc.lat,
    lng: loc.lng,
    aqi: Math.round(aqi),
    pollutants: buildPollutants(reading),
    weather: buildWeather(reading),
    lastUpdate: new Date(reading.timestamp),
    type: loc.type,
    active: true,
  };
}

export function extendedForecast(stations: Station[]): ExtendedForecast[] {
  if (stations.length === 0) return [];

  const avgAQI = stations.reduce((sum, s) => sum + s.aqi, 0) / stations.length;
  const hour = new Date().getHours();

  const forecasts: ExtendedForecast[] = [];

  // 1h, 2h, 3h forecasts — trend-based with diurnal cycle
  const diurnalPattern = (h: number) => Math.sin(((h - 6) / 24) * Math.PI * 2) * 0.3 + 1;
  const horizons: { horizon: '1h' | '2h' | '3h'; label: string; offset: number }[] = [
    { horizon: '1h', label: 'Dans 1 heure', offset: 1 },
    { horizon: '2h', label: 'Dans 2 heures', offset: 2 },
    { horizon: '3h', label: 'Dans 3 heures', offset: 3 },
  ];

  for (const h of horizons) {
    const futureHour = (hour + h.offset) % 24;
    const factor = diurnalPattern(futureHour) / diurnalPattern(hour);
    const noise = (Math.random() - 0.5) * 10;
    const aqi = Math.max(0, Math.round(avgAQI * factor + noise));
    const confidence = Math.max(0.55, 0.95 - h.offset * 0.1);
    const prevAQI = h.offset === 1 ? avgAQI : Math.max(0, Math.round(avgAQI * (diurnalPattern((hour + h.offset - 1) % 24) / diurnalPattern(hour))));
    const trend: 'up' | 'down' | 'stable' = aqi > prevAQI + 5 ? 'up' : aqi < prevAQI - 5 ? 'down' : 'stable';

    forecasts.push({
      horizon: h.horizon,
      label: h.label,
      aqi,
      confidence,
      trend,
      factors: getForecastFactors(futureHour, aqi),
    });
  }

  // J+1, J+2, J+3 — daily forecasts with weather-based variation
  const dailyHorizons: { horizon: 'J+1' | 'J+2' | 'J+3'; label: string; offset: number }[] = [
    { horizon: 'J+1', label: 'Demain', offset: 1 },
    { horizon: 'J+2', label: 'Après-demain', offset: 2 },
    { horizon: 'J+3', label: 'Dans 3 jours', offset: 3 },
  ];

  for (const d of dailyHorizons) {
    const weatherFactor = 0.85 + Math.sin(d.offset * 1.3) * 0.15 + (Math.random() - 0.5) * 0.1;
    const aqi = Math.max(0, Math.round(avgAQI * weatherFactor));
    const confidence = Math.max(0.4, 0.8 - d.offset * 0.12);
    const trend: 'up' | 'down' | 'stable' = aqi > avgAQI + 8 ? 'up' : aqi < avgAQI - 8 ? 'down' : 'stable';

    forecasts.push({
      horizon: d.horizon,
      label: d.label,
      aqi,
      confidence,
      trend,
      factors: getDailyFactors(aqi, d.offset),
    });
  }

  return forecasts;
}

function getForecastFactors(hour: number, aqi: number): string[] {
  const factors: string[] = [];
  if (hour >= 7 && hour <= 10) factors.push('Trafic matinal élevé');
  if (hour >= 17 && hour <= 20) factors.push('Heure de pointe');
  if (hour >= 11 && hour <= 15) factors.push("Ensoleillement — formation d'ozone");
  if (hour >= 0 && hour <= 5) factors.push('Dispersion nocturne faible');
  if (aqi > 150) factors.push('Accumulation de particules');
  if (aqi < 50) factors.push('Conditions de dispersion favorables');
  return factors.slice(0, 3);
}

function getDailyFactors(aqi: number, offset: number): string[] {
  const factors: string[] = [];
  if (aqi > 150) factors.push('Stagnation atmosphérique prévue');
  if (aqi < 50) factors.push('Vents modérés attendus');
  if (offset === 1) factors.push('Données météo: ensoleillé');
  if (offset === 2) factors.push('Données météo: partiellement nuageux');
  if (offset === 3) factors.push('Données météo: variable');
  if (aqi > 100) factors.push('Recommandation: limiter les activités extérieures');
  return factors.slice(0, 3);
}
