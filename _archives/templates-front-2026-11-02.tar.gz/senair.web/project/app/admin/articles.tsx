import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY } from '@/constants/data';
import { ADMIN_ARTICLES, ARTICLE_CATEGORIES, getCategoryInfo } from '@/lib/adminData';
import { Article } from '@/types';
import { Plus, Search, FileText, Edit3, Eye, Star, ChevronRight } from 'lucide-react-native';

export default function AdminArticles() {
  const router = useRouter();
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'published' | 'draft' | 'archived'>('all');

  const filtered = useMemo(() => {
    return ADMIN_ARTICLES.filter((a) => {
      if (filterStatus !== 'all' && a.status !== filterStatus) return false;
      if (search && !a.title.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [search, filterStatus]);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.pageTitle} numberOfLines={1}>Articles & Publications</Text>
            <Text style={styles.pageSubtitle} numberOfLines={1}>Gérez les publications visibles par les utilisateurs mobiles</Text>
          </View>
          <Pressable style={styles.createBtn} onPress={() => router.push('/admin/articles/create')}>
            <Plus size={18} color="#fff" strokeWidth={2.5} />
            <Text style={styles.createBtnText} numberOfLines={1}>Nouvel article</Text>
          </Pressable>
        </View>

        {/* Search + Filters */}
        <View style={styles.toolbar}>
          <View style={styles.searchWrap}>
            <Search size={16} color={COLORS.textMuted} strokeWidth={2} />
            <TextInput
              style={styles.searchInput}
              placeholder="Rechercher un article..."
              placeholderTextColor={COLORS.textMuted}
              value={search}
              onChangeText={setSearch}
            />
          </View>
          <View style={styles.filterRow}>
            {(['all', 'published', 'draft', 'archived'] as const).map((s) => (
              <Pressable
                key={s}
                style={[styles.filterChip, filterStatus === s && styles.filterChipActive]}
                onPress={() => setFilterStatus(s)}
              >
                <Text style={[styles.filterChipText, filterStatus === s && styles.filterChipTextActive]} numberOfLines={1}>
                  {s === 'all' ? 'Tous' : s === 'published' ? 'Publiés' : s === 'draft' ? 'Brouillons' : 'Archivés'}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Articles list */}
        <View style={styles.card}>
          {filtered.map((article) => {
            const catInfo = getCategoryInfo(article.category);
            return (
              <Pressable
                key={article.id}
                style={styles.articleRow}
                onPress={() => router.push(`/admin/articles/edit?id=${article.id}`)}
              >
                <View style={[styles.catBadge, { backgroundColor: catInfo.color + '20' }]}>
                  <Text style={[styles.catText, { color: catInfo.color }]} numberOfLines={1}>{catInfo.label}</Text>
                </View>
                <View style={styles.articleContent}>
                  <View style={styles.articleTitleRow}>
                    {article.featured && <Star size={14} color={COLORS.accent} strokeWidth={2} fill={COLORS.accent} />}
                    <Text style={styles.articleTitle} numberOfLines={1}>{article.title}</Text>
                  </View>
                  <Text style={styles.articleExcerpt} numberOfLines={1}>{article.excerpt}</Text>
                  <View style={styles.articleMeta}>
                    <Text style={styles.articleAuthor} numberOfLines={1}>{article.author_name}</Text>
                    <Text style={styles.articleDot}>·</Text>
                    <View style={[styles.statusBadge, { backgroundColor: article.status === 'published' ? COLORS.primaryLight : article.status === 'draft' ? COLORS.accentLight : COLORS.surfaceAlt }]}>
                      <Text style={[styles.statusText, { color: article.status === 'published' ? COLORS.primary : article.status === 'draft' ? COLORS.accent : COLORS.textMuted }]} numberOfLines={1}>
                        {article.status === 'published' ? 'Publié' : article.status === 'draft' ? 'Brouillon' : 'Archivé'}
                      </Text>
                    </View>
                  </View>
                </View>
                <ChevronRight size={18} color={COLORS.textMuted} strokeWidth={2} />
              </Pressable>
            );
          })}
          {filtered.length === 0 && (
            <View style={styles.emptyState}>
              <FileText size={32} color={COLORS.textMuted} strokeWidth={1.5} />
              <Text style={styles.emptyText}>Aucun article trouvé</Text>
            </View>
          )}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.background },
  container: { flex: 1, padding: SPACING.lg },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.lg },
  pageTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 24, color: COLORS.text },
  pageSubtitle: { fontFamily: TYPOGRAPHY.body, fontSize: 13, color: COLORS.textMuted, marginTop: 4 },
  createBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: COLORS.primary, paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, borderRadius: RADIUS.pill },
  createBtnText: { fontFamily: TYPOGRAPHY.medium, fontSize: 13, color: '#fff' },
  toolbar: { marginBottom: SPACING.md },
  searchWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.surface, borderRadius: RADIUS.md, paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, borderWidth: 1, borderColor: COLORS.border, marginBottom: SPACING.sm },
  searchInput: { flex: 1, fontFamily: TYPOGRAPHY.body, fontSize: 14, color: COLORS.text, marginLeft: SPACING.sm, outlineWidth: 0 },
  filterRow: { flexDirection: 'row', gap: SPACING.xs },
  filterChip: { paddingHorizontal: SPACING.md, paddingVertical: 6, borderRadius: RADIUS.pill, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border },
  filterChipActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  filterChipText: { fontFamily: TYPOGRAPHY.medium, fontSize: 12, color: COLORS.textSecondary },
  filterChipTextActive: { color: '#fff' },
  card: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  articleRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.border, gap: SPACING.sm },
  catBadge: { paddingHorizontal: SPACING.sm, paddingVertical: 4, borderRadius: RADIUS.pill },
  catText: { fontFamily: TYPOGRAPHY.medium, fontSize: 10 },
  articleContent: { flex: 1 },
  articleTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  articleTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 14, color: COLORS.text, flex: 1 },
  articleExcerpt: { fontFamily: TYPOGRAPHY.body, fontSize: 12, color: COLORS.textMuted, marginTop: 4 },
  articleMeta: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 6 },
  articleAuthor: { fontFamily: TYPOGRAPHY.body, fontSize: 11, color: COLORS.textSecondary },
  articleDot: { fontSize: 11, color: COLORS.textMuted },
  statusBadge: { paddingHorizontal: SPACING.sm, paddingVertical: 2, borderRadius: RADIUS.pill },
  statusText: { fontFamily: TYPOGRAPHY.medium, fontSize: 10 },
  emptyState: { alignItems: 'center', paddingVertical: SPACING.xl },
  emptyText: { fontFamily: TYPOGRAPHY.body, fontSize: 14, color: COLORS.textMuted, marginTop: SPACING.sm },
});
