import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo, STATION_LOCATIONS } from '@/constants/data';
import { useStations } from '@/hooks/useStations';
import { Factory, Home, Route, Building2, MapPin, Radio, CircleCheck, Circle, ChevronRight } from 'lucide-react-native';

export default function AdminStations() {
  const { stations, loading } = useStations();

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'industrial': return <Factory size={16} color={COLORS.textSecondary} strokeWidth={2} />;
      case 'residential': return <Home size={16} color={COLORS.textSecondary} strokeWidth={2} />;
      case 'road': return <Route size={16} color={COLORS.textSecondary} strokeWidth={2} />;
      default: return <Building2 size={16} color={COLORS.textSecondary} strokeWidth={2} />;
    }
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.pageTitle} numberOfLines={1}>Stations de mesure</Text>
            <Text style={styles.pageSubtitle} numberOfLines={1}>{stations.length} stations actives sur {STATION_LOCATIONS.length} — Réseau SEN-AIR Thiès</Text>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.tableHeader}>
            <Text style={[styles.tableHeaderText, { flex: 0.3 }]} numberOfLines={1}>#</Text>
            <Text style={[styles.tableHeaderText, { flex: 2 }]} numberOfLines={1}>Station</Text>
            <Text style={[styles.tableHeaderText, { flex: 1 }]} numberOfLines={1}>Zone</Text>
            <Text style={[styles.tableHeaderText, { flex: 0.8 }]} numberOfLines={1}>Type</Text>
            <Text style={[styles.tableHeaderText, { flex: 0.8 }]} numberOfLines={1}>AQI</Text>
            <Text style={[styles.tableHeaderText, { flex: 1 }]} numberOfLines={1}>Statut</Text>
          </View>

          {stations.map((station, i) => {
            const info = getAQIInfo(station.aqi);
            return (
              <View key={station.id} style={styles.tableRow}>
                <Text style={[styles.tableCell, { flex: 0.3, color: COLORS.textMuted }]} numberOfLines={1}>{i + 1}</Text>
                <View style={[styles.tableCell, { flex: 2, flexDirection: 'row', alignItems: 'center' }]}>
                  {getTypeIcon(station.type)}
                  <Text style={styles.stationName} numberOfLines={1}>{station.name}</Text>
                </View>
                <Text style={[styles.tableCell, { flex: 1 }]} numberOfLines={1}>{station.zone}</Text>
                <Text style={[styles.tableCell, { flex: 0.8 }]} numberOfLines={1}>{station.type === 'residential' ? 'Résidentiel' : station.type === 'road' ? 'Trafic' : station.type === 'industrial' ? 'Industriel' : 'Référence'}</Text>
                <View style={[styles.aqiBadge, { backgroundColor: info.color }]}>
                  <Text style={styles.aqiBadgeText}>{station.aqi}</Text>
                </View>
                <View style={[styles.tableCell, { flex: 1, flexDirection: 'row', alignItems: 'center' }]}>
                  <CircleCheck size={14} color={COLORS.success} strokeWidth={2} />
                  <Text style={styles.statusText} numberOfLines={1}>Active</Text>
                </View>
              </View>
            );
          })}
        </View>

        <View style={styles.summaryGrid}>
          <View style={styles.summaryCard}>
            <Radio size={20} color={COLORS.primary} strokeWidth={2} />
            <Text style={styles.summaryValue}>{stations.length}</Text>
            <Text style={styles.summaryLabel} numberOfLines={1}>Stations actives</Text>
          </View>
          <View style={styles.summaryCard}>
            <MapPin size={20} color={COLORS.secondary} strokeWidth={2} />
            <Text style={styles.summaryValue}>{STATION_LOCATIONS.length}</Text>
            <Text style={styles.summaryLabel} numberOfLines={1}>Total réseau</Text>
          </View>
          <View style={styles.summaryCard}>
            <CircleCheck size={20} color={COLORS.success} strokeWidth={2} />
            <Text style={styles.summaryValue}>100%</Text>
            <Text style={styles.summaryLabel} numberOfLines={1}>Disponibilité</Text>
          </View>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.background },
  container: { flex: 1, padding: SPACING.lg },
  header: { marginBottom: SPACING.lg },
  pageTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 24, color: COLORS.text },
  pageSubtitle: { fontFamily: TYPOGRAPHY.body, fontSize: 13, color: COLORS.textMuted, marginTop: 4 },
  card: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, marginBottom: SPACING.md, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  tableHeader: { flexDirection: 'row', paddingVertical: SPACING.sm, borderBottomWidth: 2, borderBottomColor: COLORS.border, marginBottom: SPACING.xs },
  tableHeaderText: { fontFamily: TYPOGRAPHY.heading, fontSize: 11, color: COLORS.textMuted, textTransform: 'uppercase', letterSpacing: 0.5 },
  tableRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  tableCell: { fontFamily: TYPOGRAPHY.body, fontSize: 13, color: COLORS.text, paddingHorizontal: 4 },
  stationName: { fontFamily: TYPOGRAPHY.medium, fontSize: 13, color: COLORS.text, marginLeft: 6, flexShrink: 1 },
  aqiBadge: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', marginHorizontal: 4 },
  aqiBadgeText: { fontFamily: TYPOGRAPHY.heading, fontSize: 14, color: '#fff' },
  statusText: { fontFamily: TYPOGRAPHY.body, fontSize: 12, color: COLORS.success, marginLeft: 4 },
  summaryGrid: { flexDirection: 'row', gap: SPACING.md, flexWrap: 'wrap' },
  summaryCard: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, width: 200, alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  summaryValue: { fontFamily: TYPOGRAPHY.heading, fontSize: 24, color: COLORS.text, marginTop: SPACING.xs },
  summaryLabel: { fontFamily: TYPOGRAPHY.body, fontSize: 12, color: COLORS.textMuted, marginTop: 4 },
});
