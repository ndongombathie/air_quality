import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY } from '@/constants/data';
import { ADMIN_ARTICLES, ARTICLE_CATEGORIES } from '@/lib/adminData';
import { ArrowLeft, Save, Send, Eye, Star, X } from 'lucide-react-native';

export default function AdminArticleEdit() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const articleId = params.id as string | undefined;
  const existing = articleId ? ADMIN_ARTICLES.find((a) => a.id === articleId) : null;

  const [title, setTitle] = useState(existing?.title ?? '');
  const [excerpt, setExcerpt] = useState(existing?.excerpt ?? '');
  const [content, setContent] = useState(existing?.content ?? '');
  const [category, setCategory] = useState(existing?.category ?? 'info');
  const [authorName, setAuthorName] = useState(existing?.author_name ?? 'Administration');
  const [authorRole, setAuthorRole] = useState(existing?.author_role ?? '');
  const [tags, setTags] = useState((existing?.tags ?? []).join(', '));
  const [featured, setFeatured] = useState(existing?.featured ?? false);
  const [status, setStatus] = useState<'draft' | 'published' | 'archived'>(existing?.status ?? 'draft');
  const [saved, setSaved] = useState(false);

  const handleSave = (newStatus?: 'draft' | 'published' | 'archived') => {
    const finalStatus = newStatus ?? status;
    setStatus(finalStatus);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <Pressable style={styles.backBtn} onPress={() => router.push('/admin/articles')}>
          <ArrowLeft size={18} color={COLORS.text} strokeWidth={2} />
        </Pressable>
        <Text style={styles.pageTitle} numberOfLines={1}>{existing ? 'Modifier l\'article' : 'Nouvel article'}</Text>
        <View style={styles.headerActions}>
          <Pressable style={styles.iconBtn} onPress={() => setFeatured(!featured)}>
            <Star size={18} color={featured ? COLORS.accent : COLORS.textMuted} strokeWidth={2} fill={featured ? COLORS.accent : 'none'} />
          </Pressable>
        </View>
      </View>

      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.formCard}>
          <Text style={styles.label} numberOfLines={1}>Titre</Text>
          <TextInput
            style={styles.input}
            value={title}
            onChangeText={setTitle}
            placeholder="Titre de l'article"
            placeholderTextColor={COLORS.textMuted}
          />

          <Text style={styles.label} numberOfLines={1}>Catégorie</Text>
          <View style={styles.categoryRow}>
            {ARTICLE_CATEGORIES.map((cat) => (
              <Pressable
                key={cat.value}
                style={[styles.catChip, category === cat.value && { backgroundColor: cat.color, borderColor: cat.color }]}
                onPress={() => setCategory(cat.value)}
              >
                <Text style={[styles.catChipText, category === cat.value && { color: '#fff' }]} numberOfLines={1}>
                  {cat.label}
                </Text>
              </Pressable>
            ))}
          </View>

          <Text style={styles.label} numberOfLines={1}>Résumé (extrait)</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={excerpt}
            onChangeText={setExcerpt}
            placeholder="Court résumé affiché dans les listes"
            placeholderTextColor={COLORS.textMuted}
            multiline
            numberOfLines={3}
          />

          <Text style={styles.label} numberOfLines={1}>Contenu (Markdown)</Text>
          <TextInput
            style={[styles.input, styles.textAreaLarge]}
            value={content}
            onChangeText={setContent}
            placeholder="# Titre de l'article&#10;&#10;Contenu en Markdown..."
            placeholderTextColor={COLORS.textMuted}
            multiline
            numberOfLines={10}
            textAlignVertical="top"
          />

          <View style={styles.twoCol}>
            <View style={styles.col}>
              <Text style={styles.label} numberOfLines={1}>Auteur</Text>
              <TextInput
                style={styles.input}
                value={authorName}
                onChangeText={setAuthorName}
                placeholder="Nom de l'auteur"
                placeholderTextColor={COLORS.textMuted}
              />
            </View>
            <View style={styles.col}>
              <Text style={styles.label} numberOfLines={1}>Rôle</Text>
              <TextInput
                style={styles.input}
                value={authorRole}
                onChangeText={setAuthorRole}
                placeholder="Rôle (ex: Directrice)"
                placeholderTextColor={COLORS.textMuted}
              />
            </View>
          </View>

          <Text style={styles.label} numberOfLines={1}>Tags (séparés par des virgules)</Text>
          <TextInput
            style={styles.input}
            value={tags}
            onChangeText={setTags}
            placeholder="alerte, pm25, centre-ville"
            placeholderTextColor={COLORS.textMuted}
          />

          <Text style={styles.label} numberOfLines={1}>Statut</Text>
          <View style={styles.statusRow}>
            {(['draft', 'published', 'archived'] as const).map((s) => (
              <Pressable
                key={s}
                style={[styles.statusChip, status === s && styles.statusChipActive]}
                onPress={() => setStatus(s)}
              >
                <Text style={[styles.statusChipText, status === s && styles.statusChipTextActive]} numberOfLines={1}>
                  {s === 'draft' ? 'Brouillon' : s === 'published' ? 'Publié' : 'Archivé'}
                </Text>
              </Pressable>
            ))}
          </View>

          <View style={styles.featuredRow}>
            <Pressable style={styles.featuredToggle} onPress={() => setFeatured(!featured)}>
              <Star size={16} color={featured ? COLORS.accent : COLORS.textMuted} strokeWidth={2} fill={featured ? COLORS.accent : 'none'} />
              <Text style={styles.featuredText} numberOfLines={1}>Article à la une</Text>
            </Pressable>
          </View>
        </View>

        {/* Actions */}
        <View style={styles.actions}>
          <Pressable style={styles.saveBtn} onPress={() => handleSave('draft')}>
            <Save size={16} color={COLORS.primary} strokeWidth={2} />
            <Text style={styles.saveBtnText} numberOfLines={1}>Enregistrer</Text>
          </Pressable>
          <Pressable style={styles.publishBtn} onPress={() => handleSave('published')}>
            <Send size={16} color="#fff" strokeWidth={2} />
            <Text style={styles.publishBtnText} numberOfLines={1}>Publier</Text>
          </Pressable>
        </View>

        {saved && (
          <View style={styles.savedBanner}>
            <Eye size={16} color={COLORS.success} strokeWidth={2} />
            <Text style={styles.savedText}>Article enregistré avec succès</Text>
          </View>
        )}

        <View style={{ height: 60 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.background },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: SPACING.lg, paddingVertical: SPACING.md, gap: SPACING.sm },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.surface, alignItems: 'center', justifyContent: 'center' },
  pageTitle: { flex: 1, fontFamily: TYPOGRAPHY.heading, fontSize: 20, color: COLORS.text },
  headerActions: { flexDirection: 'row', gap: SPACING.xs },
  iconBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.surface, alignItems: 'center', justifyContent: 'center' },
  container: { flex: 1, padding: SPACING.lg },
  formCard: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.lg, marginBottom: SPACING.md, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  label: { fontFamily: TYPOGRAPHY.heading, fontSize: 12, color: COLORS.text, marginBottom: 6, marginTop: SPACING.sm, textTransform: 'uppercase', letterSpacing: 0.5 },
  input: { fontFamily: TYPOGRAPHY.body, fontSize: 14, color: COLORS.text, borderWidth: 1, borderColor: COLORS.border, borderRadius: RADIUS.sm, paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, outlineWidth: 0 },
  textArea: { minHeight: 60, textAlignVertical: 'top' },
  textAreaLarge: { minHeight: 200, textAlignVertical: 'top' },
  categoryRow: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.xs },
  catChip: { paddingHorizontal: SPACING.md, paddingVertical: 7, borderRadius: RADIUS.pill, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border },
  catChipText: { fontFamily: TYPOGRAPHY.medium, fontSize: 12, color: COLORS.textSecondary },
  twoCol: { flexDirection: 'row', gap: SPACING.md },
  col: { flex: 1 },
  statusRow: { flexDirection: 'row', gap: SPACING.xs },
  statusChip: { paddingHorizontal: SPACING.md, paddingVertical: 7, borderRadius: RADIUS.pill, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border },
  statusChipActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  statusChipText: { fontFamily: TYPOGRAPHY.medium, fontSize: 12, color: COLORS.textSecondary },
  statusChipTextActive: { color: '#fff' },
  featuredRow: { marginTop: SPACING.md },
  featuredToggle: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  featuredText: { fontFamily: TYPOGRAPHY.medium, fontSize: 13, color: COLORS.textSecondary },
  actions: { flexDirection: 'row', gap: SPACING.md },
  saveBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: COLORS.primaryLight, paddingVertical: SPACING.md, borderRadius: RADIUS.md },
  saveBtnText: { fontFamily: TYPOGRAPHY.medium, fontSize: 14, color: COLORS.primary },
  publishBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: COLORS.primary, paddingVertical: SPACING.md, borderRadius: RADIUS.md },
  publishBtnText: { fontFamily: TYPOGRAPHY.medium, fontSize: 14, color: '#fff' },
  savedBanner: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: SPACING.md, paddingVertical: SPACING.sm, backgroundColor: COLORS.primaryLight, borderRadius: RADIUS.md },
  savedText: { fontFamily: TYPOGRAPHY.medium, fontSize: 13, color: COLORS.success },
});
