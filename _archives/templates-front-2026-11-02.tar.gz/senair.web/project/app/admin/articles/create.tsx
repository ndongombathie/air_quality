import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY } from '@/constants/data';
import { ArrowLeft, FileText } from 'lucide-react-native';

export default function AdminArticleCreate() {
  const router = useRouter();
  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <Pressable style={styles.backBtn} onPress={() => router.push('/admin/articles')}>
          <ArrowLeft size={18} color={COLORS.text} strokeWidth={2} />
        </Pressable>
        <Text style={styles.pageTitle} numberOfLines={1}>Nouvel article</Text>
      </View>
      <View style={styles.redirect}>
        <Pressable style={styles.redirectBtn} onPress={() => router.push('/admin/articles/edit')}>
          <FileText size={18} color="#fff" strokeWidth={2} />
          <Text style={styles.redirectText} numberOfLines={1}>Aller à l'éditeur</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.background },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: SPACING.lg, paddingVertical: SPACING.md, gap: SPACING.sm },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.surface, alignItems: 'center', justifyContent: 'center' },
  pageTitle: { flex: 1, fontFamily: TYPOGRAPHY.heading, fontSize: 20, color: COLORS.text },
  redirect: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  redirectBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: COLORS.primary, paddingHorizontal: SPACING.lg, paddingVertical: SPACING.md, borderRadius: RADIUS.md },
  redirectText: { fontFamily: TYPOGRAPHY.medium, fontSize: 14, color: '#fff' },
});
