import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo } from '@/constants/data';
import { ADMIN_ALERTS } from '@/lib/adminData';
import { Bell, Check, AlertTriangle, Clock, ChevronRight, Filter } from 'lucide-react-native';

export default function AdminAlerts() {
  const [filter, setFilter] = useState<'all' | 'active' | 'acknowledged' | 'resolved'>('all');

  const filtered = useMemo(() => {
    if (filter === 'all') return ADMIN_ALERTS;
    return ADMIN_ALERTS.filter((a) => a.status === filter);
  }, [filter]);

  const stats = {
    active: ADMIN_ALERTS.filter((a) => a.status === 'active').length,
    acknowledged: ADMIN_ALERTS.filter((a) => a.status === 'acknowledged').length,
    resolved: ADMIN_ALERTS.filter((a) => a.status === 'resolved').length,
    total: ADMIN_ALERTS.length,
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.pageTitle} numberOfLines={1}>Gestion des alertes</Text>
            <Text style={styles.pageSubtitle} numberOfLines={1}>Suivi et résolution des alertes de qualité de l'air</Text>
          </View>
        </View>

        {/* Stats */}
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { borderLeftColor: COLORS.error }]}>
            <Bell size={18} color={COLORS.error} strokeWidth={2} />
            <Text style={styles.statValue}>{stats.active}</Text>
            <Text style={styles.statLabel} numberOfLines={1}>Actives</Text>
          </View>
          <View style={[styles.statCard, { borderLeftColor: COLORS.accent }]}>
            <Clock size={18} color={COLORS.accent} strokeWidth={2} />
            <Text style={styles.statValue}>{stats.acknowledged}</Text>
            <Text style={styles.statLabel} numberOfLines={1}>Reconnues</Text>
          </View>
          <View style={[styles.statCard, { borderLeftColor: COLORS.success }]}>
            <Check size={18} color={COLORS.success} strokeWidth={2} />
            <Text style={styles.statValue}>{stats.resolved}</Text>
            <Text style={styles.statLabel} numberOfLines={1}>Résolues</Text>
          </View>
          <View style={[styles.statCard, { borderLeftColor: COLORS.secondary }]}>
            <AlertTriangle size={18} color={COLORS.secondary} strokeWidth={2} />
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel} numberOfLines={1}>Total</Text>
          </View>
        </View>

        {/* Filter */}
        <View style={styles.filterRow}>
          {(['all', 'active', 'acknowledged', 'resolved'] as const).map((f) => (
            <Pressable
              key={f}
              style={[styles.filterChip, filter === f && styles.filterChipActive]}
              onPress={() => setFilter(f)}
            >
              <Text style={[styles.filterChipText, filter === f && styles.filterChipTextActive]} numberOfLines={1}>
                {f === 'all' ? 'Toutes' : f === 'active' ? 'Actives' : f === 'acknowledged' ? 'Reconnues' : 'Résolues'}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Alerts list */}
        <View style={styles.card}>
          {filtered.map((alert) => {
            const info = getAQIInfo(alert.value);
            const statusColor = alert.status === 'active' ? COLORS.error : alert.status === 'acknowledged' ? COLORS.accent : COLORS.success;
            const statusBg = alert.status === 'active' ? '#FFEBEE' : alert.status === 'acknowledged' ? '#FFF8E1' : '#E8F5E9';
            return (
              <View key={alert.id} style={styles.alertCard}>
                <View style={[styles.alertLeftBar, { backgroundColor: info.color }]} />
                <View style={styles.alertContent}>
                  <View style={styles.alertHeader}>
                    <View style={styles.alertHeaderLeft}>
                      <Text style={styles.alertStation} numberOfLines={1}>{alert.stationName}</Text>
                      <Text style={styles.alertTime} numberOfLines={1}>
                        {Math.round((Date.now() - alert.timestamp.getTime()) / 60000)} min ago · {alert.pollutant}
                      </Text>
                    </View>
                    <View style={[styles.alertStatusBadge, { backgroundColor: statusBg }]}>
                      <Text style={[styles.alertStatusText, { color: statusColor }]} numberOfLines={1}>
                        {alert.status === 'active' ? 'Active' : alert.status === 'acknowledged' ? 'Reconnue' : 'Résolue'}
                      </Text>
                    </View>
                  </View>
                  <Text style={styles.alertMessage} numberOfLines={2}>{alert.message}</Text>
                  <View style={styles.alertMetrics}>
                    <View style={styles.alertMetric}>
                      <Text style={styles.alertMetricLabel} numberOfLines={1}>Valeur</Text>
                      <Text style={[styles.alertMetricValue, { color: info.color }]}>{alert.value} µg/m³</Text>
                    </View>
                    <View style={styles.alertMetric}>
                      <Text style={styles.alertMetricLabel} numberOfLines={1}>Seuil OMS</Text>
                      <Text style={styles.alertMetricValue}>{alert.threshold} µg/m³</Text>
                    </View>
                    <View style={styles.alertMetric}>
                      <Text style={styles.alertMetricLabel} numberOfLines={1}>Niveau</Text>
                      <Text style={[styles.alertMetricValue, { color: info.color }]} numberOfLines={1}>{info.labelFr}</Text>
                    </View>
                  </View>
                  <View style={styles.alertActions}>
                    {alert.status === 'active' && (
                      <Pressable style={[styles.alertActionBtn, { backgroundColor: COLORS.accentLight }]}>
                        <Check size={14} color={COLORS.accent} strokeWidth={2} />
                        <Text style={[styles.alertActionText, { color: COLORS.accent }]} numberOfLines={1}>Reconnaître</Text>
                      </Pressable>
                    )}
                    {(alert.status === 'active' || alert.status === 'acknowledged') && (
                      <Pressable style={[styles.alertActionBtn, { backgroundColor: COLORS.primaryLight }]}>
                        <Check size={14} color={COLORS.primary} strokeWidth={2} />
                        <Text style={[styles.alertActionText, { color: COLORS.primary }]} numberOfLines={1}>Marquer résolue</Text>
                      </Pressable>
                    )}
                  </View>
                </View>
              </View>
            );
          })}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.background },
  container: { flex: 1, padding: SPACING.lg },
  header: { marginBottom: SPACING.lg },
  pageTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 24, color: COLORS.text },
  pageSubtitle: { fontFamily: TYPOGRAPHY.body, fontSize: 13, color: COLORS.textMuted, marginTop: 4 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, marginBottom: SPACING.lg },
  statCard: { backgroundColor: COLORS.surface, borderRadius: RADIUS.md, padding: SPACING.md, width: 200, borderLeftWidth: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  statValue: { fontFamily: TYPOGRAPHY.heading, fontSize: 24, color: COLORS.text, marginTop: SPACING.xs },
  statLabel: { fontFamily: TYPOGRAPHY.body, fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  filterRow: { flexDirection: 'row', gap: SPACING.xs, marginBottom: SPACING.md },
  filterChip: { paddingHorizontal: SPACING.md, paddingVertical: 7, borderRadius: RADIUS.pill, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border },
  filterChipActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  filterChipText: { fontFamily: TYPOGRAPHY.medium, fontSize: 12, color: COLORS.textSecondary },
  filterChipTextActive: { color: '#fff' },
  card: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  alertCard: { flexDirection: 'row', marginBottom: SPACING.md, borderRadius: RADIUS.md, overflow: 'hidden', backgroundColor: COLORS.surfaceAlt, borderWidth: 1, borderColor: COLORS.border },
  alertLeftBar: { width: 4 },
  alertContent: { flex: 1, padding: SPACING.md },
  alertHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  alertHeaderLeft: { flex: 1, marginRight: SPACING.sm },
  alertStation: { fontFamily: TYPOGRAPHY.heading, fontSize: 14, color: COLORS.text },
  alertTime: { fontFamily: TYPOGRAPHY.body, fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  alertStatusBadge: { paddingHorizontal: SPACING.sm, paddingVertical: 4, borderRadius: RADIUS.pill },
  alertStatusText: { fontFamily: TYPOGRAPHY.medium, fontSize: 10 },
  alertMessage: { fontFamily: TYPOGRAPHY.body, fontSize: 12, color: COLORS.textSecondary, marginTop: SPACING.xs, lineHeight: 18 },
  alertMetrics: { flexDirection: 'row', gap: SPACING.lg, marginTop: SPACING.sm, paddingTop: SPACING.sm, borderTopWidth: 1, borderTopColor: COLORS.border },
  alertMetric: { flex: 1 },
  alertMetricLabel: { fontFamily: TYPOGRAPHY.body, fontSize: 10, color: COLORS.textMuted },
  alertMetricValue: { fontFamily: TYPOGRAPHY.heading, fontSize: 13, color: COLORS.text, marginTop: 2 },
  alertActions: { flexDirection: 'row', gap: SPACING.sm, marginTop: SPACING.sm },
  alertActionBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: SPACING.md, paddingVertical: 6, borderRadius: RADIUS.pill },
  alertActionText: { fontFamily: TYPOGRAPHY.medium, fontSize: 11 },
});
