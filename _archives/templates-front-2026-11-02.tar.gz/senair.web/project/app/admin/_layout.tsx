import React from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView, Platform, Dimensions } from 'react-native';
import { Stack, useRouter, usePathname } from 'expo-router';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY } from '@/constants/data';
import { LayoutDashboard, Radio, FileText, TrendingUp, Bell, BarChart3, Leaf } from 'lucide-react-native';

const NAV_ITEMS = [
  { href: '/admin', label: 'Tableau de bord', icon: LayoutDashboard },
  { href: '/admin/stations', label: 'Stations', icon: Radio },
  { href: '/admin/articles', label: 'Articles', icon: FileText },
  { href: '/admin/forecasts', label: 'Prévisions', icon: TrendingUp },
  { href: '/admin/alerts', label: 'Alertes', icon: Bell },
  { href: '/admin/analytics', label: 'Analytique', icon: BarChart3 },
];

export default function AdminLayout() {
  const router = useRouter();
  const pathname = usePathname();
  const isWeb = Platform.OS === 'web';
  const windowWidth = Dimensions.get('window').width;
  const showSidebar = isWeb && windowWidth >= 768;

  if (!showSidebar) {
    return (
      <View style={styles.mobileContainer}>
        <View style={styles.mobileHeader}>
          <Leaf size={24} color={COLORS.primary} strokeWidth={2} />
          <Text style={styles.mobileTitle}>SEN-AIR Admin</Text>
        </View>
        <Text style={styles.mobileWarning}>
          La plateforme d'administration est optimisée pour un écran d'ordinateur. Veuillez y accéder depuis un navigateur sur desktop.
        </Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.mobileNav}>
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = pathname === item.href;
            return (
              <Pressable
                key={item.href}
                style={[styles.mobileNavItem, active && styles.mobileNavItemActive]}
                onPress={() => router.push(item.href)}
              >
                <Icon size={16} color={active ? '#fff' : COLORS.textSecondary} strokeWidth={2} />
                <Text style={[styles.mobileNavText, active && styles.mobileNavTextActive]} numberOfLines={1}>
                  {item.label}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>
        <View style={styles.mobileContent}>
          <Stack screenOptions={{ headerShown: false }} />
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.sidebar}>
        <View style={styles.sidebarHeader}>
          <View style={styles.logoWrap}>
            <Leaf size={28} color="#fff" strokeWidth={2.5} />
          </View>
          <View>
            <Text style={styles.logoTitle} numberOfLines={1}>SEN-AIR</Text>
            <Text style={styles.logoSubtitle} numberOfLines={1}>Console d'administration</Text>
          </View>
        </View>

        <View style={styles.navSection}>
          <Text style={styles.navSectionTitle} numberOfLines={1}>SURVEILLANCE</Text>
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = pathname === item.href;
            return (
              <Pressable
                key={item.href}
                style={[styles.navItem, active && styles.navItemActive]}
                onPress={() => router.push(item.href)}
              >
                <Icon size={18} color={active ? COLORS.primary : COLORS.textSecondary} strokeWidth={2} />
                <Text style={[styles.navItemText, active && styles.navItemTextActive]} numberOfLines={1}>
                  {item.label}
                </Text>
              </Pressable>
            );
          })}
        </View>

        <View style={styles.sidebarFooter}>
          <View style={styles.userCard}>
            <View style={styles.userAvatar}>
              <Text style={styles.userAvatarText} numberOfLines={1}>AD</Text>
            </View>
            <View>
              <Text style={styles.userName} numberOfLines={1}>Administration</Text>
              <Text style={styles.userRole} numberOfLines={1}>Décideur SEN-AIR</Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.main}>
        <Stack screenOptions={{ headerShown: false }} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: COLORS.background,
  },
  sidebar: {
    width: 260,
    backgroundColor: COLORS.dark,
    paddingTop: SPACING.lg,
    paddingHorizontal: SPACING.md,
    paddingBottom: SPACING.md,
  },
  sidebarHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SPACING.xl,
    paddingHorizontal: SPACING.xs,
  },
  logoWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.sm,
  },
  logoTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 16,
    color: '#fff',
    letterSpacing: 0.5,
  },
  logoSubtitle: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 10,
    color: '#7A8B92',
    marginTop: 2,
  },
  navSection: {
    flex: 1,
  },
  navSectionTitle: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 10,
    color: '#5A6B72',
    letterSpacing: 1,
    marginBottom: SPACING.sm,
    paddingHorizontal: SPACING.xs,
  },
  navItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: SPACING.sm,
    borderRadius: RADIUS.sm,
    marginBottom: 2,
  },
  navItemActive: {
    backgroundColor: 'rgba(10, 107, 59, 0.15)',
  },
  navItemText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 14,
    color: '#9BA8B0',
    marginLeft: SPACING.sm,
  },
  navItemTextActive: {
    color: COLORS.primary,
  },
  sidebarFooter: {
    borderTopWidth: 1,
    borderTopColor: '#1A2528',
    paddingTop: SPACING.md,
  },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.sm,
  },
  userAvatarText: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 14,
    color: '#fff',
  },
  userName: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 13,
    color: '#fff',
  },
  userRole: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: '#7A8B92',
    marginTop: 2,
  },
  main: {
    flex: 1,
    overflow: 'hidden',
  },
  mobileContainer: {
    flex: 1,
    backgroundColor: COLORS.background,
    paddingTop: SPACING.lg,
  },
  mobileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    marginBottom: SPACING.md,
  },
  mobileTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 18,
    color: COLORS.text,
    marginLeft: SPACING.sm,
  },
  mobileWarning: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    color: COLORS.textSecondary,
    paddingHorizontal: SPACING.md,
    marginBottom: SPACING.md,
    lineHeight: 20,
  },
  mobileNav: {
    maxHeight: 50,
    paddingHorizontal: SPACING.md,
    marginBottom: SPACING.sm,
  },
  mobileNavItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical: 8,
    borderRadius: RADIUS.pill,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginRight: SPACING.xs,
  },
  mobileNavItemActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  mobileNavText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.textSecondary,
    marginLeft: 4,
  },
  mobileNavTextActive: {
    color: '#fff',
  },
  mobileContent: {
    flex: 1,
  },
});
