import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo, STATION_LOCATIONS } from '@/constants/data';
import { useStations } from '@/hooks/useStations';
import { getDashboardStats, ADMIN_ALERTS, ADMIN_ARTICLES } from '@/lib/adminData';
import { Radio, FileText, Bell, TrendingUp, ArrowUpRight, ArrowDownRight, Minus, AlertTriangle, Clock, ChevronRight } from 'lucide-react-native';
import Svg, { Rect, Text as SvgText, Path, Line, Circle } from 'react-native-svg';

export default function AdminDashboard() {
  const { stations, loading } = useStations();
  const router = useRouter();

  const stats = useMemo(() => getDashboardStats(stations), [stations]);
  const recentAlerts = ADMIN_ALERTS.slice(0, 4);
  const recentArticles = ADMIN_ARTICLES.slice(0, 4);

  const trendData = Array.from({ length: 14 }, (_, i) => ({
    day: i,
    aqi: 80 + Math.sin(i * 0.6) * 30 + Math.random() * 15,
  }));

  const chartWidth = 520;
  const chartHeight = 140;
  const padding = 30;
  const stepX = (chartWidth - padding * 2) / (trendData.length - 1);
  const maxAQI = Math.max(...trendData.map((d) => d.aqi), 150);

  const points = trendData.map((d, i) => ({
    x: padding + i * stepX,
    y: chartHeight - padding - (d.aqi / maxAQI) * (chartHeight - padding * 2),
    ...d,
  }));

  const linePath = points.map((p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `L ${p.x} ${p.y}`)).join(' ');
  const areaPath = `${linePath} L ${points[points.length - 1].x} ${chartHeight - padding} L ${points[0].x} ${chartHeight - padding} Z`;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.pageTitle} numberOfLines={1}>Tableau de bord</Text>
            <Text style={styles.pageSubtitle} numberOfLines={1}>Vue d'ensemble du réseau de surveillance — Thiès</Text>
          </View>
          <Pressable style={styles.refreshBtn} onPress={() => router.push('/admin/forecasts')}>
            <TrendingUp size={16} color={COLORS.primary} strokeWidth={2} />
            <Text style={styles.refreshBtnText} numberOfLines={1}>Voir prévisions</Text>
          </Pressable>
        </View>

        {/* KPI Cards */}
        <View style={styles.kpiGrid}>
          <View style={styles.kpiCard}>
            <View style={[styles.kpiIcon, { backgroundColor: COLORS.primaryLight }]}>
              <Radio size={20} color={COLORS.primary} strokeWidth={2} />
            </View>
            <Text style={styles.kpiValue}>{stats.activeStations}<Text style={styles.kpiTotal}>/{stats.totalStations}</Text></Text>
            <Text style={styles.kpiLabel} numberOfLines={1}>Stations actives</Text>
          </View>
          <View style={styles.kpiCard}>
            <View style={[styles.kpiIcon, { backgroundColor: getAQIInfo(stats.avgAQI).bgColor }]}>
              <TrendingUp size={20} color={getAQIInfo(stats.avgAQI).color} strokeWidth={2} />
            </View>
            <Text style={styles.kpiValue}>{stats.avgAQI}</Text>
            <Text style={styles.kpiLabel} numberOfLines={1}>AQI moyen</Text>
          </View>
          <View style={styles.kpiCard}>
            <View style={[styles.kpiIcon, { backgroundColor: '#FFEBEE' }]}>
              <Bell size={20} color={COLORS.error} strokeWidth={2} />
            </View>
            <Text style={styles.kpiValue}>{stats.unreadAlerts}</Text>
            <Text style={styles.kpiLabel} numberOfLines={1}>Alertes actives</Text>
          </View>
          <View style={styles.kpiCard}>
            <View style={[styles.kpiIcon, { backgroundColor: COLORS.secondaryLight }]}>
              <FileText size={20} color={COLORS.secondary} strokeWidth={2} />
            </View>
            <Text style={styles.kpiValue}>{stats.publishedArticles}<Text style={styles.kpiTotal}>/{stats.totalArticles}</Text></Text>
            <Text style={styles.kpiLabel} numberOfLines={1}>Articles publiés</Text>
          </View>
        </View>

        {/* Trend Chart */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle} numberOfLines={1}>Évolution de l'AQI — 14 derniers jours</Text>
            <View style={styles.trendBadge}>
              <Text style={styles.trendBadgeText}>Moyenne: {stats.avgAQI}</Text>
            </View>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <Svg width={chartWidth} height={chartHeight}>
              {[0, 0.5, 1].map((t, i) => (
                <Line key={i} x1={padding} y1={padding + t * (chartHeight - padding * 2)} x2={chartWidth - padding} y2={padding + t * (chartHeight - padding * 2)} stroke={COLORS.border} strokeWidth={0.5} strokeDasharray="3 3" />
              ))}
              <Path d={areaPath} fill={COLORS.primaryLight} opacity={0.4} />
              <Path d={linePath} fill="none" stroke={COLORS.primary} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
              {points.map((p, i) => (
                <Circle key={i} cx={p.x} cy={p.y} r={3} fill={COLORS.primary} />
              ))}
            </Svg>
          </ScrollView>
        </View>

        {/* Two columns: Top zones + Alerts */}
        <View style={styles.twoCol}>
          <View style={styles.card}>
            <Text style={styles.cardTitle} numberOfLines={1}>Zones les plus polluées</Text>
            {stats.topPollutedZones.map((zone, i) => {
              const info = getAQIInfo(zone.aqi);
              const TrendIcon = zone.trend > 0 ? ArrowUpRight : zone.trend < 0 ? ArrowDownRight : Minus;
              const trendColor = zone.trend > 0 ? COLORS.error : zone.trend < 0 ? COLORS.success : COLORS.textMuted;
              return (
                <View key={i} style={styles.zoneRow}>
                  <View style={[styles.zoneRank, { backgroundColor: info.bgColor }]}>
                    <Text style={[styles.zoneRankText, { color: info.textColor }]}>{i + 1}</Text>
                  </View>
                  <Text style={styles.zoneName} numberOfLines={1}>{zone.zone}</Text>
                  <Text style={[styles.zoneAQI, { color: info.color }]}>{zone.aqi}</Text>
                  <View style={styles.zoneTrend}>
                    <TrendIcon size={14} color={trendColor} strokeWidth={2} />
                    <Text style={[styles.zoneTrendText, { color: trendColor }]}>{Math.abs(zone.trend)}</Text>
                  </View>
                </View>
              );
            })}
          </View>

          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Text style={styles.cardTitle} numberOfLines={1}>Alertes récentes</Text>
              <Pressable onPress={() => router.push('/admin/alerts')}>
                <ChevronRight size={18} color={COLORS.textMuted} strokeWidth={2} />
              </Pressable>
            </View>
            {recentAlerts.map((alert) => {
              const info = getAQIInfo(alert.value);
              return (
                <View key={alert.id} style={styles.alertRow}>
                  <View style={[styles.alertDot, { backgroundColor: info.color }]} />
                  <View style={styles.alertContent}>
                    <Text style={styles.alertStation} numberOfLines={1}>{alert.stationName}</Text>
                    <Text style={styles.alertMsg} numberOfLines={1}>{alert.message}</Text>
                  </View>
                  <View style={[styles.alertStatus, { backgroundColor: alert.status === 'active' ? '#FFEBEE' : alert.status === 'acknowledged' ? '#FFF8E1' : '#E8F5E9' }]}>
                    <Text style={[styles.alertStatusText, { color: alert.status === 'active' ? COLORS.error : alert.status === 'acknowledged' ? COLORS.accent : COLORS.success }]} numberOfLines={1}>
                      {alert.status === 'active' ? 'Active' : alert.status === 'acknowledged' ? 'Reconnue' : 'Résolue'}
                    </Text>
                  </View>
                </View>
              );
            })}
          </View>
        </View>

        {/* Recent Articles */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle} numberOfLines={1}>Articles récents</Text>
            <Pressable onPress={() => router.push('/admin/articles')}>
              <ChevronRight size={18} color={COLORS.textMuted} strokeWidth={2} />
            </Pressable>
          </View>
          {recentArticles.map((article) => (
            <View key={article.id} style={styles.articleRow}>
              <View style={[styles.articleCatBadge, { backgroundColor: article.category === 'alert' ? '#FFEBEE' : article.category === 'report' ? COLORS.primaryLight : article.category === 'info' ? COLORS.secondaryLight : article.category === 'regulation' ? COLORS.accentLight : '#F3E5F5' }]}>
                <Text style={[styles.articleCatText, { color: article.category === 'alert' ? COLORS.error : article.category === 'report' ? COLORS.primary : article.category === 'info' ? COLORS.secondary : article.category === 'regulation' ? COLORS.accent : '#8F3F97' }]} numberOfLines={1}>
                  {article.category === 'alert' ? 'Alerte' : article.category === 'report' ? 'Rapport' : article.category === 'info' ? 'Info' : article.category === 'regulation' ? 'Réglement.' : 'Événement'}
                </Text>
              </View>
              <View style={styles.articleContent}>
                <Text style={styles.articleTitle} numberOfLines={1}>{article.title}</Text>
                <Text style={styles.articleMeta} numberOfLines={1}>{article.author_name} · {article.status === 'published' ? 'Publié' : article.status === 'draft' ? 'Brouillon' : 'Archivé'}</Text>
              </View>
            </View>
          ))}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.background },
  container: { flex: 1, padding: SPACING.lg },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.lg },
  pageTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 24, color: COLORS.text },
  pageSubtitle: { fontFamily: TYPOGRAPHY.body, fontSize: 13, color: COLORS.textMuted, marginTop: 4 },
  refreshBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: COLORS.primaryLight, paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, borderRadius: RADIUS.pill },
  refreshBtnText: { fontFamily: TYPOGRAPHY.medium, fontSize: 13, color: COLORS.primary },
  kpiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, marginBottom: SPACING.lg },
  kpiCard: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, width: 200, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  kpiIcon: { width: 40, height: 40, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginBottom: SPACING.sm },
  kpiValue: { fontFamily: TYPOGRAPHY.heading, fontSize: 28, color: COLORS.text },
  kpiTotal: { fontFamily: TYPOGRAPHY.body, fontSize: 16, color: COLORS.textMuted },
  kpiLabel: { fontFamily: TYPOGRAPHY.body, fontSize: 12, color: COLORS.textMuted, marginTop: 4 },
  card: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, marginBottom: SPACING.md, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.sm },
  cardTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 15, color: COLORS.text },
  trendBadge: { backgroundColor: COLORS.surfaceAlt, paddingHorizontal: SPACING.sm, paddingVertical: 4, borderRadius: RADIUS.pill },
  trendBadgeText: { fontFamily: TYPOGRAPHY.medium, fontSize: 11, color: COLORS.textSecondary },
  twoCol: { flexDirection: 'row', gap: SPACING.md, marginBottom: SPACING.md, flexWrap: 'wrap' },
  zoneRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  zoneRank: { width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginRight: SPACING.sm },
  zoneRankText: { fontFamily: TYPOGRAPHY.heading, fontSize: 13 },
  zoneName: { flex: 1, fontFamily: TYPOGRAPHY.medium, fontSize: 13, color: COLORS.text },
  zoneAQI: { fontFamily: TYPOGRAPHY.heading, fontSize: 15, marginRight: SPACING.sm },
  zoneTrend: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  zoneTrendText: { fontFamily: TYPOGRAPHY.medium, fontSize: 12 },
  alertRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.border, gap: SPACING.sm },
  alertDot: { width: 8, height: 8, borderRadius: 4 },
  alertContent: { flex: 1 },
  alertStation: { fontFamily: TYPOGRAPHY.medium, fontSize: 13, color: COLORS.text },
  alertMsg: { fontFamily: TYPOGRAPHY.body, fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  alertStatus: { paddingHorizontal: SPACING.sm, paddingVertical: 4, borderRadius: RADIUS.pill },
  alertStatusText: { fontFamily: TYPOGRAPHY.medium, fontSize: 10 },
  articleRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.border, gap: SPACING.sm },
  articleCatBadge: { paddingHorizontal: SPACING.sm, paddingVertical: 4, borderRadius: RADIUS.pill },
  articleCatText: { fontFamily: TYPOGRAPHY.medium, fontSize: 10 },
  articleContent: { flex: 1 },
  articleTitle: { fontFamily: TYPOGRAPHY.medium, fontSize: 13, color: COLORS.text },
  articleMeta: { fontFamily: TYPOGRAPHY.body, fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
});
