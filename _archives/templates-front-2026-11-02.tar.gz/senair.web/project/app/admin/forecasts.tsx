import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo } from '@/constants/data';
import { useStations } from '@/hooks/useStations';
import { extendedForecast } from '@/lib/forecast';
import { ArrowUpRight, ArrowDownRight, Minus, Clock, Calendar, Wind, Sun, Cloud, TrendingUp, Info } from 'lucide-react-native';
import Svg, { Path, Line, Circle, Text as SvgText, Rect } from 'react-native-svg';

export default function AdminForecasts() {
  const { stations } = useStations();
  const forecasts = useMemo(() => extendedForecast(stations), [stations]);

  const hourlyForecasts = forecasts.filter((f) => f.horizon === '1h' || f.horizon === '2h' || f.horizon === '3h');
  const dailyForecasts = forecasts.filter((f) => f.horizon === 'J+1' || f.horizon === 'J+2' || f.horizon === 'J+3');

  // Combined chart
  const chartWidth = 600;
  const chartHeight = 200;
  const padding = 40;
  const allAQI = forecasts.map((f) => f.aqi);
  const maxAQI = Math.max(...allAQI, 150);
  const stepX = (chartWidth - padding * 2) / (forecasts.length - 1);

  const points = forecasts.map((f, i) => ({
    x: padding + i * stepX,
    y: chartHeight - padding - (f.aqi / maxAQI) * (chartHeight - padding * 2),
    ...f,
  }));

  const linePath = points.map((p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `L ${p.x} ${p.y}`)).join(' ');
  const areaPath = `${linePath} L ${points[points.length - 1].x} ${chartHeight - padding} L ${points[0].x} ${chartHeight - padding} Z`;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.pageTitle} numberOfLines={1}>Prévisions qualité de l'air</Text>
            <Text style={styles.pageSubtitle} numberOfLines={1}>Prévisions à court terme (1h, 2h, 3h) et à moyen terme (J+1, J+2, J+3)</Text>
          </View>
        </View>

        {/* Combined chart */}
        <View style={styles.card}>
          <Text style={styles.cardTitle} numberOfLines={1}>Évolution prévue de l'AQI</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <Svg width={chartWidth} height={chartHeight}>
              {[0, 0.25, 0.5, 0.75, 1].map((t, i) => (
                <Line key={i} x1={padding} y1={padding + t * (chartHeight - padding * 2)} x2={chartWidth - padding} y2={padding + t * (chartHeight - padding * 2)} stroke={COLORS.border} strokeWidth={0.5} strokeDasharray="3 3" />
              ))}
              <Path d={areaPath} fill={COLORS.primaryLight} opacity={0.3} />
              <Path d={linePath} fill="none" stroke={COLORS.primary} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
              {points.map((p, i) => {
                const info = getAQIInfo(p.aqi);
                return <Circle key={i} cx={p.x} cy={p.y} r={5} fill={info.color} stroke="#fff" strokeWidth={2} />;
              })}
              {points.map((p, i) => (
                <SvgText key={i} x={p.x} y={p.y - 12} fontSize={10} fill={COLORS.text} textAnchor="middle" fontFamily="Inter-Bold">
                  {p.aqi}
                </SvgText>
              ))}
              {points.map((p, i) => (
                <SvgText key={i} x={p.x} y={chartHeight - 10} fontSize={10} fill={COLORS.textMuted} textAnchor="middle" fontFamily="Inter-Regular">
                  {p.horizon}
                </SvgText>
              ))}
            </Svg>
          </ScrollView>
        </View>

        {/* Hourly forecasts */}
        <View style={styles.sectionHeader}>
          <Clock size={18} color={COLORS.primary} strokeWidth={2} />
          <Text style={styles.sectionTitle} numberOfLines={1}>Prévisions horaires</Text>
        </View>
        <View style={styles.forecastGrid}>
          {hourlyForecasts.map((f) => {
            const info = getAQIInfo(f.aqi);
            const TrendIcon = f.trend === 'up' ? ArrowUpRight : f.trend === 'down' ? ArrowDownRight : Minus;
            const trendColor = f.trend === 'up' ? COLORS.error : f.trend === 'down' ? COLORS.success : COLORS.textMuted;
            return (
              <View key={f.horizon} style={styles.forecastCard}>
                <View style={[styles.forecastBadge, { backgroundColor: info.color }]}>
                  <Text style={styles.forecastBadgeText} numberOfLines={1}>{f.horizon}</Text>
                </View>
                <Text style={styles.forecastLabel} numberOfLines={1}>{f.label}</Text>
                <Text style={[styles.forecastAQI, { color: info.color }]}>{f.aqi}</Text>
                <Text style={[styles.forecastStatus, { color: info.textColor }]} numberOfLines={1}>{info.labelFr}</Text>
                <View style={styles.forecastTrend}>
                  <TrendIcon size={14} color={trendColor} strokeWidth={2} />
                  <Text style={[styles.forecastTrendText, { color: trendColor }]} numberOfLines={1}>
                    {f.trend === 'up' ? 'Hausse' : f.trend === 'down' ? 'Baisse' : 'Stable'}
                  </Text>
                </View>
                <View style={styles.confidenceBar}>
                  <View style={[styles.confidenceFill, { width: `${f.confidence * 100}%`, backgroundColor: COLORS.primary }]} />
                </View>
                <Text style={styles.confidenceText} numberOfLines={1}>Confiance: {Math.round(f.confidence * 100)}%</Text>
                <View style={styles.factorsList}>
                  {f.factors.map((factor, i) => (
                    <View key={i} style={styles.factorItem}>
                      <Info size={10} color={COLORS.textMuted} strokeWidth={2} />
                      <Text style={styles.factorText} numberOfLines={1}>{factor}</Text>
                    </View>
                  ))}
                </View>
              </View>
            );
          })}
        </View>

        {/* Daily forecasts */}
        <View style={styles.sectionHeader}>
          <Calendar size={18} color={COLORS.accent} strokeWidth={2} />
          <Text style={styles.sectionTitle} numberOfLines={1}>Prévisions à 3 jours</Text>
        </View>
        <View style={styles.forecastGrid}>
          {dailyForecasts.map((f) => {
            const info = getAQIInfo(f.aqi);
            const TrendIcon = f.trend === 'up' ? ArrowUpRight : f.trend === 'down' ? ArrowDownRight : Minus;
            const trendColor = f.trend === 'up' ? COLORS.error : f.trend === 'down' ? COLORS.success : COLORS.textMuted;
            return (
              <View key={f.horizon} style={[styles.forecastCard, { borderColor: info.color + '30' }]}>
                <View style={[styles.forecastBadge, { backgroundColor: info.color }]}>
                  <Text style={styles.forecastBadgeText} numberOfLines={1}>{f.horizon}</Text>
                </View>
                <Text style={styles.forecastLabel} numberOfLines={1}>{f.label}</Text>
                <Text style={[styles.forecastAQI, { color: info.color }]}>{f.aqi}</Text>
                <Text style={[styles.forecastStatus, { color: info.textColor }]} numberOfLines={1}>{info.labelFr}</Text>
                <View style={styles.forecastTrend}>
                  <TrendIcon size={14} color={trendColor} strokeWidth={2} />
                  <Text style={[styles.forecastTrendText, { color: trendColor }]} numberOfLines={1}>
                    {f.trend === 'up' ? 'Hausse' : f.trend === 'down' ? 'Baisse' : 'Stable'}
                  </Text>
                </View>
                <View style={styles.confidenceBar}>
                  <View style={[styles.confidenceFill, { width: `${f.confidence * 100}%`, backgroundColor: COLORS.accent }]} />
                </View>
                <Text style={styles.confidenceText} numberOfLines={1}>Confiance: {Math.round(f.confidence * 100)}%</Text>
                <View style={styles.factorsList}>
                  {f.factors.map((factor, i) => (
                    <View key={i} style={styles.factorItem}>
                      <Info size={10} color={COLORS.textMuted} strokeWidth={2} />
                      <Text style={styles.factorText} numberOfLines={1}>{factor}</Text>
                    </View>
                  ))}
                </View>
              </View>
            );
          })}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.background },
  container: { flex: 1, padding: SPACING.lg },
  header: { marginBottom: SPACING.lg },
  pageTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 24, color: COLORS.text },
  pageSubtitle: { fontFamily: TYPOGRAPHY.body, fontSize: 13, color: COLORS.textMuted, marginTop: 4 },
  card: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, marginBottom: SPACING.md, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  cardTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 15, color: COLORS.text, marginBottom: SPACING.sm },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: SPACING.md, marginTop: SPACING.sm },
  sectionTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 16, color: COLORS.text },
  forecastGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, marginBottom: SPACING.lg },
  forecastCard: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, width: 280, borderWidth: 1, borderColor: COLORS.border, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  forecastBadge: { alignSelf: 'flex-start', paddingHorizontal: SPACING.md, paddingVertical: 4, borderRadius: RADIUS.pill, marginBottom: SPACING.xs },
  forecastBadgeText: { fontFamily: TYPOGRAPHY.heading, fontSize: 12, color: '#fff' },
  forecastLabel: { fontFamily: TYPOGRAPHY.body, fontSize: 12, color: COLORS.textMuted, marginBottom: SPACING.xs },
  forecastAQI: { fontFamily: TYPOGRAPHY.heading, fontSize: 36 },
  forecastStatus: { fontFamily: TYPOGRAPHY.medium, fontSize: 13, marginTop: 4 },
  forecastTrend: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: SPACING.xs },
  forecastTrendText: { fontFamily: TYPOGRAPHY.medium, fontSize: 12 },
  confidenceBar: { height: 4, backgroundColor: COLORS.surfaceAlt, borderRadius: 2, marginTop: SPACING.sm, overflow: 'hidden' },
  confidenceFill: { height: '100%', borderRadius: 2 },
  confidenceText: { fontFamily: TYPOGRAPHY.body, fontSize: 10, color: COLORS.textMuted, marginTop: 4 },
  factorsList: { marginTop: SPACING.sm, paddingTop: SPACING.sm, borderTopWidth: 1, borderTopColor: COLORS.border },
  factorItem: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 4 },
  factorText: { fontFamily: TYPOGRAPHY.body, fontSize: 10, color: COLORS.textSecondary, flex: 1 },
});
