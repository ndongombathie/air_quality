import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo, WHO_NORMS } from '@/constants/data';
import { useStations } from '@/hooks/useStations';
import { BarChart3, TrendingUp, Activity, Wind, Droplets } from 'lucide-react-native';
import Svg, { Rect, Text as SvgText, Path, Line, Circle } from 'react-native-svg';

export default function AdminAnalytics() {
  const { stations } = useStations();

  const avgAQI = stations.length > 0 ? Math.round(stations.reduce((s, st) => s + st.aqi, 0) / stations.length) : 0;
  const maxAQI = stations.length > 0 ? Math.max(...stations.map((s) => s.aqi)) : 0;
  const minAQI = stations.length > 0 ? Math.min(...stations.map((s) => s.aqi)) : 0;

  // Bar chart data — AQI by station
  const barData = stations.map((s) => ({ name: s.zone, aqi: s.aqi, color: getAQIInfo(s.aqi).color }));
  const barChartWidth = 600;
  const barChartHeight = 220;
  const barPadding = 30;
  const barWidth = (barChartWidth - barPadding * 2) / barData.length;

  // Pollutant comparison vs WHO
  const pollutantData = [
    { name: 'PM2.5', value: 16.5, limit: 15, unit: 'µg/m³', color: '#FF8F00' },
    { name: 'PM10', value: 34.2, limit: 45, unit: 'µg/m³', color: '#0288D1' },
    { name: 'NO₂', value: 0.17, limit: 25, unit: 'µg/m³', color: '#0A6B3B' },
    { name: 'SO₂', value: 0.26, limit: 40, unit: 'µg/m³', color: '#8F3F97' },
    { name: 'O₃', value: 59.6, limit: 100, unit: 'µg/m³', color: '#00C853' },
    { name: 'CO₂', value: 485, limit: 1000, unit: 'ppm', color: '#FF5722' },
  ];

  // Time series — 30 days
  const timeSeries = Array.from({ length: 30 }, (_, i) => ({
    day: i + 1,
    aqi: 85 + Math.sin(i * 0.3) * 25 + Math.cos(i * 0.5) * 15 + Math.random() * 10,
  }));

  const tsWidth = 600;
  const tsHeight = 180;
  const tsPadding = 30;
  const tsStepX = (tsWidth - tsPadding * 2) / (timeSeries.length - 1);
  const tsMaxAQI = Math.max(...timeSeries.map((d) => d.aqi), 150);

  const tsPoints = timeSeries.map((d, i) => ({
    x: tsPadding + i * tsStepX,
    y: tsHeight - tsPadding - (d.aqi / tsMaxAQI) * (tsHeight - tsPadding * 2),
    ...d,
  }));

  const tsLine = tsPoints.map((p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `L ${p.x} ${p.y}`)).join(' ');
  const tsArea = `${tsLine} L ${tsPoints[tsPoints.length - 1].x} ${tsHeight - tsPadding} L ${tsPoints[0].x} ${tsHeight - tsPadding} Z`;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.pageTitle} numberOfLines={1}>Analytique & Rapports</Text>
            <Text style={styles.pageSubtitle} numberOfLines={1}>Analyse détaillée des données de qualité de l'air — Thiès</Text>
          </View>
        </View>

        {/* Summary cards */}
        <View style={styles.summaryGrid}>
          <View style={styles.summaryCard}>
            <TrendingUp size={20} color={COLORS.primary} strokeWidth={2} />
            <Text style={styles.summaryValue}>{avgAQI}</Text>
            <Text style={styles.summaryLabel} numberOfLines={1}>AQI moyen</Text>
          </View>
          <View style={styles.summaryCard}>
            <Activity size={20} color={COLORS.error} strokeWidth={2} />
            <Text style={styles.summaryValue}>{maxAQI}</Text>
            <Text style={styles.summaryLabel} numberOfLines={1}>Pic maximum</Text>
          </View>
          <View style={styles.summaryCard}>
            <Wind size={20} color={COLORS.success} strokeWidth={2} />
            <Text style={styles.summaryValue}>{minAQI}</Text>
            <Text style={styles.summaryLabel} numberOfLines={1}>Minimum</Text>
          </View>
          <View style={styles.summaryCard}>
            <BarChart3 size={20} color={COLORS.secondary} strokeWidth={2} />
            <Text style={styles.summaryValue}>{stations.length}</Text>
            <Text style={styles.summaryLabel} numberOfLines={1}>Stations</Text>
          </View>
        </View>

        {/* AQI by station bar chart */}
        <View style={styles.card}>
          <Text style={styles.cardTitle} numberOfLines={1}>AQI par station</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <Svg width={barChartWidth} height={barChartHeight}>
              <Line x1={barPadding} y1={barChartHeight - barPadding} x2={barChartWidth - barPadding} y2={barChartHeight - barPadding} stroke={COLORS.border} strokeWidth={1} />
              {barData.map((d, i) => {
                const barH = (d.aqi / 300) * (barChartHeight - barPadding * 2);
                const x = barPadding + i * barWidth + barWidth * 0.15;
                const w = barWidth * 0.7;
                const y = barChartHeight - barPadding - barH;
                return (
                  <View key={i}>
                    <Rect x={x} y={y} width={w} height={barH} fill={d.color} rx={4} />
                    <SvgText x={x + w / 2} y={y - 6} fontSize={11} fill={COLORS.text} textAnchor="middle" fontFamily="Inter-Bold">{d.aqi}</SvgText>
                    <SvgText x={x + w / 2} y={barChartHeight - barPadding + 14} fontSize={9} fill={COLORS.textMuted} textAnchor="middle" fontFamily="Inter-Regular">{d.name.length > 10 ? d.name.substring(0, 10) + '...' : d.name}</SvgText>
                  </View>
                );
              })}
            </Svg>
          </ScrollView>
        </View>

        {/* 30-day trend */}
        <View style={styles.card}>
          <Text style={styles.cardTitle} numberOfLines={1}>Tendance sur 30 jours</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <Svg width={tsWidth} height={tsHeight}>
              {[0, 0.5, 1].map((t, i) => (
                <Line key={i} x1={tsPadding} y1={tsPadding + t * (tsHeight - tsPadding * 2)} x2={tsWidth - tsPadding} y2={tsPadding + t * (tsHeight - tsPadding * 2)} stroke={COLORS.border} strokeWidth={0.5} strokeDasharray="3 3" />
              ))}
              <Path d={tsArea} fill={COLORS.primaryLight} opacity={0.3} />
              <Path d={tsLine} fill="none" stroke={COLORS.primary} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
            </Svg>
          </ScrollView>
        </View>

        {/* Pollutant vs WHO norms */}
        <View style={styles.card}>
          <Text style={styles.cardTitle} numberOfLines={1}>Polluants vs normes OMS</Text>
          {pollutantData.map((p, i) => {
            const ratio = p.value / p.limit;
            const pct = Math.min(ratio * 100, 100);
            const barColor = ratio > 1 ? COLORS.error : ratio > 0.7 ? COLORS.accent : COLORS.success;
            return (
              <View key={i} style={styles.pollutantRow}>
                <View style={styles.pollutantInfo}>
                  <Text style={styles.pollutantName} numberOfLines={1}>{p.name}</Text>
                  <Text style={styles.pollutantValues} numberOfLines={1}>
                    {p.value} / {p.limit} {p.unit}
                  </Text>
                </View>
                <View style={styles.pollutantBarWrap}>
                  <View style={[styles.pollutantBar, { width: `${pct}%`, backgroundColor: barColor }]} />
                </View>
                <Text style={[styles.pollutantRatio, { color: barColor }]} numberOfLines={1}>{Math.round(ratio * 100)}%</Text>
              </View>
            );
          })}
        </View>

        {/* WHO norms table */}
        <View style={styles.card}>
          <Text style={styles.cardTitle} numberOfLines={1}>Normes OMS de qualité de l'air</Text>
          <View style={styles.tableHeader}>
            <Text style={[styles.tableHeaderText, { flex: 2 }]} numberOfLines={1}>Polluant</Text>
            <Text style={[styles.tableHeaderText, { flex: 1 }]} numberOfLines={1}>Formule</Text>
            <Text style={[styles.tableHeaderText, { flex: 1 }]} numberOfLines={1}>Annuel</Text>
            <Text style={[styles.tableHeaderText, { flex: 1 }]} numberOfLines={1}>Journalier</Text>
            <Text style={[styles.tableHeaderText, { flex: 1 }]} numberOfLines={1}>8h</Text>
            <Text style={[styles.tableHeaderText, { flex: 0.8 }]} numberOfLines={1}>Unité</Text>
          </View>
          {WHO_NORMS.map((norm, i) => (
            <View key={i} style={styles.tableRow}>
              <Text style={[styles.tableCell, { flex: 2 }]} numberOfLines={1}>{norm.pollutant}</Text>
              <Text style={[styles.tableCell, { flex: 1 }]} numberOfLines={1}>{norm.formula}</Text>
              <Text style={[styles.tableCell, { flex: 1 }]} numberOfLines={1}>{norm.annual ?? '—'}</Text>
              <Text style={[styles.tableCell, { flex: 1 }]} numberOfLines={1}>{norm.daily ?? '—'}</Text>
              <Text style={[styles.tableCell, { flex: 1 }]} numberOfLines={1}>{norm.hourly8 ?? '—'}</Text>
              <Text style={[styles.tableCell, { flex: 0.8 }]} numberOfLines={1}>{norm.unit}</Text>
            </View>
          ))}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.background },
  container: { flex: 1, padding: SPACING.lg },
  header: { marginBottom: SPACING.lg },
  pageTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 24, color: COLORS.text },
  pageSubtitle: { fontFamily: TYPOGRAPHY.body, fontSize: 13, color: COLORS.textMuted, marginTop: 4 },
  summaryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, marginBottom: SPACING.lg },
  summaryCard: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, width: 200, alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  summaryValue: { fontFamily: TYPOGRAPHY.heading, fontSize: 28, color: COLORS.text, marginTop: SPACING.xs },
  summaryLabel: { fontFamily: TYPOGRAPHY.body, fontSize: 12, color: COLORS.textMuted, marginTop: 4 },
  card: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, marginBottom: SPACING.md, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  cardTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 15, color: COLORS.text, marginBottom: SPACING.sm },
  pollutantRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.border, gap: SPACING.sm },
  pollutantInfo: { width: 140 },
  pollutantName: { fontFamily: TYPOGRAPHY.heading, fontSize: 13, color: COLORS.text },
  pollutantValues: { fontFamily: TYPOGRAPHY.body, fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  pollutantBarWrap: { flex: 1, height: 8, backgroundColor: COLORS.surfaceAlt, borderRadius: 4, overflow: 'hidden' },
  pollutantBar: { height: '100%', borderRadius: 4 },
  pollutantRatio: { fontFamily: TYPOGRAPHY.heading, fontSize: 13, width: 50, textAlign: 'right' },
  tableHeader: { flexDirection: 'row', paddingVertical: SPACING.sm, borderBottomWidth: 2, borderBottomColor: COLORS.border, marginBottom: SPACING.xs },
  tableHeaderText: { fontFamily: TYPOGRAPHY.heading, fontSize: 10, color: COLORS.textMuted, textTransform: 'uppercase', letterSpacing: 0.5 },
  tableRow: { flexDirection: 'row', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  tableCell: { fontFamily: TYPOGRAPHY.body, fontSize: 12, color: COLORS.text, paddingHorizontal: 4 },
});
