import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY, getAQIInfo, HISTORY_24H, HISTORY_7D } from '@/constants/data';
import AQIGauge from '@/components/AQIGauge';
import WeatherCard from '@/components/WeatherCard';
import PollutantCard from '@/components/PollutantCard';
import AlertBanner from '@/components/AlertBanner';
import StationCard from '@/components/StationCard';
import SectionHeader from '@/components/SectionHeader';
import AQIChart from '@/components/AQIChart';
import StationDetailModal from '@/components/StationDetailModal';
import ForecastCard from '@/components/ForecastCard';
import { Station, ExtendedForecast } from '@/types';
import { useStations } from '@/hooks/useStations';
import { forecast5Min, interpolateAQI, forecastForLocation, extendedForecast } from '@/lib/forecast';
import { Wind, Droplets, Eye, Activity, Clock, TrendingUp, ChevronDown, ArrowUpRight, ArrowDownRight, Minus, Calendar } from 'lucide-react-native';

export default function HomeScreen() {
  const { stations, loading, reload } = useStations();
  const [refreshing, setRefreshing] = useState(false);
  const [showAlert, setShowAlert] = useState(true);
  const [selectedStation, setSelectedStation] = useState<Station | null>(null);
  const [chartMetric, setChartMetric] = useState<'aqi' | 'pm25' | 'pm10'>('aqi');
  const [chartRange, setChartRange] = useState<'24h' | '7d'>('24h');

  const mainStation = stations[0] ?? null;
  const chartData = chartRange === '24h' ? HISTORY_24H : HISTORY_7D;

  const avgAQI = useMemo(() => {
    if (stations.length === 0) return 0;
    return Math.round(stations.reduce((sum, s) => sum + s.aqi, 0) / stations.length);
  }, [stations]);

  const maxStation = useMemo(() => {
    if (stations.length === 0) return null;
    return stations.reduce((max, s) => (s.aqi > max.aqi ? s : max), stations[0]);
  }, [stations]);

  const cityForecast = useMemo(() => forecast5Min(stations), [stations]);
  const extForecast = useMemo(() => extendedForecast(stations), [stations]);

  const onRefresh = () => {
    setRefreshing(true);
    reload().finally(() => setRefreshing(false));
  };

  if (loading && stations.length === 0) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Chargement des données...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!mainStation || !maxStation) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Aucune station disponible</Text>
        </View>
      </SafeAreaView>
    );
  }

  const info = getAQIInfo(mainStation.aqi);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView
        style={styles.container}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.primary} />}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <Text style={styles.greeting} numberOfLines={1}>Bonjour, Thiès</Text>
            <Text style={styles.date} numberOfLines={1}>
              {new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}
            </Text>
          </View>
          <View style={[styles.logoBadge, { backgroundColor: info.bgColor }]}>
            <Text style={[styles.logoText, { color: info.textColor }]} numberOfLines={1}>SEN-AIR</Text>
          </View>
        </View>

        {/* Alert Banner */}
        {showAlert && (
          <AlertBanner
            aqi={maxStation.aqi}
            stationName={maxStation.name}
            onDismiss={() => setShowAlert(false)}
            onPress={() => setSelectedStation(maxStation)}
          />
        )}

        {/* Main AQI Card */}
        <View style={[styles.mainCard, { backgroundColor: info.bgColor }]}>
          <View style={styles.mainCardHeader}>
            <View style={styles.mainCardHeaderLeft}>
              <Text style={[styles.cardTitle, { color: info.textColor }]} numberOfLines={1}>Qualité de l'air actuelle</Text>
              <Text style={[styles.cardSubtitle, { color: info.textColor }]} numberOfLines={1}>
                {mainStation.name} · {mainStation.zone}
              </Text>
            </View>
            <Pressable
              style={[styles.changeBtn, { borderColor: info.textColor + '40' }]}
              onPress={() => setSelectedStation(mainStation)}
            >
              <Text style={[styles.changeBtnText, { color: info.textColor }]} numberOfLines={1}>Détails</Text>
            </Pressable>
          </View>
          <View style={styles.gaugeWrap}>
            <AQIGauge aqi={mainStation.aqi} />
          </View>
          <View style={styles.quickStats}>
            <View style={styles.quickStat}>
              <TrendingUp size={16} color={info.textColor} strokeWidth={2} />
              <Text style={[styles.quickStatLabel, { color: info.textColor }]} numberOfLines={1}>Moyenne ville</Text>
              <Text style={[styles.quickStatValue, { color: info.textColor }]}>{avgAQI}</Text>
            </View>
            <View style={[styles.quickStatDivider, { backgroundColor: info.textColor + '20' }]} />
            <View style={styles.quickStat}>
              <Activity size={16} color={info.textColor} strokeWidth={2} />
              <Text style={[styles.quickStatLabel, { color: info.textColor }]} numberOfLines={1}>Pic max</Text>
              <Text style={[styles.quickStatValue, { color: info.textColor }]}>{maxStation.aqi}</Text>
            </View>
            <View style={[styles.quickStatDivider, { backgroundColor: info.textColor + '20' }]} />
            <View style={styles.quickStat}>
              <Clock size={16} color={info.textColor} strokeWidth={2} />
              <Text style={[styles.quickStatLabel, { color: info.textColor }]} numberOfLines={1}>Mise à jour</Text>
              <Text style={[styles.quickStatValue, { color: info.textColor }]} numberOfLines={1}>il y a 5 min</Text>
            </View>
          </View>
        </View>

        {/* 5-minute Forecast */}
        <SectionHeader title="Prévision (5 minutes)" subtitle="Estimation de l'évolution de l'AQI" />
        <View style={styles.sectionPadding}>
          <ForecastCard forecast={cityForecast} />
        </View>

        {/* Extended Forecasts: 1h/2h/3h + J+1/J+2/J+3 */}
        <SectionHeader title="Prévisions étendues" subtitle="Court et moyen terme" />
        <View style={styles.sectionPadding}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: SPACING.sm, paddingBottom: SPACING.xs }}>
            {extForecast.map((f) => {
              const info = getAQIInfo(f.aqi);
              const TrendIcon = f.trend === 'up' ? ArrowUpRight : f.trend === 'down' ? ArrowDownRight : Minus;
              const trendColor = f.trend === 'up' ? COLORS.error : f.trend === 'down' ? COLORS.success : COLORS.textMuted;
              const isDaily = f.horizon.startsWith('J');
              return (
                <View key={f.horizon} style={[styles.extForecastCard, { borderColor: info.color + '30' }]}>
                  <View style={[styles.extForecastBadge, { backgroundColor: info.color }]}>
                    <Text style={styles.extForecastBadgeText} numberOfLines={1}>{f.horizon}</Text>
                  </View>
                  <Text style={styles.extForecastLabel} numberOfLines={1}>{f.label}</Text>
                  <Text style={[styles.extForecastAQI, { color: info.color }]}>{f.aqi}</Text>
                  <Text style={[styles.extForecastStatus, { color: info.textColor }]} numberOfLines={1}>{info.labelFr}</Text>
                  <View style={styles.extForecastTrend}>
                    <TrendIcon size={12} color={trendColor} strokeWidth={2} />
                    <Text style={[styles.extForecastTrendText, { color: trendColor }]} numberOfLines={1}>
                      {f.trend === 'up' ? 'Hausse' : f.trend === 'down' ? 'Baisse' : 'Stable'}
                    </Text>
                  </View>
                  <View style={styles.extForecastConf}>
                    <View style={styles.extForecastConfBar}>
                      <View style={[styles.extForecastConfFill, { width: `${f.confidence * 100}%`, backgroundColor: isDaily ? COLORS.accent : COLORS.primary }]} />
                    </View>
                    <Text style={styles.extForecastConfText} numberOfLines={1}>{Math.round(f.confidence * 100)}%</Text>
                  </View>
                </View>
              );
            })}
          </ScrollView>
        </View>

        {/* Weather */}
        <SectionHeader title="Conditions météo" subtitle="Influence sur la dispersion des polluants" />
        <View style={styles.sectionPadding}>
          <WeatherCard weather={mainStation.weather} />
        </View>

        {/* Pollutants */}
        {mainStation.pollutants.length > 0 && (
          <>
            <SectionHeader title="Polluants mesurés" subtitle="Comparaison aux normes OMS" />
            <View style={styles.sectionPadding}>
              {mainStation.pollutants.map((p) => (
                <PollutantCard key={p.id} pollutant={p} />
              ))}
            </View>
          </>
        )}

        {/* Chart */}
        <SectionHeader
          title="Évolution temporelle"
          subtitle={chartRange === '24h' ? 'Dernières 24 heures' : '7 derniers jours'}
        />
        <View style={styles.sectionPadding}>
          <View style={styles.chartControls}>
            <View style={styles.metricToggle}>
              {(['aqi', 'pm25', 'pm10'] as const).map((m) => (
                <Pressable
                  key={m}
                  style={[styles.metricBtn, chartMetric === m && styles.metricBtnActive]}
                  onPress={() => setChartMetric(m)}
                >
                  <Text style={[styles.metricBtnText, chartMetric === m && styles.metricBtnTextActive]} numberOfLines={1}>
                    {m === 'aqi' ? 'AQI' : m === 'pm25' ? 'PM2.5' : 'PM10'}
                  </Text>
                </Pressable>
              ))}
            </View>
            <View style={styles.metricToggle}>
              {(['24h', '7d'] as const).map((r) => (
                <Pressable
                  key={r}
                  style={[styles.metricBtn, chartRange === r && styles.metricBtnActive]}
                  onPress={() => setChartRange(r)}
                >
                  <Text style={[styles.metricBtnText, chartRange === r && styles.metricBtnTextActive]} numberOfLines={1}>
                    {r === '24h' ? '24h' : '7j'}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
          <AQIChart data={chartData} metric={chartMetric} />
        </View>

        {/* Stations */}
        <SectionHeader title="Stations de mesure" subtitle={`${stations.length} stations actives à Thiès`} />
        <View style={styles.sectionPadding}>
          {stations.map((s) => (
            <StationCard key={s.id} station={s} onPress={() => setSelectedStation(s)} />
          ))}
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      <StationDetailModal
        station={selectedStation}
        visible={!!selectedStation}
        onClose={() => setSelectedStation(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingText: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 14,
    color: COLORS.textMuted,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
  },
  headerLeft: {
    flex: 1,
    marginRight: SPACING.sm,
  },
  greeting: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 22,
    color: COLORS.text,
  },
  date: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 13,
    color: COLORS.textMuted,
    marginTop: 2,
    textTransform: 'capitalize',
  },
  logoBadge: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.xs,
    borderRadius: RADIUS.pill,
  },
  logoText: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 13,
    letterSpacing: 0.5,
  },
  mainCard: {
    marginHorizontal: SPACING.md,
    borderRadius: RADIUS.xl,
    padding: SPACING.lg,
    marginBottom: SPACING.md,
  },
  mainCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  mainCardHeaderLeft: {
    flex: 1,
    marginRight: SPACING.sm,
  },
  cardTitle: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 15,
  },
  cardSubtitle: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 12,
    opacity: 0.7,
    marginTop: 2,
  },
  changeBtn: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
    borderRadius: RADIUS.pill,
    borderWidth: 1,
  },
  changeBtnText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
  },
  gaugeWrap: {
    alignItems: 'center',
    marginVertical: SPACING.md,
  },
  quickStats: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    marginTop: SPACING.sm,
  },
  quickStat: {
    alignItems: 'center',
    flex: 1,
  },
  quickStatLabel: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 10,
    opacity: 0.7,
    marginTop: 4,
  },
  quickStatValue: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 15,
    marginTop: 2,
  },
  quickStatDivider: {
    width: 1,
    height: 32,
  },
  sectionPadding: {
    paddingHorizontal: SPACING.md,
  },
  extForecastCard: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    width: 140,
    borderWidth: 1,
    borderColor: COLORS.border,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  extForecastBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: SPACING.sm,
    paddingVertical: 3,
    borderRadius: RADIUS.pill,
    marginBottom: SPACING.xs,
  },
  extForecastBadgeText: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 11,
    color: '#fff',
  },
  extForecastLabel: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 11,
    color: COLORS.textMuted,
    marginBottom: 2,
  },
  extForecastAQI: {
    fontFamily: TYPOGRAPHY.heading,
    fontSize: 28,
  },
  extForecastStatus: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 11,
    marginTop: 2,
  },
  extForecastTrend: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginTop: SPACING.xs,
  },
  extForecastTrendText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 10,
  },
  extForecastConf: {
    marginTop: SPACING.sm,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  extForecastConfBar: {
    flex: 1,
    height: 3,
    backgroundColor: COLORS.surfaceAlt,
    borderRadius: 2,
    overflow: 'hidden',
  },
  extForecastConfFill: {
    height: '100%',
    borderRadius: 2,
  },
  extForecastConfText: {
    fontFamily: TYPOGRAPHY.body,
    fontSize: 9,
    color: COLORS.textMuted,
  },
  chartControls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: SPACING.sm,
  },
  metricToggle: {
    flexDirection: 'row',
    backgroundColor: COLORS.surfaceAlt,
    borderRadius: RADIUS.pill,
    padding: 2,
  },
  metricBtn: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
    borderRadius: RADIUS.pill,
  },
  metricBtnActive: {
    backgroundColor: COLORS.primary,
  },
  metricBtnText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  metricBtnTextActive: {
    color: '#fff',
  },
});
