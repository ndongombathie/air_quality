import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, RefreshControl, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, RADIUS, SPACING, TYPOGRAPHY } from '@/constants/data';
import { ADMIN_ARTICLES, ARTICLE_CATEGORIES, getCategoryInfo } from '@/lib/adminData';
import { Article } from '@/types';
import { Search, Star, Clock, ChevronRight, AlertTriangle, Info, FileText, Scale, Calendar } from 'lucide-react-native';

export default function ArticlesScreen() {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<string>('all');
  const [refreshing, setRefreshing] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  const publishedArticles = useMemo(() => {
    return ADMIN_ARTICLES.filter((a) => a.status === 'published')
      .filter((a) => filter === 'all' || a.category === filter)
      .filter((a) => !search || a.title.toLowerCase().includes(search.toLowerCase()))
      .sort((a, b) => {
        if (a.featured && !b.featured) return -1;
        if (!a.featured && b.featured) return 1;
        return new Date(b.published_at ?? 0).getTime() - new Date(a.published_at ?? 0).getTime();
      });
  }, [search, filter]);

  const featured = publishedArticles.find((a) => a.featured);
  const rest = publishedArticles.filter((a) => !a.featured || a.id !== featured?.id);

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'alert': return <AlertTriangle size={14} color={getCategoryInfo(cat).color} strokeWidth={2} />;
      case 'info': return <Info size={14} color={getCategoryInfo(cat).color} strokeWidth={2} />;
      case 'report': return <FileText size={14} color={getCategoryInfo(cat).color} strokeWidth={2} />;
      case 'regulation': return <Scale size={14} color={getCategoryInfo(cat).color} strokeWidth={2} />;
      case 'event': return <Calendar size={14} color={getCategoryInfo(cat).color} strokeWidth={2} />;
      default: return <FileText size={14} color={COLORS.textSecondary} strokeWidth={2} />;
    }
  };

  if (selectedArticle) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
          <Pressable style={styles.backBtn} onPress={() => setSelectedArticle(null)}>
            <ChevronRight size={20} color={COLORS.primary} strokeWidth={2} style={{ transform: [{ rotate: '180deg' }] }} />
            <Text style={styles.backText} numberOfLines={1}>Retour aux articles</Text>
          </Pressable>

          <View style={styles.articleHeaderRow}>
            <View style={[styles.catBadge, { backgroundColor: getCategoryInfo(selectedArticle.category).color + '20' }]}>
              {getCategoryIcon(selectedArticle.category)}
              <Text style={[styles.catText, { color: getCategoryInfo(selectedArticle.category).color }]} numberOfLines={1}>
                {getCategoryInfo(selectedArticle.category).label}
              </Text>
            </View>
            {selectedArticle.featured && (
              <View style={styles.featuredBadgeInline}>
                <Star size={12} color={COLORS.accent} strokeWidth={2} fill={COLORS.accent} />
                <Text style={styles.featuredBadgeInlineText} numberOfLines={1}>À la une</Text>
              </View>
            )}
          </View>

          <Text style={styles.articleTitle}>{selectedArticle.title}</Text>
          <Text style={styles.articleExcerpt}>{selectedArticle.excerpt}</Text>

          <View style={styles.authorRow}>
            <View style={styles.authorAvatar}>
              <Text style={styles.authorAvatarText} numberOfLines={1}>
                {selectedArticle.author_name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase()}
              </Text>
            </View>
            <View>
              <Text style={styles.authorName} numberOfLines={1}>{selectedArticle.author_name}</Text>
              {selectedArticle.author_role ? <Text style={styles.authorRole} numberOfLines={1}>{selectedArticle.author_role}</Text> : null}
            </View>
            <Text style={styles.articleDate} numberOfLines={1}>
              {selectedArticle.published_at ? new Date(selectedArticle.published_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : ''}
            </Text>
          </View>

          <View style={styles.contentCard}>
            {selectedArticle.content.split('\n').map((line, i) => {
              if (line.startsWith('# ')) {
                return <Text key={i} style={styles.contentH1}>{line.replace('# ', '')}</Text>;
              }
              if (line.startsWith('## ')) {
                return <Text key={i} style={styles.contentH2}>{line.replace('## ', '')}</Text>;
              }
              if (line.startsWith('- ')) {
                return (
                  <View key={i} style={styles.bulletRow}>
                    <Text style={styles.bullet}>•</Text>
                    <Text style={styles.bulletText}>{line.replace('- ', '')}</Text>
                  </View>
                );
              }
              if (line.trim() === '') return <View key={i} style={{ height: SPACING.sm }} />;
              return <Text key={i} style={styles.contentText}>{line}</Text>;
            })}
          </View>

          {selectedArticle.tags.length > 0 && (
            <View style={styles.tagsRow}>
              {selectedArticle.tags.map((tag, i) => (
                <View key={i} style={styles.tag}>
                  <Text style={styles.tagText} numberOfLines={1}>#{tag}</Text>
                </View>
              ))}
            </View>
          )}

          <View style={{ height: 60 }} />
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView
        style={styles.container}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.primary} />}
      >
        <View style={styles.header}>
          <Text style={styles.pageTitle} numberOfLines={1}>Articles & Actualités</Text>
          <Text style={styles.pageSubtitle} numberOfLines={1}>Publications officielles de SEN-AIR Thiès</Text>
        </View>

        {/* Search */}
        <View style={styles.searchWrap}>
          <Search size={16} color={COLORS.textMuted} strokeWidth={2} />
          <TextInput
            style={styles.searchInput}
            placeholder="Rechercher..."
            placeholderTextColor={COLORS.textMuted}
            value={search}
            onChangeText={setSearch}
          />
        </View>

        {/* Category filters */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterBar} contentContainerStyle={styles.filterBarContent}>
          <Pressable
            style={[styles.filterChip, filter === 'all' && styles.filterChipActive]}
            onPress={() => setFilter('all')}
          >
            <Text style={[styles.filterText, filter === 'all' && styles.filterTextActive]} numberOfLines={1}>Tous</Text>
          </Pressable>
          {ARTICLE_CATEGORIES.map((cat) => (
            <Pressable
              key={cat.value}
              style={[styles.filterChip, filter === cat.value && { backgroundColor: cat.color, borderColor: cat.color }]}
              onPress={() => setFilter(cat.value)}
            >
              <Text style={[styles.filterText, filter === cat.value && { color: '#fff' }]} numberOfLines={1}>{cat.label}</Text>
            </Pressable>
          ))}
        </ScrollView>

        {/* Featured article */}
        {featured && (
          <Pressable style={styles.featuredCard} onPress={() => setSelectedArticle(featured)}>
            <View style={styles.featuredHeader}>
              <View style={[styles.catBadge, { backgroundColor: getCategoryInfo(featured.category).color + '20' }]}>
                {getCategoryIcon(featured.category)}
                <Text style={[styles.catText, { color: getCategoryInfo(featured.category).color }]} numberOfLines={1}>
                  {getCategoryInfo(featured.category).label}
                </Text>
              </View>
              <View style={styles.featuredStar}>
                <Star size={14} color={COLORS.accent} strokeWidth={2} fill={COLORS.accent} />
              </View>
            </View>
            <Text style={styles.featuredTitle} numberOfLines={2}>{featured.title}</Text>
            <Text style={styles.featuredExcerpt} numberOfLines={3}>{featured.excerpt}</Text>
            <View style={styles.featuredFooter}>
              <Text style={styles.featuredAuthor} numberOfLines={1}>{featured.author_name}</Text>
              <Clock size={12} color={COLORS.textMuted} strokeWidth={2} />
              <Text style={styles.featuredDate} numberOfLines={1}>
                {featured.published_at ? new Date(featured.published_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) : ''}
              </Text>
            </View>
          </Pressable>
        )}

        {/* Article list */}
        {rest.map((article) => {
          const catInfo = getCategoryInfo(article.category);
          return (
            <Pressable
              key={article.id}
              style={styles.articleCard}
              onPress={() => setSelectedArticle(article)}
            >
              <View style={[styles.catBadge, { backgroundColor: catInfo.color + '20' }]}>
                {getCategoryIcon(article.category)}
                <Text style={[styles.catText, { color: catInfo.color }]} numberOfLines={1}>{catInfo.label}</Text>
              </View>
              <Text style={styles.articleCardTitle} numberOfLines={2}>{article.title}</Text>
              <Text style={styles.articleCardExcerpt} numberOfLines={2}>{article.excerpt}</Text>
              <View style={styles.articleCardFooter}>
                <Text style={styles.articleCardAuthor} numberOfLines={1}>{article.author_name}</Text>
                <ChevronRight size={16} color={COLORS.textMuted} strokeWidth={2} />
              </View>
            </Pressable>
          );
        })}

        {publishedArticles.length === 0 && (
          <View style={styles.emptyState}>
            <FileText size={32} color={COLORS.textMuted} strokeWidth={1.5} />
            <Text style={styles.emptyText}>Aucun article trouvé</Text>
          </View>
        )}

        <View style={{ height: 80 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.background },
  container: { flex: 1, padding: SPACING.md },
  header: { marginBottom: SPACING.md },
  pageTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 22, color: COLORS.text },
  pageSubtitle: { fontFamily: TYPOGRAPHY.body, fontSize: 13, color: COLORS.textMuted, marginTop: 4 },
  searchWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.surface, borderRadius: RADIUS.md, paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, borderWidth: 1, borderColor: COLORS.border, marginBottom: SPACING.sm },
  searchInput: { flex: 1, fontFamily: TYPOGRAPHY.body, fontSize: 14, color: COLORS.text, marginLeft: SPACING.sm, outlineWidth: 0 },
  filterBar: { maxHeight: 44, marginBottom: SPACING.md },
  filterBarContent: { gap: SPACING.xs, alignItems: 'center' },
  filterChip: { paddingHorizontal: SPACING.md, paddingVertical: 7, borderRadius: RADIUS.pill, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border },
  filterChipActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  filterText: { fontFamily: TYPOGRAPHY.medium, fontSize: 12, color: COLORS.textSecondary },
  filterTextActive: { color: '#fff' },
  featuredCard: { backgroundColor: COLORS.surface, borderRadius: RADIUS.xl, padding: SPACING.lg, marginBottom: SPACING.md, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 8, elevation: 3 },
  featuredHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.sm },
  featuredStar: { backgroundColor: COLORS.accentLight, width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  featuredTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 18, color: COLORS.text, lineHeight: 24 },
  featuredExcerpt: { fontFamily: TYPOGRAPHY.body, fontSize: 13, color: COLORS.textSecondary, marginTop: SPACING.xs, lineHeight: 19 },
  featuredFooter: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: SPACING.md, paddingTop: SPACING.sm, borderTopWidth: 1, borderTopColor: COLORS.border },
  featuredAuthor: { flex: 1, fontFamily: TYPOGRAPHY.medium, fontSize: 12, color: COLORS.text },
  featuredDate: { fontFamily: TYPOGRAPHY.body, fontSize: 11, color: COLORS.textMuted },
  articleCard: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, padding: SPACING.md, marginBottom: SPACING.sm, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  catBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start', paddingHorizontal: SPACING.sm, paddingVertical: 4, borderRadius: RADIUS.pill, marginBottom: SPACING.xs },
  catText: { fontFamily: TYPOGRAPHY.medium, fontSize: 10 },
  articleCardTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 15, color: COLORS.text, lineHeight: 20 },
  articleCardExcerpt: { fontFamily: TYPOGRAPHY.body, fontSize: 12, color: COLORS.textMuted, marginTop: 4, lineHeight: 17 },
  articleCardFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: SPACING.sm },
  articleCardAuthor: { fontFamily: TYPOGRAPHY.body, fontSize: 11, color: COLORS.textSecondary },
  emptyState: { alignItems: 'center', paddingVertical: SPACING.xl },
  emptyText: { fontFamily: TYPOGRAPHY.body, fontSize: 14, color: COLORS.textMuted, marginTop: SPACING.sm },
  backBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: SPACING.md },
  backText: { fontFamily: TYPOGRAPHY.medium, fontSize: 14, color: COLORS.primary },
  articleTitle: { fontFamily: TYPOGRAPHY.heading, fontSize: 22, color: COLORS.text, lineHeight: 28 },
  articleExcerpt: { fontFamily: TYPOGRAPHY.body, fontSize: 14, color: COLORS.textSecondary, marginTop: SPACING.xs, lineHeight: 20 },
  authorRow: { flexDirection: 'row', alignItems: 'center', marginTop: SPACING.md, paddingBottom: SPACING.md, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  authorAvatar: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center', marginRight: SPACING.sm },
  authorAvatarText: { fontFamily: TYPOGRAPHY.heading, fontSize: 13, color: '#fff' },
  authorName: { fontFamily: TYPOGRAPHY.medium, fontSize: 13, color: COLORS.text },
  authorRole: { fontFamily: TYPOGRAPHY.body, fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  articleDate: { marginLeft: 'auto', fontFamily: TYPOGRAPHY.body, fontSize: 11, color: COLORS.textMuted },
  contentCard: { marginTop: SPACING.md },
  contentH1: { fontFamily: TYPOGRAPHY.heading, fontSize: 20, color: COLORS.text, marginTop: SPACING.sm, marginBottom: SPACING.xs, lineHeight: 26 },
  contentH2: { fontFamily: TYPOGRAPHY.heading, fontSize: 16, color: COLORS.text, marginTop: SPACING.sm, marginBottom: SPACING.xs, lineHeight: 22 },
  contentText: { fontFamily: TYPOGRAPHY.body, fontSize: 14, color: COLORS.textSecondary, lineHeight: 22, marginBottom: SPACING.xs },
  bulletRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 6 },
  bullet: { fontFamily: TYPOGRAPHY.body, fontSize: 14, color: COLORS.primary, marginRight: 8, marginTop: 2 },
  bulletText: { flex: 1, fontFamily: TYPOGRAPHY.body, fontSize: 14, color: COLORS.textSecondary, lineHeight: 22 },
  tagsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: SPACING.md },
  tag: { backgroundColor: COLORS.surfaceAlt, paddingHorizontal: SPACING.sm, paddingVertical: 4, borderRadius: RADIUS.pill },
  tagText: { fontFamily: TYPOGRAPHY.body, fontSize: 11, color: COLORS.textSecondary },
  articleHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.sm },
  featuredBadgeInline: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: COLORS.accentLight,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 4,
    borderRadius: RADIUS.pill,
  },
  featuredBadgeInlineText: {
    fontFamily: TYPOGRAPHY.medium,
    fontSize: 10,
    color: COLORS.accent,
  },
});
