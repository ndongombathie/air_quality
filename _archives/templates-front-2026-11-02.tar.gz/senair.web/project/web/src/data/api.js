// Static data layer — structured to be replaced by Django REST API calls later.
// Each function returns a Promise to simulate async API behavior.

const ARTICLES = [
  {
    id: 'art-1',
    title: "Pic de pollution à l'Hôtel de Ville — Recommandations",
    slug: 'pic-pollution-hotel-ville',
    excerpt: 'Une forte concentration de PM2.5 a été détectée au centre-ville de Thiès. La population est invitée à limiter les activités extérieures.',
    content: "# Alerte qualité de l'air\n\nUne concentration anormale de particules fines (PM2.5) a été enregistrée à la station Hôtel de Ville, avec un indice dépassant 200.\n\n## Recommandations\n\n- Limitez les activités physiques en plein air\n- Préférez l'aération matinale (6h-8h)\n- Les personnes sensibles (asthmatiques, enfants, personnes âgées) doivent rester à l'intérieur\n\n## Suivi\n\nL'évolution sera monitorée toutes les 5 minutes via la plateforme SEN-AIR.",
    category: 'alert',
    author_name: 'Dr. Aminata Diop',
    author_role: 'Directrice, Qualité de l\'Air',
    status: 'published',
    featured: true,
    image_url: null,
    tags: ['pm25', 'alerte', 'centre-ville'],
    published_at: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    created_at: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    updated_at: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
  },
  {
    id: 'art-2',
    title: "Rapport mensuel de qualité de l'air — Juin 2026",
    slug: 'rapport-mensuel-juin-2026',
    excerpt: "Le rapport présente l'analyse complète des données de qualité de l'air pour le mois de juin 2026 sur les 9 stations de Thiès.",
    content: "# Rapport mensuel — Juin 2026\n\n## Synthèse\n\nLe mois de juin 2026 a montré une amélioration globale de la qualité de l'air par rapport au mois de mai, avec une moyenne mensuelle de 78 (modérée).\n\n## Points clés\n\n- 9 stations actives sur l'ensemble du mois\n- 3 dépassements de seuil OMS enregistrés\n- La station Hôtel de Ville reste la plus exposée\n- Amélioration notable sur le secteur universitaire\n\n## Tendances\n\nLes concentrations de PM2.5 ont diminué de 12% par rapport à mai.",
    category: 'report',
    author_name: 'Mamadou Sarr',
    author_role: 'Analyste Environnemental',
    status: 'published',
    featured: false,
    image_url: null,
    tags: ['rapport', 'mensuel', 'analyse'],
    published_at: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(),
    updated_at: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
  },
  {
    id: 'art-3',
    title: 'Nouvelle station de mesure à Cité Lamy',
    slug: 'nouvelle-station-cite-lamy',
    excerpt: "Une nouvelle station de surveillance de la qualité de l'air a été installée au Collège Cité Lamy, portant le réseau à 9 stations actives.",
    content: "# Nouvelle station — Cité Lamy\n\nLe réseau SEN-AIR s'agrandit avec l'installation d'une nouvelle station de mesure au Collège Cité Lamy.\n\n## Caractéristiques\n\n- Capteurs: PM2.5, PM10, CO2, TVOC, CO, NO, NO2, SO2, O3, NH3\n- Transmission des données en temps réel (toutes les 5 minutes)\n- Alimentation solaire autonome\n\n## Impact\n\nCette station renforce la couverture du secteur sud de Thiès.",
    category: 'info',
    author_name: 'Administration SEN-AIR',
    author_role: '',
    status: 'published',
    featured: false,
    image_url: null,
    tags: ['station', 'installation', 'cite-lamy'],
    published_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 4).toISOString(),
    updated_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
  },
  {
    id: 'art-4',
    title: 'Réglementation sur les véhicules anciens en centre-ville',
    slug: 'reglementation-vehicules-anciens',
    excerpt: 'La mairie de Thiès annonce de nouvelles restrictions pour les véhicules de plus de 15 ans dans le centre-ville.',
    content: "# Nouvelle réglementation\n\n## Mesures\n\nAfin de réduire les émissions polluantes, la municipalité de Thiès met en place une zone à faibles émissions dans le centre-ville.\n\n## Points concernés\n\n- Véhicules de plus de 15 ans interdits en centre-ville (7h-19h)\n- Contrôles techniques renforcés\n- Incitations pour le transport en commun\n\n## Entrée en vigueur\n\nLes mesures seront progressives à partir du 1er septembre 2026.",
    category: 'regulation',
    author_name: 'Mairie de Thiès',
    author_role: 'Service Environnement',
    status: 'published',
    featured: false,
    image_url: null,
    tags: ['reglementation', 'vehicules', 'centre-ville'],
    published_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(),
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 6).toISOString(),
    updated_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(),
  },
  {
    id: 'art-5',
    title: "Journée de sensibilisation à la qualité de l'air",
    slug: 'journee-sensibilisation-qualite-air',
    excerpt: "Une journée de sensibilisation est organisée le 15 août 2026 à l'Université Iba Der Thiam.",
    content: "# Journée de sensibilisation\n\nLe 15 août 2026, une journée de sensibilisation à la qualité de l'air sera organisée à l'Université Iba Der Thiam de Thiès.\n\n## Programme\n\n- 9h: Ouverture et présentation du réseau SEN-AIR\n- 10h: Ateliers sur les effets de la pollution\n- 14h: Démonstration des capteurs\n- 16h: Table ronde avec les décideurs",
    category: 'event',
    author_name: 'Administration SEN-AIR',
    author_role: '',
    status: 'draft',
    featured: false,
    image_url: null,
    tags: ['event', 'sensibilisation'],
    published_at: null,
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    updated_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
  },
  {
    id: 'art-6',
    title: 'Analyse des niveaux de CO2 dans les écoles',
    slug: 'analyse-co2-ecoles',
    excerpt: 'Une étude révèle des concentrations élevées de CO2 dans plusieurs écoles de Thiès.',
    content: "# Analyse CO2 dans les écoles\n\nLes mesures montrent des niveaux préoccupants dans certaines salles de classe, particulièrement pendant les heures de cours.\n\n## Recommandations\n\n- Aérer les salles toutes les heures\n- Installer des extracteurs d'air\n- Surveiller le CO2 en continu",
    category: 'report',
    author_name: 'Dr. Aminata Diop',
    author_role: 'Directrice, Qualité de l\'Air',
    status: 'draft',
    featured: false,
    image_url: null,
    tags: ['co2', 'ecoles', 'etude'],
    published_at: null,
    created_at: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    updated_at: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
  },
];

const ALERTS = [
  { id: 'alert-1', stationId: 168373, stationName: 'Hôtel de Ville', pollutant: 'PM2.5', value: 205, threshold: 15, level: 'very_unhealthy', timestamp: new Date(Date.now() - 1000 * 60 * 15), status: 'active', message: 'Dépassement critique du seuil OMS pour les particules fines PM2.5' },
  { id: 'alert-2', stationId: 168393, stationName: 'Lycée Médina Fall', pollutant: 'CO₂', value: 510, threshold: 1000, level: 'moderate', timestamp: new Date(Date.now() - 1000 * 60 * 45), status: 'active', message: 'Concentration élevée en dioxyde de carbone' },
  { id: 'alert-3', stationId: 168394, stationName: 'École Kaba Sall', pollutant: 'CO₂', value: 815, threshold: 1000, level: 'moderate', timestamp: new Date(Date.now() - 1000 * 60 * 120), status: 'acknowledged', message: 'Niveau de CO2 élevé détecté en salle de classe' },
  { id: 'alert-4', stationId: 168373, stationName: 'Hôtel de Ville', pollutant: 'PM10', value: 207, threshold: 45, level: 'very_unhealthy', timestamp: new Date(Date.now() - 1000 * 60 * 180), status: 'resolved', message: 'Particules grossières très au-dessus de la norme OMS' },
  { id: 'alert-5', stationId: 168377, stationName: 'Lycée Malick Sy', pollutant: 'TVOC', value: 296, threshold: 300, level: 'moderate', timestamp: new Date(Date.now() - 1000 * 60 * 240), status: 'active', message: 'Composés organiques volatils proches du seuil' },
];

const ARTICLE_CATEGORIES = [
  { value: 'alert', label: 'Alerte', color: '#D32F2F' },
  { value: 'info', label: 'Information', color: '#0288D1' },
  { value: 'report', label: 'Rapport', color: '#0A6B3B' },
  { value: 'regulation', label: 'Réglementation', color: '#FF8F00' },
  { value: 'event', label: 'Événement', color: '#8F3F97' },
];

// --- API simulation layer (replace with Django REST API later) ---

export async function fetchArticles() {
  return ARTICLES;
}

export async function fetchArticle(id) {
  return ARTICLES.find((a) => a.id === id) || null;
}

export async function fetchAlerts() {
  return ALERTS;
}

export async function fetchDashboardStats(stations) {
  const avgAQI = stations.length > 0 ? Math.round(stations.reduce((s, st) => s + st.aqi, 0) / stations.length) : 0;
  const maxAQI = stations.length > 0 ? Math.max(...stations.map((s) => s.aqi)) : 0;

  const types = ['residential', 'road', 'industrial'];
  const stationsByType = types.map((type) => {
    const typeStations = stations.filter((s) => s.type === type);
    return {
      type,
      count: typeStations.length,
      avgAQI: typeStations.length > 0 ? Math.round(typeStations.reduce((s, st) => s + st.aqi, 0) / typeStations.length) : 0,
    };
  }).filter((t) => t.count > 0);

  const topPollutedZones = [...stations]
    .sort((a, b) => b.aqi - a.aqi)
    .slice(0, 5)
    .map((s) => ({ zone: s.zone, aqi: s.aqi, trend: Math.round((Math.random() - 0.4) * 15) }));

  return {
    totalStations: 9,
    activeStations: stations.length,
    avgAQI,
    maxAQI,
    totalAlerts: ALERTS.length,
    unreadAlerts: ALERTS.filter((a) => a.status === 'active').length,
    totalArticles: ARTICLES.length,
    publishedArticles: ARTICLES.filter((a) => a.status === 'published').length,
    stationsByType,
    topPollutedZones,
  };
}

export async function fetchExtendedForecasts(stations) {
  if (stations.length === 0) return [];
  const avgAQI = stations.reduce((s, st) => s + st.aqi, 0) / stations.length;
  const hour = new Date().getHours();
  const forecasts = [];

  const diurnal = (h) => Math.sin(((h - 6) / 24) * Math.PI * 2) * 0.3 + 1;

  const horizons = [
    { horizon: '1h', label: 'Dans 1 heure', offset: 1 },
    { horizon: '2h', label: 'Dans 2 heures', offset: 2 },
    { horizon: '3h', label: 'Dans 3 heures', offset: 3 },
  ];

  for (const h of horizons) {
    const futureHour = (hour + h.offset) % 24;
    const factor = diurnal(futureHour) / diurnal(hour);
    const noise = (Math.random() - 0.5) * 10;
    const aqi = Math.max(0, Math.round(avgAQI * factor + noise));
    const confidence = Math.max(0.55, 0.95 - h.offset * 0.1);
    const trend = aqi > avgAQI + 5 ? 'up' : aqi < avgAQI - 5 ? 'down' : 'stable';
    const factors = [];
    if (futureHour >= 7 && futureHour <= 10) factors.push('Trafic matinal élevé');
    if (futureHour >= 17 && futureHour <= 20) factors.push('Heure de pointe');
    if (aqi > 150) factors.push('Accumulation de particules');
    if (aqi < 50) factors.push('Conditions de dispersion favorables');
    forecasts.push({ horizon: h.horizon, label: h.label, aqi, confidence, trend, factors: factors.slice(0, 3) });
  }

  const daily = [
    { horizon: 'J+1', label: 'Demain', offset: 1 },
    { horizon: 'J+2', label: 'Après-demain', offset: 2 },
    { horizon: 'J+3', label: 'Dans 3 jours', offset: 3 },
  ];

  for (const d of daily) {
    const weatherFactor = 0.85 + Math.sin(d.offset * 1.3) * 0.15 + (Math.random() - 0.5) * 0.1;
    const aqi = Math.max(0, Math.round(avgAQI * weatherFactor));
    const confidence = Math.max(0.4, 0.8 - d.offset * 0.12);
    const trend = aqi > avgAQI + 8 ? 'up' : aqi < avgAQI - 8 ? 'down' : 'stable';
    const factors = [];
    if (aqi > 150) factors.push('Stagnation atmosphérique prévue');
    if (aqi < 50) factors.push('Vents modérés attendus');
    if (d.offset === 1) factors.push('Météo: ensoleillé');
    if (d.offset === 2) factors.push('Météo: partiellement nuageux');
    if (d.offset === 3) factors.push('Météo: variable');
    forecasts.push({ horizon: d.horizon, label: d.label, aqi, confidence, trend, factors: factors.slice(0, 3) });
  }

  return forecasts;
}

export async function fetchTrendData(days = 14) {
  return Array.from({ length: days }, (_, i) => ({
    day: `J-${days - i}`,
    aqi: Math.round(80 + Math.sin(i * 0.6) * 30 + Math.random() * 15),
  }));
}

export async function fetchPollutantComparison() {
  return [
    { name: 'PM2.5', value: 16.5, limit: 15, unit: 'µg/m³' },
    { name: 'PM10', value: 34.2, limit: 45, unit: 'µg/m³' },
    { name: 'NO₂', value: 0.17, limit: 25, unit: 'µg/m³' },
    { name: 'SO₂', value: 0.26, limit: 40, unit: 'µg/m³' },
    { name: 'O₃', value: 59.6, limit: 100, unit: 'µg/m³' },
    { name: 'CO₂', value: 485, limit: 1000, unit: 'ppm' },
  ];
}

export { ARTICLE_CATEGORIES };

export function getCategoryInfo(category) {
  return ARTICLE_CATEGORIES.find((c) => c.value === category) ?? ARTICLE_CATEGORIES[1];
}
