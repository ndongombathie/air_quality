export const COLORS = {
  primary: '#0A6B3B',
  primaryLight: '#E6F4EE',
  primaryDark: '#074D2A',
  secondary: '#0288D1',
  secondaryLight: '#E1F5FE',
  accent: '#FF8F00',
  accentLight: '#FFF8E1',
  success: '#2E7D32',
  warning: '#ED6C02',
  error: '#D32F2F',
  errorLight: '#FFEBEE',
  dark: '#0F1C1E',
  surface: '#FFFFFF',
  surfaceAlt: '#F5F7F8',
  background: '#F0F2F5',
  border: '#E0E4E6',
  text: '#1A2528',
  textSecondary: '#4A5B62',
  textMuted: '#8A9BA2',
};

export const AQI_LEVELS = [
  { min: 0, max: 50, label: 'Bon', labelFr: 'Bon', color: '#00E400', bgColor: '#E8F5E9', textColor: '#1B5E20' },
  { min: 51, max: 100, label: 'Moderate', labelFr: 'Modéré', color: '#FFFF00', bgColor: '#FFFDE7', textColor: '#F57F17' },
  { min: 101, max: 150, label: 'Unhealthy for Sensitive', labelFr: 'Sensible', color: '#FF9900', bgColor: '#FFF3E0', textColor: '#E65100' },
  { min: 151, max: 200, label: 'Unhealthy', labelFr: 'Mauvais', color: '#FF0000', bgColor: '#FFEBEE', textColor: '#B71C1C' },
  { min: 201, max: 300, label: 'Very Unhealthy', labelFr: 'Très mauvais', color: '#8F3F97', bgColor: '#F3E5F5', textColor: '#6A1B9A' },
  { min: 301, max: 500, label: 'Hazardous', labelFr: 'Dangereux', color: '#7E0023', bgColor: '#FCE4EC', textColor: '#880E4F' },
];

export function getAQIInfo(aqi) {
  return AQI_LEVELS.find((l) => aqi >= l.min && aqi <= l.max) ?? AQI_LEVELS[0];
}

export const STATIONS = [
  { id: 168373, name: 'Hôtel de Ville', zone: 'Centre-ville', type: 'road', lat: 14.7099, lng: -16.9232, aqi: 205, active: true, pollutants: { pm25: 16.5, pm10: 34.2, co2: 485, tvoc: 296, co: 0.07, no: 0.01, no2: 0.17, so2: 0.26, o3: 59.6, nh3: 1.3 } },
  { id: 168374, name: 'Marché Central', zone: 'Centre-ville', type: 'road', lat: 14.7084, lng: -16.9201, aqi: 187, active: true, pollutants: { pm25: 14.2, pm10: 28.5, co2: 445, tvoc: 250, co: 0.05, no: 0.01, no2: 0.14, so2: 0.22, o3: 52.3, nh3: 1.1 } },
  { id: 168375, name: 'Gare Routière', zone: 'Transport', type: 'road', lat: 14.7156, lng: -16.9356, aqi: 156, active: true, pollutants: { pm25: 12.8, pm10: 25.1, co2: 410, tvoc: 210, co: 0.04, no: 0.01, no2: 0.12, so2: 0.18, o3: 48.5, nh3: 0.9 } },
  { id: 168376, name: 'Université UIDT', zone: 'Universitaire', type: 'residential', lat: 14.7220, lng: -16.9100, aqi: 78, active: true, pollutants: { pm25: 8.5, pm10: 18.2, co2: 380, tvoc: 150, co: 0.02, no: 0.005, no2: 0.08, so2: 0.10, o3: 35.2, nh3: 0.5 } },
  { id: 168377, name: 'Lycée Malick Sy', zone: 'Scolaire', type: 'residential', lat: 14.7050, lng: -16.9180, aqi: 92, active: true, pollutants: { pm25: 10.2, pm10: 22.0, co2: 420, tvoc: 296, co: 0.03, no: 0.008, no2: 0.10, so2: 0.15, o3: 42.1, nh3: 0.7 } },
  { id: 168393, name: 'Lycée Médina Fall', zone: 'Scolaire', type: 'residential', lat: 14.7180, lng: -16.9250, aqi: 68, active: true, pollutants: { pm25: 7.2, pm10: 16.5, co2: 510, tvoc: 180, co: 0.02, no: 0.005, no2: 0.07, so2: 0.08, o3: 30.5, nh3: 0.4 } },
  { id: 168394, name: 'École Kaba Sall', zone: 'Scolaire', type: 'residential', lat: 14.7120, lng: -16.9150, aqi: 115, active: true, pollutants: { pm25: 11.5, pm10: 24.8, co2: 815, tvoc: 220, co: 0.03, no: 0.009, no2: 0.11, so2: 0.17, o3: 45.3, nh3: 0.8 } },
  { id: 168395, name: 'Zone Industrielle', zone: 'Industriel', type: 'industrial', lat: 14.7300, lng: -16.9400, aqi: 168, active: true, pollutants: { pm25: 13.8, pm10: 30.5, co2: 460, tvoc: 340, co: 0.06, no: 0.015, no2: 0.16, so2: 0.28, o3: 55.0, nh3: 1.2 } },
  { id: 168396, name: 'Cité Lamy', zone: 'Résidentiel', type: 'residential', lat: 14.7000, lng: -16.9050, aqi: 54, active: true, pollutants: { pm25: 6.0, pm10: 14.0, co2: 360, tvoc: 120, co: 0.01, no: 0.003, no2: 0.05, so2: 0.06, o3: 25.0, nh3: 0.3 } },
];

export const WHO_NORMS = [
  { pollutant: 'PM2.5', formula: 'Particules fines', annual: 5, daily: 15, hourly8: null, unit: 'µg/m³' },
  { pollutant: 'PM10', formula: 'Particules grossières', annual: 15, daily: 45, hourly8: null, unit: 'µg/m³' },
  { pollutant: 'NO₂', formula: "Dioxyde d'azote", annual: 10, daily: 25, hourly8: null, unit: 'µg/m³' },
  { pollutant: 'SO₂', formula: 'Dioxyde de soufre', annual: 40, daily: null, hourly8: null, unit: 'µg/m³' },
  { pollutant: 'O₃', formula: 'Ozone', annual: null, daily: null, hourly8: 100, unit: 'µg/m³' },
  { pollutant: 'CO₂', formula: 'Dioxyde de carbone', annual: null, daily: null, hourly8: 1000, unit: 'ppm' },
];
