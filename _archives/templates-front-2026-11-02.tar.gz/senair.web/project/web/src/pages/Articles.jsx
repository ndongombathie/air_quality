import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Search, FileText, Star, ChevronRight } from 'lucide-react';
import { fetchArticles, getCategoryInfo, ARTICLE_CATEGORIES } from '../data/api.js';

export default function Articles() {
  const [articles, setArticles] = useState([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  React.useEffect(() => {
    fetchArticles().then((a) => { setArticles(a); setLoading(false); });
  }, []);

  const filtered = useMemo(() => {
    return articles
      .filter((a) => filter === 'all' || a.status === filter)
      .filter((a) => !search || a.title.toLowerCase().includes(search.toLowerCase()));
  }, [articles, search, filter]);

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Articles & Publications</h1>
          <p className="page-subtitle">Gérez les publications visibles par les utilisateurs mobiles</p>
        </div>
        <Link to="/articles/new" className="btn btn-primary">
          <Plus size={18} strokeWidth={2.5} />
          Nouvel article
        </Link>
      </div>

      <div className="search-bar">
        <Search size={16} color="var(--text-muted)" strokeWidth={2} />
        <input
          placeholder="Rechercher un article..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="chip-row">
        {[
          { value: 'all', label: 'Tous' },
          { value: 'published', label: 'Publiés' },
          { value: 'draft', label: 'Brouillons' },
          { value: 'archived', label: 'Archivés' },
        ].map((f) => (
          <button
            key={f.value}
            className={`chip ${filter === f.value ? 'active' : ''}`}
            onClick={() => setFilter(f.value)}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="card">
        {loading ? (
          <div className="loading">Chargement...</div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <FileText size={32} strokeWidth={1.5} />
            <p>Aucun article trouvé</p>
          </div>
        ) : (
          filtered.map((article) => {
            const cat = getCategoryInfo(article.category);
            return (
              <Link key={article.id} to={`/articles/${article.id}`} style={{ textDecoration: 'none' }}>
                <div className="article-row">
                  <span className="article-cat-badge" style={{ background: cat.color + '20', color: cat.color }}>{cat.label}</span>
                  <div className="article-content">
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      {article.featured && <Star size={14} color="var(--accent)" fill="var(--accent)" strokeWidth={2} />}
                      <span className="article-title">{article.title}</span>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4 }}>{article.excerpt}</div>
                    <div className="article-meta">
                      <span className="article-author">{article.author_name}</span>
                      <span className="article-dot">·</span>
                      <span className={`badge ${article.status === 'published' ? 'badge-success' : 'badge-muted'}`} style={{ fontSize: 10 }}>
                        {article.status === 'published' ? 'Publié' : article.status === 'draft' ? 'Brouillon' : 'Archivé'}
                      </span>
                    </div>
                  </div>
                  <ChevronRight size={18} color="var(--text-muted)" strokeWidth={2} />
                </div>
              </Link>
            );
          })
        )}
      </div>
    </div>
  );
}
