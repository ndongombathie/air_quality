import React, { useState, useEffect } from 'react';
import { TrendingUp, Activity, Wind, BarChart3 } from 'lucide-react';
import { STATIONS, getAQIInfo, WHO_NORMS } from '../data/constants.js';
import { fetchTrendData, fetchPollutantComparison } from '../data/api.js';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, AreaChart, Area } from 'recharts';

export default function Analytics() {
  const [trend, setTrend] = useState([]);
  const [pollutants, setPollutants] = useState([]);

  useEffect(() => {
    Promise.all([fetchTrendData(30), fetchPollutantComparison()]).then(([t, p]) => {
      setTrend(t);
      setPollutants(p);
    });
  }, []);

  const avgAQI = STATIONS.length > 0 ? Math.round(STATIONS.reduce((s, st) => s + st.aqi, 0) / STATIONS.length) : 0;
  const maxAQI = STATIONS.length > 0 ? Math.max(...STATIONS.map((s) => s.aqi)) : 0;
  const minAQI = STATIONS.length > 0 ? Math.min(...STATIONS.map((s) => s.aqi)) : 0;

  const barData = STATIONS.map((s) => ({ name: s.zone, aqi: s.aqi, color: getAQIInfo(s.aqi).color }));

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Analytique & Rapports</h1>
          <p className="page-subtitle">Analyse détaillée des données de qualité de l'air — Thiès</p>
        </div>
      </div>

      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-icon" style={{ background: 'var(--primary-light)' }}>
            <TrendingUp size={20} color="var(--primary)" strokeWidth={2} />
          </div>
          <div className="kpi-value">{avgAQI}</div>
          <div className="kpi-label">AQI moyen</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon" style={{ background: 'var(--error-light)' }}>
            <Activity size={20} color="var(--error)" strokeWidth={2} />
          </div>
          <div className="kpi-value">{maxAQI}</div>
          <div className="kpi-label">Pic maximum</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon" style={{ background: 'var(--primary-light)' }}>
            <Wind size={20} color="var(--success)" strokeWidth={2} />
          </div>
          <div className="kpi-value">{minAQI}</div>
          <div className="kpi-label">Minimum</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon" style={{ background: 'var(--secondary-light)' }}>
            <BarChart3 size={20} color="var(--secondary)" strokeWidth={2} />
          </div>
          <div className="kpi-value">{STATIONS.length}</div>
          <div className="kpi-label">Stations</div>
        </div>
      </div>

      {/* AQI by station */}
      <div className="card">
        <h2 className="card-title">AQI par station</h2>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={barData}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="name" tick={{ fontSize: 10, fill: 'var(--text-muted)' }} angle={-20} textAnchor="end" height={60} />
            <YAxis tick={{ fontSize: 11, fill: 'var(--text-muted)' }} />
            <Tooltip contentStyle={{ borderRadius: 10, border: '1px solid var(--border)', fontSize: 13 }} />
            <Bar dataKey="aqi" radius={[6, 6, 0, 0]}>
              {barData.map((entry, i) => (
                <Cell key={i} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* 30-day trend */}
      <div className="card">
        <h2 className="card-title">Tendance sur 30 jours</h2>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={trend}>
            <defs>
              <linearGradient id="trendGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.3} />
                <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="day" tick={{ fontSize: 10, fill: 'var(--text-muted)' }} />
            <YAxis tick={{ fontSize: 11, fill: 'var(--text-muted)' }} />
            <Tooltip contentStyle={{ borderRadius: 10, border: '1px solid var(--border)', fontSize: 13 }} />
            <Area type="monotone" dataKey="aqi" stroke="var(--primary)" strokeWidth={2} fill="url(#trendGrad)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Pollutant vs WHO */}
      <div className="card">
        <h2 className="card-title">Polluants vs normes OMS</h2>
        {pollutants.map((p, i) => {
          const ratio = p.value / p.limit;
          const pct = Math.min(ratio * 100, 100);
          const barColor = ratio > 1 ? 'var(--error)' : ratio > 0.7 ? 'var(--accent)' : 'var(--success)';
          return (
            <div key={i} className="pollutant-row">
              <div className="pollutant-info">
                <div className="pollutant-name">{p.name}</div>
                <div className="pollutant-values">{p.value} / {p.limit} {p.unit}</div>
              </div>
              <div className="pollutant-bar-wrap">
                <div className="pollutant-bar" style={{ width: `${pct}%`, background: barColor }} />
              </div>
              <div className="pollutant-ratio" style={{ color: barColor }}>{Math.round(ratio * 100)}%</div>
            </div>
          );
        })}
      </div>

      {/* WHO norms table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '20px 20px 0' }}>
          <h2 className="card-title" style={{ marginBottom: 0 }}>Normes OMS de qualité de l'air</h2>
        </div>
        <table className="table">
          <thead className="table-header">
            <tr>
              <th>Polluant</th>
              <th>Formule</th>
              <th>Annuel</th>
              <th>Journalier</th>
              <th>8h</th>
              <th>Unité</th>
            </tr>
          </thead>
          <tbody>
            {WHO_NORMS.map((norm, i) => (
              <tr key={i} className="table-row">
                <td style={{ fontWeight: 600 }}>{norm.pollutant}</td>
                <td>{norm.formula}</td>
                <td>{norm.annual ?? '—'}</td>
                <td>{norm.daily ?? '—'}</td>
                <td>{norm.hourly8 ?? '—'}</td>
                <td>{norm.unit}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
