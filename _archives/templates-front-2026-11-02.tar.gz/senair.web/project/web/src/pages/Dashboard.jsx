import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Radio, TrendingUp, Bell, FileText, ArrowUpRight, ArrowDownRight, Minus, ChevronRight, AlertTriangle } from 'lucide-react';
import { STATIONS, getAQIInfo } from '../data/constants.js';
import { fetchDashboardStats, fetchAlerts, fetchArticles, fetchTrendData } from '../data/api.js';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [alerts, setAlerts] = useState([]);
  const [articles, setArticles] = useState([]);
  const [trend, setTrend] = useState([]);

  useEffect(() => {
    Promise.all([
      fetchDashboardStats(STATIONS),
      fetchAlerts(),
      fetchArticles(),
      fetchTrendData(14),
    ]).then(([s, a, art, t]) => {
      setStats(s);
      setAlerts(a.slice(0, 4));
      setArticles(art.slice(0, 4));
      setTrend(t);
    });
  }, []);

  if (!stats) return <div className="loading">Chargement...</div>;

  const avgInfo = getAQIInfo(stats.avgAQI);

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Tableau de bord</h1>
          <p className="page-subtitle">Vue d'ensemble du réseau de surveillance — Thiès</p>
        </div>
        <Link to="/forecasts" className="btn btn-outline">
          <TrendingUp size={16} strokeWidth={2} />
          Voir prévisions
        </Link>
      </div>

      {/* KPIs */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-icon" style={{ background: 'var(--primary-light)' }}>
            <Radio size={20} color="var(--primary)" strokeWidth={2} />
          </div>
          <div className="kpi-value">{stats.activeStations}<span className="kpi-total">/{stats.totalStations}</span></div>
          <div className="kpi-label">Stations actives</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon" style={{ background: avgInfo.bgColor }}>
            <TrendingUp size={20} color={avgInfo.color} strokeWidth={2} />
          </div>
          <div className="kpi-value">{stats.avgAQI}</div>
          <div className="kpi-label">AQI moyen</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon" style={{ background: 'var(--error-light)' }}>
            <Bell size={20} color="var(--error)" strokeWidth={2} />
          </div>
          <div className="kpi-value">{stats.unreadAlerts}</div>
          <div className="kpi-label">Alertes actives</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon" style={{ background: 'var(--secondary-light)' }}>
            <FileText size={20} color="var(--secondary)" strokeWidth={2} />
          </div>
          <div className="kpi-value">{stats.publishedArticles}<span className="kpi-total">/{stats.totalArticles}</span></div>
          <div className="kpi-label">Articles publiés</div>
        </div>
      </div>

      {/* Trend chart */}
      <div className="card">
        <div className="card-header">
          <h2 className="card-title" style={{ marginBottom: 0 }}>Évolution de l'AQI — 14 derniers jours</h2>
          <span className="badge badge-success">Moyenne: {stats.avgAQI}</span>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={trend}>
            <defs>
              <linearGradient id="aqiGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.3} />
                <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="day" tick={{ fontSize: 11, fill: 'var(--text-muted)' }} />
            <YAxis tick={{ fontSize: 11, fill: 'var(--text-muted)' }} />
            <Tooltip contentStyle={{ borderRadius: 10, border: '1px solid var(--border)', fontSize: 13 }} />
            <Area type="monotone" dataKey="aqi" stroke="var(--primary)" strokeWidth={2} fill="url(#aqiGrad)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Two columns */}
      <div className="two-col">
        <div className="card">
          <h2 className="card-title">Zones les plus polluées</h2>
          {stats.topPollutedZones.map((zone, i) => {
            const info = getAQIInfo(zone.aqi);
            const TrendIcon = zone.trend > 0 ? ArrowUpRight : zone.trend < 0 ? ArrowDownRight : Minus;
            const trendClass = zone.trend > 0 ? 'trend-up' : zone.trend < 0 ? 'trend-down' : 'trend-stable';
            return (
              <div key={i} className="zone-row">
                <div className="zone-rank" style={{ background: info.bgColor, color: info.textColor }}>{i + 1}</div>
                <span className="zone-name">{zone.zone}</span>
                <span className="zone-aqi" style={{ color: info.color }}>{zone.aqi}</span>
                <span className={`zone-trend ${trendClass}`}>
                  <TrendIcon size={14} strokeWidth={2} />
                  {Math.abs(zone.trend)}
                </span>
              </div>
            );
          })}
        </div>

        <div className="card">
          <div className="card-header">
            <h2 className="card-title" style={{ marginBottom: 0 }}>Alertes récentes</h2>
            <Link to="/alerts"><ChevronRight size={18} color="var(--text-muted)" /></Link>
          </div>
          {alerts.map((alert) => {
            const info = getAQIInfo(alert.value);
            return (
              <div key={alert.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                <div style={{ width: 8, height: 8, borderRadius: 4, background: info.color, flexShrink: 0 }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)' }}>{alert.stationName}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>{alert.message}</div>
                </div>
                <span className={`badge ${alert.status === 'active' ? 'badge-error' : alert.status === 'acknowledged' ? 'badge-warning' : 'badge-success'}`}>
                  {alert.status === 'active' ? 'Active' : alert.status === 'acknowledged' ? 'Reconnue' : 'Résolue'}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent articles */}
      <div className="card">
        <div className="card-header">
          <h2 className="card-title" style={{ marginBottom: 0 }}>Articles récents</h2>
          <Link to="/articles"><ChevronRight size={18} color="var(--text-muted)" /></Link>
        </div>
        {articles.map((article) => {
          const catColors = { alert: '#D32F2F', info: '#0288D1', report: '#0A6B3B', regulation: '#FF8F00', event: '#8F3F97' };
          const catLabels = { alert: 'Alerte', info: 'Info', report: 'Rapport', regulation: 'Réglement.', event: 'Événement' };
          const color = catColors[article.category] || '#0288D1';
          return (
            <div key={article.id} className="article-row">
              <span className="article-cat-badge" style={{ background: color + '20', color }}>{catLabels[article.category]}</span>
              <div className="article-content">
                <div className="article-title">{article.title}</div>
                <div className="article-meta">
                  <span className="article-author">{article.author_name}</span>
                  <span className="article-dot">·</span>
                  <span className={`badge ${article.status === 'published' ? 'badge-success' : 'badge-muted'}`} style={{ fontSize: 10 }}>
                    {article.status === 'published' ? 'Publié' : 'Brouillon'}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
