import React, { useState, useMemo } from 'react';
import { Factory, Home, Route, Building2, MapPin, Radio, CheckCircle } from 'lucide-react';
import { STATIONS, getAQIInfo } from '../data/constants.js';

const TYPE_LABELS = { residential: 'Résidentiel', road: 'Trafic', industrial: 'Industriel', reference: 'Référence' };
const TYPE_ICONS = { residential: Home, road: Route, industrial: Factory, reference: Building2 };

export default function Stations() {
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    if (!search) return STATIONS;
    return STATIONS.filter((s) => s.name.toLowerCase().includes(search.toLowerCase()) || s.zone.toLowerCase().includes(search.toLowerCase()));
  }, [search]);

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Stations de mesure</h1>
          <p className="page-subtitle">{STATIONS.length} stations actives — Réseau SEN-AIR Thiès</p>
        </div>
      </div>

      <div className="search-bar">
        <Radio size={16} color="var(--text-muted)" strokeWidth={2} />
        <input
          placeholder="Rechercher par nom ou zone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <table className="table">
          <thead className="table-header">
            <tr>
              <th style={{ width: 40 }}>#</th>
              <th>Station</th>
              <th>Zone</th>
              <th>Type</th>
              <th>AQI</th>
              <th>Statut</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((station, i) => {
              const info = getAQIInfo(station.aqi);
              const Icon = TYPE_ICONS[station.type] || Building2;
              return (
                <tr key={station.id} className="table-row">
                  <td style={{ color: 'var(--text-muted)' }}>{i + 1}</td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <Icon size={16} color="var(--text-secondary)" strokeWidth={2} />
                      <span style={{ fontWeight: 600 }}>{station.name}</span>
                    </div>
                  </td>
                  <td>{station.zone}</td>
                  <td>{TYPE_LABELS[station.type] || station.type}</td>
                  <td>
                    <span className="aqi-badge" style={{ background: info.color }}>{station.aqi}</span>
                  </td>
                  <td>
                    <span className="badge badge-success">
                      <CheckCircle size={12} strokeWidth={2} /> Active
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 16, marginTop: 16 }}>
        <div className="card" style={{ textAlign: 'center' }}>
          <Radio size={20} color="var(--primary)" strokeWidth={2} />
          <div className="kpi-value" style={{ fontSize: 24, marginTop: 8 }}>{STATIONS.length}</div>
          <div className="kpi-label">Stations actives</div>
        </div>
        <div className="card" style={{ textAlign: 'center' }}>
          <MapPin size={20} color="var(--secondary)" strokeWidth={2} />
          <div className="kpi-value" style={{ fontSize: 24, marginTop: 8 }}>9</div>
          <div className="kpi-label">Total réseau</div>
        </div>
        <div className="card" style={{ textAlign: 'center' }}>
          <CheckCircle size={20} color="var(--success)" strokeWidth={2} />
          <div className="kpi-value" style={{ fontSize: 24, marginTop: 8 }}>100%</div>
          <div className="kpi-label">Disponibilité</div>
        </div>
      </div>
    </div>
  );
}
