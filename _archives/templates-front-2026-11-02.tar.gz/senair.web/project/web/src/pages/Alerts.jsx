import React, { useState, useEffect, useMemo } from 'react';
import { Bell, Check, AlertTriangle, Clock } from 'lucide-react';
import { getAQIInfo } from '../data/constants.js';
import { fetchAlerts } from '../data/api.js';

export default function Alerts() {
  const [alerts, setAlerts] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAlerts().then((a) => { setAlerts(a); setLoading(false); });
  }, []);

  const filtered = useMemo(() => {
    if (filter === 'all') return alerts;
    return alerts.filter((a) => a.status === filter);
  }, [alerts, filter]);

  const stats = {
    active: alerts.filter((a) => a.status === 'active').length,
    acknowledged: alerts.filter((a) => a.status === 'acknowledged').length,
    resolved: alerts.filter((a) => a.status === 'resolved').length,
    total: alerts.length,
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Gestion des alertes</h1>
          <p className="page-subtitle">Suivi et résolution des alertes de qualité de l'air</p>
        </div>
      </div>

      <div className="kpi-grid">
        <div className="kpi-card" style={{ borderLeft: '3px solid var(--error)' }}>
          <Bell size={18} color="var(--error)" strokeWidth={2} />
          <div className="kpi-value" style={{ fontSize: 24, marginTop: 8 }}>{stats.active}</div>
          <div className="kpi-label">Actives</div>
        </div>
        <div className="kpi-card" style={{ borderLeft: '3px solid var(--accent)' }}>
          <Clock size={18} color="var(--accent)" strokeWidth={2} />
          <div className="kpi-value" style={{ fontSize: 24, marginTop: 8 }}>{stats.acknowledged}</div>
          <div className="kpi-label">Reconnues</div>
        </div>
        <div className="kpi-card" style={{ borderLeft: '3px solid var(--success)' }}>
          <Check size={18} color="var(--success)" strokeWidth={2} />
          <div className="kpi-value" style={{ fontSize: 24, marginTop: 8 }}>{stats.resolved}</div>
          <div className="kpi-label">Résolues</div>
        </div>
        <div className="kpi-card" style={{ borderLeft: '3px solid var(--secondary)' }}>
          <AlertTriangle size={18} color="var(--secondary)" strokeWidth={2} />
          <div className="kpi-value" style={{ fontSize: 24, marginTop: 8 }}>{stats.total}</div>
          <div className="kpi-label">Total</div>
        </div>
      </div>

      <div className="chip-row">
        {[
          { value: 'all', label: 'Toutes' },
          { value: 'active', label: 'Actives' },
          { value: 'acknowledged', label: 'Reconnues' },
          { value: 'resolved', label: 'Résolues' },
        ].map((f) => (
          <button
            key={f.value}
            className={`chip ${filter === f.value ? 'active' : ''}`}
            onClick={() => setFilter(f.value)}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="card">
        {loading ? (
          <div className="loading">Chargement...</div>
        ) : (
          filtered.map((alert) => {
            const info = getAQIInfo(alert.value);
            const statusClass = alert.status === 'active' ? 'badge-error' : alert.status === 'acknowledged' ? 'badge-warning' : 'badge-success';
            const statusLabel = alert.status === 'active' ? 'Active' : alert.status === 'acknowledged' ? 'Reconnue' : 'Résolue';
            const minutesAgo = Math.round((Date.now() - alert.timestamp.getTime()) / 60000);

            return (
              <div key={alert.id} className="alert-card">
                <div className="alert-bar" style={{ background: info.color }} />
                <div className="alert-body">
                  <div className="alert-top">
                    <div>
                      <div className="alert-station">{alert.stationName}</div>
                      <div className="alert-time">Il y a {minutesAgo} min · {alert.pollutant}</div>
                    </div>
                    <span className={`badge ${statusClass}`}>{statusLabel}</span>
                  </div>
                  <div className="alert-message">{alert.message}</div>
                  <div className="alert-metrics">
                    <div>
                      <div className="alert-metric-label">Valeur</div>
                      <div className="alert-metric-value" style={{ color: info.color }}>{alert.value} µg/m³</div>
                    </div>
                    <div>
                      <div className="alert-metric-label">Seuil OMS</div>
                      <div className="alert-metric-value">{alert.threshold} µg/m³</div>
                    </div>
                    <div>
                      <div className="alert-metric-label">Niveau</div>
                      <div className="alert-metric-value" style={{ color: info.color }}>{info.labelFr}</div>
                    </div>
                  </div>
                  {alert.status !== 'resolved' && (
                    <div className="alert-actions">
                      {alert.status === 'active' && (
                        <button className="btn btn-outline btn-sm">
                          <Check size={14} strokeWidth={2} />
                          Reconnaître
                        </button>
                      )}
                      <button className="btn btn-primary btn-sm">
                        <Check size={14} strokeWidth={2} />
                        Marquer résolue
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
