import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Save, Send, Star, Eye } from 'lucide-react';
import { fetchArticle, ARTICLE_CATEGORIES } from '../data/api.js';

export default function ArticleEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = !id;

  const [title, setTitle] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('info');
  const [authorName, setAuthorName] = useState('Administration');
  const [authorRole, setAuthorRole] = useState('');
  const [tags, setTags] = useState('');
  const [featured, setFeatured] = useState(false);
  const [status, setStatus] = useState('draft');
  const [toast, setToast] = useState(null);

  useEffect(() => {
    if (!isNew) {
      fetchArticle(id).then((article) => {
        if (article) {
          setTitle(article.title);
          setExcerpt(article.excerpt);
          setContent(article.content);
          setCategory(article.category);
          setAuthorName(article.author_name);
          setAuthorRole(article.author_role);
          setTags(article.tags.join(', '));
          setFeatured(article.featured);
          setStatus(article.status);
        }
      });
    }
  }, [id, isNew]);

  const handleSave = (newStatus) => {
    setStatus(newStatus);
    setToast(newStatus === 'published' ? 'Article publié avec succès' : 'Article enregistré');
    setTimeout(() => setToast(null), 2500);
  };

  return (
    <div className="page-container">
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
        <button onClick={() => navigate('/articles')} className="btn btn-outline btn-sm">
          <ArrowLeft size={16} strokeWidth={2} />
          Retour
        </button>
        <h1 className="page-title">{isNew ? 'Nouvel article' : 'Modifier l\'article'}</h1>
        <button
          onClick={() => setFeatured(!featured)}
          style={{
            background: featured ? 'var(--accent-light)' : 'var(--surface-alt)',
            border: 'none', borderRadius: 'var(--radius-pill)',
            padding: '6px 14px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
          }}
        >
          <Star size={16} color={featured ? 'var(--accent)' : 'var(--text-muted)'} fill={featured ? 'var(--accent)' : 'none'} strokeWidth={2} />
          <span style={{ fontSize: 12, fontWeight: 600, color: featured ? 'var(--accent)' : 'var(--text-muted)' }}>
            {featured ? 'À la une' : 'Mettre à la une'}
          </span>
        </button>
      </div>

      <div className="card" style={{ maxWidth: 800 }}>
        <div className="form-group">
          <label className="form-label">Titre</label>
          <input className="form-input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Titre de l'article" />
        </div>

        <div className="form-group">
          <label className="form-label">Catégorie</label>
          <div className="chip-row" style={{ marginBottom: 0 }}>
            {ARTICLE_CATEGORIES.map((cat) => (
              <button
                key={cat.value}
                className={`chip ${category === cat.value ? 'active' : ''}`}
                onClick={() => setCategory(cat.value)}
                style={category === cat.value ? { background: cat.color, borderColor: cat.color } : {}}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        <div className="form-group">
          <label className="form-label">Résumé (extrait)</label>
          <textarea
            className="form-textarea"
            value={excerpt}
            onChange={(e) => setExcerpt(e.target.value)}
            placeholder="Court résumé affiché dans les listes"
            style={{ minHeight: 60 }}
          />
        </div>

        <div className="form-group">
          <label className="form-label">Contenu (Markdown)</label>
          <textarea
            className="form-textarea"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="# Titre de l'article&#10;&#10;Contenu en Markdown..."
            style={{ minHeight: 240, fontFamily: 'monospace', fontSize: 13 }}
          />
        </div>

        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Auteur</label>
            <input className="form-input" value={authorName} onChange={(e) => setAuthorName(e.target.value)} placeholder="Nom de l'auteur" />
          </div>
          <div className="form-group">
            <label className="form-label">Rôle</label>
            <input className="form-input" value={authorRole} onChange={(e) => setAuthorRole(e.target.value)} placeholder="Rôle (ex: Directrice)" />
          </div>
        </div>

        <div className="form-group">
          <label className="form-label">Tags (séparés par des virgules)</label>
          <input className="form-input" value={tags} onChange={(e) => setTags(e.target.value)} placeholder="alerte, pm25, centre-ville" />
        </div>

        <div className="form-group">
          <label className="form-label">Statut</label>
          <div className="chip-row" style={{ marginBottom: 0 }}>
            {[
              { value: 'draft', label: 'Brouillon' },
              { value: 'published', label: 'Publié' },
              { value: 'archived', label: 'Archivé' },
            ].map((s) => (
              <button
                key={s.value}
                className={`chip ${status === s.value ? 'active' : ''}`}
                onClick={() => setStatus(s.value)}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 16, maxWidth: 800, marginTop: 8 }}>
        <button className="btn btn-outline" style={{ flex: 1, justifyContent: 'center' }} onClick={() => handleSave('draft')}>
          <Save size={16} strokeWidth={2} />
          Enregistrer
        </button>
        <button className="btn btn-primary" style={{ flex: 1, justifyContent: 'center' }} onClick={() => handleSave('published')}>
          <Send size={16} strokeWidth={2} />
          Publier
        </button>
      </div>

      {toast && (
        <div className="toast">
          <Eye size={16} />
          {toast}
        </div>
      )}
    </div>
  );
}
