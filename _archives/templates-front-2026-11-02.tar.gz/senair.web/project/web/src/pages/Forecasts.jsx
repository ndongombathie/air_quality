import React, { useState, useEffect } from 'react';
import { Clock, Calendar, ArrowUpRight, ArrowDownRight, Minus, Info } from 'lucide-react';
import { STATIONS, getAQIInfo } from '../data/constants.js';
import { fetchExtendedForecasts } from '../data/api.js';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';

export default function Forecasts() {
  const [forecasts, setForecasts] = useState([]);

  useEffect(() => {
    fetchExtendedForecasts(STATIONS).then(setForecasts);
  }, []);

  if (forecasts.length === 0) return <div className="loading">Chargement des prévisions...</div>;

  const hourly = forecasts.filter((f) => f.horizon === '1h' || f.horizon === '2h' || f.horizon === '3h');
  const daily = forecasts.filter((f) => f.horizon.startsWith('J'));

  const chartData = forecasts.map((f) => ({ horizon: f.horizon, aqi: f.aqi }));

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Prévisions qualité de l'air</h1>
          <p className="page-subtitle">Court terme (1h, 2h, 3h) et moyen terme (J+1, J+2, J+3)</p>
        </div>
      </div>

      {/* Combined chart */}
      <div className="card">
        <h2 className="card-title">Évolution prévue de l'AQI</h2>
        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="horizon" tick={{ fontSize: 12, fill: 'var(--text-secondary)' }} />
            <YAxis tick={{ fontSize: 11, fill: 'var(--text-muted)' }} />
            <Tooltip contentStyle={{ borderRadius: 10, border: '1px solid var(--border)', fontSize: 13 }} />
            <ReferenceLine y={50} stroke="#00E400" strokeDasharray="3 3" label={{ text: 'Bon', fontSize: 10, fill: '#1B5E20' }} />
            <ReferenceLine y={100} stroke="#FFFF00" strokeDasharray="3 3" label={{ text: 'Modéré', fontSize: 10, fill: '#F57F17' }} />
            <ReferenceLine y={150} stroke="#FF9900" strokeDasharray="3 3" label={{ text: 'Sensible', fontSize: 10, fill: '#E65100' }} />
            <Line type="monotone" dataKey="aqi" stroke="var(--primary)" strokeWidth={3} dot={{ r: 5, fill: 'var(--primary)' }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Hourly forecasts */}
      <div className="section-header">
        <Clock size={18} color="var(--primary)" strokeWidth={2} />
        <h2>Prévisions horaires</h2>
      </div>
      <div className="forecast-grid">
        {hourly.map((f) => {
          const info = getAQIInfo(f.aqi);
          const TrendIcon = f.trend === 'up' ? ArrowUpRight : f.trend === 'down' ? ArrowDownRight : Minus;
          const trendClass = f.trend === 'up' ? 'trend-up' : f.trend === 'down' ? 'trend-down' : 'trend-stable';
          return (
            <div key={f.horizon} className="forecast-card" style={{ borderColor: info.color + '30' }}>
              <span className="forecast-badge" style={{ background: info.color }}>{f.horizon}</span>
              <div className="forecast-label">{f.label}</div>
              <div className="forecast-aqi" style={{ color: info.color }}>{f.aqi}</div>
              <div className="forecast-status" style={{ color: info.textColor }}>{info.labelFr}</div>
              <div className={`forecast-trend ${trendClass}`}>
                <TrendIcon size={14} strokeWidth={2} />
                {f.trend === 'up' ? 'Hausse' : f.trend === 'down' ? 'Baisse' : 'Stable'}
              </div>
              <div className="forecast-confidence">
                <div className="confidence-bar">
                  <div className="confidence-fill" style={{ width: `${f.confidence * 100}%`, background: 'var(--primary)' }} />
                </div>
                <div className="confidence-text">Confiance: {Math.round(f.confidence * 100)}%</div>
              </div>
              <div className="forecast-factors">
                {f.factors.map((factor, i) => (
                  <div key={i} className="forecast-factor">
                    <Info size={10} color="var(--text-muted)" strokeWidth={2} />
                    {factor}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Daily forecasts */}
      <div className="section-header">
        <Calendar size={18} color="var(--accent)" strokeWidth={2} />
        <h2>Prévisions à 3 jours</h2>
      </div>
      <div className="forecast-grid">
        {daily.map((f) => {
          const info = getAQIInfo(f.aqi);
          const TrendIcon = f.trend === 'up' ? ArrowUpRight : f.trend === 'down' ? ArrowDownRight : Minus;
          const trendClass = f.trend === 'up' ? 'trend-up' : f.trend === 'down' ? 'trend-down' : 'trend-stable';
          return (
            <div key={f.horizon} className="forecast-card" style={{ borderColor: info.color + '30' }}>
              <span className="forecast-badge" style={{ background: info.color }}>{f.horizon}</span>
              <div className="forecast-label">{f.label}</div>
              <div className="forecast-aqi" style={{ color: info.color }}>{f.aqi}</div>
              <div className="forecast-status" style={{ color: info.textColor }}>{info.labelFr}</div>
              <div className={`forecast-trend ${trendClass}`}>
                <TrendIcon size={14} strokeWidth={2} />
                {f.trend === 'up' ? 'Hausse' : f.trend === 'down' ? 'Baisse' : 'Stable'}
              </div>
              <div className="forecast-confidence">
                <div className="confidence-bar">
                  <div className="confidence-fill" style={{ width: `${f.confidence * 100}%`, background: 'var(--accent)' }} />
                </div>
                <div className="confidence-text">Confiance: {Math.round(f.confidence * 100)}%</div>
              </div>
              <div className="forecast-factors">
                {f.factors.map((factor, i) => (
                  <div key={i} className="forecast-factor">
                    <Info size={10} color="var(--text-muted)" strokeWidth={2} />
                    {factor}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
