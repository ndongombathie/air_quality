import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Stations from './pages/Stations.jsx';
import Articles from './pages/Articles.jsx';
import ArticleEditor from './pages/ArticleEditor.jsx';
import Forecasts from './pages/Forecasts.jsx';
import Alerts from './pages/Alerts.jsx';
import Analytics from './pages/Analytics.jsx';

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/stations" element={<Stations />} />
        <Route path="/articles" element={<Articles />} />
        <Route path="/articles/new" element={<ArticleEditor />} />
        <Route path="/articles/:id" element={<ArticleEditor />} />
        <Route path="/forecasts" element={<Forecasts />} />
        <Route path="/alerts" element={<Alerts />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Layout>
  );
}
