import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { LayoutDashboard, Radio, FileText, TrendingUp, Bell, BarChart3, Leaf, Menu, X } from 'lucide-react';

const NAV_ITEMS = [
  { href: '/dashboard', label: 'Tableau de bord', icon: LayoutDashboard },
  { href: '/stations', label: 'Stations', icon: Radio },
  { href: '/articles', label: 'Articles', icon: FileText },
  { href: '/forecasts', label: 'Prévisions', icon: TrendingUp },
  { href: '/alerts', label: 'Alertes', icon: Bell },
  { href: '/analytics', label: 'Analytique', icon: BarChart3 },
];

export default function Layout({ children }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  return (
    <div className="app-layout">
      <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <div className="sidebar-logo">
            <Leaf size={28} strokeWidth={2.5} />
          </div>
          <div>
            <div className="sidebar-title">SEN-AIR</div>
            <div className="sidebar-subtitle">Console d'administration</div>
          </div>
        </div>

        <nav className="sidebar-nav">
          <div className="nav-section-title">Surveillance</div>
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.href}
                to={item.href}
                className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
                onClick={() => setMobileOpen(false)}
              >
                <Icon size={18} strokeWidth={2} />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>

        <div className="sidebar-footer">
          <div className="user-card">
            <div className="user-avatar">AD</div>
            <div>
              <div className="user-name">Administration</div>
              <div className="user-role">Décideur SEN-AIR</div>
            </div>
          </div>
        </div>
      </aside>

      <main className="main-content">
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          style={{
            position: 'fixed', top: 16, left: 16, zIndex: 200,
            background: 'var(--surface)', border: '1px solid var(--border)',
            borderRadius: 10, padding: 10, cursor: 'pointer', display: 'none',
          }}
          className="mobile-menu-btn"
        >
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        {children}
      </main>
    </div>
  );
}
