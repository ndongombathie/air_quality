export type AQILevel = 'good' | 'moderate' | 'sensitive' | 'unhealthy' | 'very_unhealthy' | 'hazardous';

export interface AQIInfo {
  level: AQILevel;
  label: string;
  labelFr: string;
  color: string;
  bgColor: string;
  textColor: string;
  min: number;
  max: number;
  icon: string;
}

export interface Pollutant {
  id: string;
  name: string;
  unit: string;
  value: number;
  whoLimit: number;
  description: string;
}

export interface WeatherData {
  temperature: number;
  humidity: number;
  windSpeed: number;
  windDirection: string;
  pressure: number;
  condition: string;
  icon: string;
}

export interface Station {
  id: number;
  name: string;
  zone: string;
  lat: number;
  lng: number;
  aqi: number;
  pollutants: Pollutant[];
  weather: WeatherData;
  lastUpdate: Date;
  type: 'industrial' | 'residential' | 'road' | 'reference';
  active: boolean;
}

export interface Alert {
  id: string;
  stationId: number;
  stationName: string;
  pollutant: string;
  value: number;
  threshold: number;
  level: AQILevel;
  timestamp: Date;
  read: boolean;
  message: string;
}

export interface HealthProfile {
  id: string;
  label: string;
  icon: string;
  description: string;
}

export interface Recommendation {
  profile: string;
  aqiLevel: AQILevel;
  title: string;
  actions: string[];
  color: string;
}

export interface WHONorm {
  pollutant: string;
  formula: string;
  annual?: number;
  daily?: number;
  hourly8?: number;
  unit: string;
}

export interface HistoryPoint {
  time: string;
  aqi: number;
  pm25: number;
  pm10: number;
}

export interface ForecastPoint {
  time: string;
  aqi: number;
  confidence: number;
  interpolated: boolean;
}

export interface StationReading {
  station_id: number;
  pm25: number | null;
  pm10: number | null;
  temperature: number | null;
  humidity: number | null;
  co2: number | null;
  tvoc: number | null;
  co: number | null;
  no: number | null;
  no2: number | null;
  so2: number | null;
  o3: number | null;
  nh3: number | null;
  vitesse_vent: number | null;
  direction_vent: number | null;
  iqr: number | null;
  categorie_iqa: string | null;
  timestamp: string;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: 'alert' | 'info' | 'report' | 'regulation' | 'event';
  author_name: string;
  author_role: string;
  status: 'draft' | 'published' | 'archived';
  featured: boolean;
  image_url: string | null;
  tags: string[];
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface ExtendedForecast {
  horizon: '1h' | '2h' | '3h' | 'J+1' | 'J+2' | 'J+3';
  label: string;
  aqi: number;
  confidence: number;
  trend: 'up' | 'down' | 'stable';
  factors: string[];
}

export interface DashboardStats {
  totalStations: number;
  activeStations: number;
  avgAQI: number;
  maxAQI: number;
  totalAlerts: number;
  unreadAlerts: number;
  totalArticles: number;
  publishedArticles: number;
  stationsByType: { type: string; count: number; avgAQI: number }[];
  topPollutedZones: { zone: string; aqi: number; trend: number }[];
  alertsByLevel: { level: AQILevel; count: number }[];
}

export interface AdminAlert {
  id: string;
  stationId: number;
  stationName: string;
  pollutant: string;
  value: number;
  threshold: number;
  level: AQILevel;
  timestamp: Date;
  status: 'active' | 'acknowledged' | 'resolved';
  message: string;
}
