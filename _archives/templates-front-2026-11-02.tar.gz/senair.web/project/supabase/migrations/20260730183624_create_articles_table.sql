/*
# Create articles table for admin publications

1. New Tables
- `articles` — publications created by admin/deciders, visible on mobile app
  - id (uuid, primary key)
  - title (text, not null)
  - slug (text, unique, not null)
  - excerpt (text — short summary shown in lists)
  - content (text — full article body, markdown)
  - category (text: 'alert' | 'info' | 'report' | 'regulation' | 'event')
  - author_name (text)
  - author_role (text — e.g. "Directeur", "Analyste")
  - status (text: 'draft' | 'published' | 'archived')
  - featured (boolean, default false)
  - image_url (text — optional header image)
  - tags (text[] — optional tags)
  - published_at (timestamptz — when the article goes live)
  - created_at (timestamptz)
  - updated_at (timestamptz)

2. Security
- Single-tenant admin app (no sign-in for now). RLS enabled, anon+authenticated have full CRUD.
- Data is intentionally public/shared — articles are meant to be read by all mobile users.
*/

CREATE TABLE IF NOT EXISTS articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  excerpt text,
  content text,
  category text NOT NULL DEFAULT 'info',
  author_name text NOT NULL DEFAULT 'Administration',
  author_role text DEFAULT '',
  status text NOT NULL DEFAULT 'draft',
  featured boolean NOT NULL DEFAULT false,
  image_url text,
  tags text[] DEFAULT '{}',
  published_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE articles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_articles" ON articles;
CREATE POLICY "anon_select_articles" ON articles FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_articles" ON articles;
CREATE POLICY "anon_insert_articles" ON articles FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_articles" ON articles;
CREATE POLICY "anon_update_articles" ON articles FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_articles" ON articles;
CREATE POLICY "anon_delete_articles" ON articles FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_articles_status ON articles(status);
CREATE INDEX IF NOT EXISTS idx_articles_published_at ON articles(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_articles_category ON articles(category);
