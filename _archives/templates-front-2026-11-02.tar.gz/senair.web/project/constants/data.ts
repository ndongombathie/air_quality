import { AQIInfo, AQILevel, Pollutant, WeatherData, Station, Alert, Recommendation, WHONorm, HistoryPoint, ForecastPoint, StationReading } from '@/types';

export const AQI_LEVELS: Record<AQILevel, AQIInfo> = {
  good: {
    level: 'good',
    label: 'Good',
    labelFr: 'Bon',
    color: '#00E400',
    bgColor: '#E8F8E8',
    textColor: '#1B5E20',
    min: 0,
    max: 50,
    icon: 'check-circle',
  },
  moderate: {
    level: 'moderate',
    label: 'Moderate',
    labelFr: 'Modéré',
    color: '#FFFF00',
    bgColor: '#FFFDE7',
    textColor: '#F57F17',
    min: 51,
    max: 100,
    icon: 'alert-circle',
  },
  sensitive: {
    level: 'sensitive',
    label: 'Unhealthy for Sensitive Groups',
    labelFr: 'Malsain pour groupes sensibles',
    color: '#FF7E00',
    bgColor: '#FFF3E0',
    textColor: '#E65100',
    min: 101,
    max: 150,
    icon: 'alert-triangle',
  },
  unhealthy: {
    level: 'unhealthy',
    label: 'Unhealthy',
    labelFr: 'Malsain',
    color: '#FF0000',
    bgColor: '#FFEBEE',
    textColor: '#B71C1C',
    min: 151,
    max: 200,
    icon: 'alert-octagon',
  },
  very_unhealthy: {
    level: 'very_unhealthy',
    label: 'Very Unhealthy',
    labelFr: 'Très malsain',
    color: '#8F3F97',
    bgColor: '#F3E5F5',
    textColor: '#4A148C',
    min: 201,
    max: 300,
    icon: 'alert-octagon',
  },
  hazardous: {
    level: 'hazardous',
    label: 'Hazardous',
    labelFr: 'Dangereux',
    color: '#7E0023',
    bgColor: '#FCE4EC',
    textColor: '#560027',
    min: 301,
    max: 500,
    icon: 'skull',
  },
};

export function getAQIInfo(aqi: number): AQIInfo {
  if (aqi <= 50) return AQI_LEVELS.good;
  if (aqi <= 100) return AQI_LEVELS.moderate;
  if (aqi <= 150) return AQI_LEVELS.sensitive;
  if (aqi <= 200) return AQI_LEVELS.unhealthy;
  if (aqi <= 300) return AQI_LEVELS.very_unhealthy;
  return AQI_LEVELS.hazardous;
}

export function aqiFromCategorie(categorie: string): number {
  switch (categorie) {
    case 'Bon': return 40;
    case 'Modérée': return 75;
    case 'Malsain pour groupes sensibles': return 125;
    case 'Malsain': return 175;
    case 'Très mauvaise': return 250;
    case 'Dangereux': return 350;
    default: return 75;
  }
}

export const WHO_NORMS: WHONorm[] = [
  { pollutant: 'Dioxyde d\'azote', formula: 'NO₂', annual: 10, hourly8: 25, unit: 'µg/m³' },
  { pollutant: 'Dioxyde de soufre', formula: 'SO₂', daily: 40, hourly8: 200, unit: 'µg/m³' },
  { pollutant: 'Ozone', formula: 'O₃', hourly8: 100, unit: 'µg/m³' },
  { pollutant: 'Particules fines', formula: 'PM2.5', annual: 5, daily: 15, unit: 'µg/m³' },
  { pollutant: 'Particules grossières', formula: 'PM10', annual: 15, daily: 45, unit: 'µg/m³' },
  { pollutant: 'Monoxyde de carbone', formula: 'CO', daily: 4, unit: 'mg/m³' },
];

export const HEALTH_PROFILES = [
  { id: 'general', label: 'Population générale', icon: 'users', description: 'Adultes en bonne santé' },
  { id: 'children', label: 'Enfants', icon: 'baby', description: 'Moins de 12 ans' },
  { id: 'elderly', label: 'Personnes âgées', icon: 'accessibility', description: 'Plus de 65 ans' },
  { id: 'asthma', label: 'Asthmatiques', icon: 'wind', description: 'Maladies respiratoires' },
  { id: 'cardiac', label: 'Cardiaques', icon: 'heart-pulse', description: 'Maladies cardiovasculaires' },
  { id: 'pregnant', label: 'Femmes enceintes', icon: 'heart', description: 'Grossesse' },
  { id: 'outdoor', label: 'Travailleurs extérieurs', icon: 'hard-hat', description: 'Exposition professionnelle' },
  { id: 'athlete', label: 'Sportifs', icon: 'activity', description: 'Activité physique intense' },
];

export const RECOMMENDATIONS: Recommendation[] = [
  {
    profile: 'general',
    aqiLevel: 'good',
    title: 'Qualité de l\'air idéale',
    actions: [
      'Profitez pleinement des activités en plein air',
      'Aérez votre domicile en grand',
      'Aucune précaution particulière nécessaire',
    ],
    color: '#00B86B',
  },
  {
    profile: 'general',
    aqiLevel: 'moderate',
    title: 'Qualité de l\'air acceptable',
    actions: [
      'Activités extérieures possibles sans restriction majeure',
      'Aérez en début de journée quand la pollution est plus faible',
      'Surveillez les évolutions si vous êtes sensible',
    ],
    color: '#F5A623',
  },
  {
    profile: 'general',
    aqiLevel: 'sensitive',
    title: 'Prudence recommandée',
    actions: [
      'Limitez les efforts intenses en plein air',
      'Préférez l\'activité physique en intérieur',
      'Aérez tôt le matin (6h-8h)',
    ],
    color: '#FF7E00',
  },
  {
    profile: 'general',
    aqiLevel: 'unhealthy',
    title: 'Évitez l\'extérieur',
    actions: [
      'Restez à l\'intérieur autant que possible',
      'Fermez fenêtres et portes',
      'Utilisez un purificateur d\'air si disponible',
    ],
    color: '#E53935',
  },
  {
    profile: 'general',
    aqiLevel: 'very_unhealthy',
    title: 'Alerte sanitaire',
    actions: [
      'Restez impérativement à l\'intérieur',
      'Évitez toute activité physique',
      'Portez un masque si vous devez sortir',
    ],
    color: '#8F3F97',
  },
  {
    profile: 'children',
    aqiLevel: 'moderate',
    title: 'Surveillance renforcée pour les enfants',
    actions: [
      'Limitez les jeux extérieurs prolongés',
      'Privilégiez les activités calmes en intérieur',
      'Surveillez la respiration et la toux',
    ],
    color: '#F5A623',
  },
  {
    profile: 'children',
    aqiLevel: 'sensitive',
    title: 'Protection des enfants',
    actions: [
      'Maintenez les enfants à l\'intérieur',
      'Suspendez les activités sportives en extérieur',
      'Consultez un médecin en cas de toux ou gêne',
    ],
    color: '#FF7E00',
  },
  {
    profile: 'asthma',
    aqiLevel: 'moderate',
    title: 'Vigilance asthmatiques',
    actions: [
      'Gardez votre bronchodilatateur à portée de main',
      'Évitez les zones à fort trafic',
      'Surveillez tout signe d\'essoufflement',
    ],
    color: '#F5A623',
  },
  {
    profile: 'asthma',
    aqiLevel: 'sensitive',
    title: 'Précautions asthmatiques',
    actions: [
      'Restez à l\'intérieur, climatisation si possible',
      'Utilisez votre traitement de fond régulièrement',
      'Consultez immédiatement en cas de crise',
    ],
    color: '#FF7E00',
  },
  {
    profile: 'cardiac',
    aqiLevel: 'moderate',
    title: 'Attention cardiaques',
    actions: [
      'Évitez les efforts physiques intenses',
      'Surveillez tension et rythme cardiaque',
      'Ne sortez pas aux heures chaudes',
    ],
    color: '#F5A623',
  },
  {
    profile: 'outdoor',
    aqiLevel: 'unhealthy',
    title: 'Protection travailleurs extérieurs',
    actions: [
      'Portez un masque de protection FFP2',
      'Faites des pauses à l\'intérieur toutes les 2 heures',
      'Hydratez-vous abondamment',
    ],
    color: '#E53935',
  },
  {
    profile: 'athlete',
    aqiLevel: 'moderate',
    title: 'Ajustement sportif',
    actions: [
      'Réduisez l\'intensité de 50%',
      'Préférez l\'entraînement en salle',
      'Évitez les séances longues en extérieur',
    ],
    color: '#F5A623',
  },
];

export const STATION_LOCATIONS = [
  { id: 89441, name: 'Université Iba Der Thiam', shortName: 'Univ. Iba Der Thiam', zone: 'Université', lat: 14.794498116325476, lng: -16.96105368259619, type: 'residential' as const },
  { id: 166062, name: 'Ecole Elémentaire Sud Stade', shortName: 'Sud Stade', zone: 'Sud Stade', lat: 14.767584195764858, lng: -16.943624763523218, type: 'residential' as const },
  { id: 168373, name: 'Hôtel de Ville', shortName: 'Hôtel de Ville', zone: 'Centre-ville', lat: 14.791343, lng: -16.924869, type: 'road' as const },
  { id: 168377, name: 'Lycée Malick Sy', shortName: 'Lycée Malick Sy', zone: 'Malick Sy', lat: 14.784821362711984, lng: -16.939469998191395, type: 'residential' as const },
  { id: 168388, name: 'Lycée Jules Sagna', shortName: 'Lycée Jules Sagna', zone: 'Jules Sagna', lat: 14.796931104490659, lng: -16.92713209381339, type: 'residential' as const },
  { id: 168393, name: 'Lycee Medina Fall', shortName: 'Medina Fall', zone: 'Medina Fall', lat: 14.8006029, lng: -16.9074725, type: 'residential' as const },
  { id: 168394, name: 'Ecole élémentaire Kaba Sall', shortName: 'Kaba Sall', zone: 'Kaba Sall', lat: 14.7777094, lng: -16.9147503, type: 'residential' as const },
  { id: 168397, name: 'Collège Cité Lamy', shortName: 'Cité Lamy', zone: 'Cité Lamy', lat: 14.7755516, lng: -16.9317663, type: 'residential' as const },
  { id: 168401, name: 'Lycée de FAHU', shortName: 'FAHU', zone: 'FAHU', lat: 14.765215, lng: -16.9445212, type: 'residential' as const },
];

export function buildPollutants(r: StationReading): Pollutant[] {
  const pollutants: Pollutant[] = [];
  if (r.pm25 != null) pollutants.push({ id: 'pm25', name: 'PM2.5', unit: 'µg/m³', value: r.pm25, whoLimit: 15, description: 'Particules fines' });
  if (r.pm10 != null) pollutants.push({ id: 'pm10', name: 'PM10', unit: 'µg/m³', value: r.pm10, whoLimit: 45, description: 'Particules grossières' });
  if (r.no2 != null) pollutants.push({ id: 'no2', name: 'NO₂', unit: 'µg/m³', value: r.no2, whoLimit: 25, description: 'Dioxyde d\'azote' });
  if (r.so2 != null) pollutants.push({ id: 'so2', name: 'SO₂', unit: 'µg/m³', value: r.so2, whoLimit: 40, description: 'Dioxyde de soufre' });
  if (r.o3 != null) pollutants.push({ id: 'o3', name: 'O₃', unit: 'µg/m³', value: r.o3, whoLimit: 100, description: 'Ozone' });
  if (r.co2 != null) pollutants.push({ id: 'co2', name: 'CO₂', unit: 'ppm', value: r.co2, whoLimit: 1000, description: 'Dioxyde de carbone' });
  return pollutants;
}

export function buildWeather(r: StationReading): WeatherData {
  const windDir = r.direction_vent != null ? compassDirection(r.direction_vent) : 'N';
  return {
    temperature: r.temperature ?? 30,
    humidity: r.humidity ?? 50,
    windSpeed: r.vitesse_vent ?? 7,
    windDirection: windDir,
    pressure: 1013,
    condition: r.temperature != null && r.temperature > 33 ? 'Ensoleillé' : 'Partiellement nuageux',
    icon: r.temperature != null && r.temperature > 33 ? 'sun' : 'cloud-sun',
  };
}

function compassDirection(deg: number): string {
  const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'];
  return dirs[Math.round(deg / 45) % 8];
}

export const SAMPLE_ALERTS: Alert[] = [
  {
    id: 'alert-1',
    stationId: 168373,
    stationName: 'Hôtel de Ville',
    pollutant: 'PM2.5',
    value: 205,
    threshold: 15,
    level: 'very_unhealthy',
    timestamp: new Date(Date.now() - 1000 * 60 * 15),
    read: false,
    message: 'Dépassement critique du seuil OMS pour les particules fines PM2.5',
  },
  {
    id: 'alert-2',
    stationId: 168393,
    stationName: 'Lycee Medina Fall',
    pollutant: 'CO₂',
    value: 510,
    threshold: 1000,
    level: 'moderate',
    timestamp: new Date(Date.now() - 1000 * 60 * 45),
    read: false,
    message: 'Concentration élevée en dioxyde de carbone',
  },
  {
    id: 'alert-3',
    stationId: 168394,
    stationName: 'Ecole élémentaire Kaba Sall',
    pollutant: 'CO₂',
    value: 815,
    threshold: 1000,
    level: 'moderate',
    timestamp: new Date(Date.now() - 1000 * 60 * 120),
    read: true,
    message: 'Niveau de CO₂ élevé détecté en salle de classe',
  },
  {
    id: 'alert-4',
    stationId: 168373,
    stationName: 'Hôtel de Ville',
    pollutant: 'PM10',
    value: 207,
    threshold: 45,
    level: 'very_unhealthy',
    timestamp: new Date(Date.now() - 1000 * 60 * 180),
    read: true,
    message: 'Particules grossières très au-dessus de la norme OMS',
  },
];

export const HISTORY_24H: HistoryPoint[] = Array.from({ length: 24 }, (_, i) => {
  const hour = i;
  const baseAQI = 90 + Math.sin((hour / 24) * Math.PI * 2) * 40 + Math.random() * 20;
  const basePM25 = baseAQI * 0.35 + Math.random() * 5;
  const basePM10 = baseAQI * 0.55 + Math.random() * 8;
  return {
    time: `${String(hour).padStart(2, '0')}:00`,
    aqi: Math.round(baseAQI),
    pm25: Math.round(basePM25),
    pm10: Math.round(basePM10),
  };
});

export const HISTORY_7D: HistoryPoint[] = Array.from({ length: 7 }, (_, i) => {
  const days = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
  const baseAQI = 100 + Math.sin(i * 0.8) * 35 + Math.random() * 15;
  return {
    time: days[i],
    aqi: Math.round(baseAQI),
    pm25: Math.round(baseAQI * 0.35),
    pm10: Math.round(baseAQI * 0.55),
  };
});

export const COLORS = {
  primary: '#0A6B3B',
  primaryDark: '#064A28',
  primaryLight: '#E8F5E9',
  secondary: '#0288D1',
  secondaryDark: '#01579B',
  secondaryLight: '#E1F5FE',
  accent: '#FF8F00',
  accentLight: '#FFF8E1',
  success: '#00C853',
  warning: '#FFAB00',
  error: '#D32F2F',
  background: '#F7F9FA',
  surface: '#FFFFFF',
  surfaceAlt: '#F0F4F5',
  text: '#1A1F23',
  textSecondary: '#5F6B72',
  textMuted: '#9BA8B0',
  border: '#E3E8EB',
  dark: '#0B1416',
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const RADIUS = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  pill: 999,
};

export const TYPOGRAPHY = {
  heading: 'Inter-Bold',
  body: 'Inter-Regular',
  medium: 'Inter-Medium',
  light: 'Inter-Light',
};
